package testSuites.LaboratorioCucumber;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.After;
import org.junit.runner.RunWith;


@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = "com.hpe.alm.octane.OctaneGherkinFormatter:gherkin-results/ManualRunnerTest_OctaneGherkinResults.xml",
        features = "src/test/java/features",
        glue = {"steps"},
        tags = {"@BSPID941022REV0.28.0"}

)

public class LabCucumber {
    @After
    public void afterClasss() {
        // Do nothing because of X and Y.
    }
}

