package pages.Web;

import driverWeb.DriverContextWeb;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.web.UtilsWeb;

import static utils.web.ControlledActionsWeb.visualizarObjeto;

public class PortalWeb implements Portal {
    private WebDriver driver;

    public PortalWeb() {
        this.driver = DriverContextWeb.getDriverWeb();
        PageFactory.initElements(this.driver, this);
    }

    //-----------------Se declaran todos los elementos Web------------------------------
    @FindBy(xpath = "//*[@id=\"login\"]/form/p[1]/input")
    private WebElement campoUsuario;
    @FindBy(xpath = "//*[@id=\"login\"]/form/p[2]/input[1]")
    private WebElement campoPassword;
    @FindBy(xpath = "//*[@id=\"login\"]/form/p[3]/input")
    private WebElement btnIngresar;
    @FindBy(xpath = "//input[@value=\"Enrolar Luego\"]")
    private WebElement btnEnrolarLuego;

    //----------------- funciones ------------------------------
    public void setCampoUsuario(String usuario) {
        String step = "Ingreso credenciales al campo usuario";
        String descripcion = "Se ingresa la credencial '" + usuario + "' al campo usuario";
        try {
            campoUsuario.sendKeys(usuario);
            UtilsWeb.enmarcarObjeto(campoUsuario);
            PdfBciReports.addWebReportImage(step, descripcion, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(campoUsuario);
        } catch (NoSuchElementException | NullPointerException e) {
            PdfBciReports.addWebReportImage(step, "Error: No se encontro el elemento campo usuario asociado a la pantalla de inicio de sesion en la Web Portal. " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void setCampoPassword(String password) {
        String step = "Ingreso credenciales al campo password";
        String descripcion = "Se ingresa la credencial " + password + " al campo password";
        try {
            campoPassword.sendKeys(password);
            UtilsWeb.enmarcarObjeto(campoPassword);
            PdfBciReports.addWebReportImage(step, descripcion, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(campoPassword);
        } catch (NoSuchElementException | NullPointerException e) {
            PdfBciReports.addWebReportImage(step, "Error: No se encontro el elemento campo password asociado a la pantalla de inicio de sesion en la Web Portal. " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void clickIngresar() {
        String step = "Presiono boton 'Ingresar'";
        String descripcion = "Boton visualizado";
        try {
            if (visualizarObjeto(btnIngresar, 1)) {
                UtilsWeb.enmarcarObjeto(btnIngresar);
                PdfBciReports.addWebReportImage(step, descripcion, EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(btnIngresar);
            }
            btnIngresar.click();
        } catch (NoSuchElementException e) {
        }
    }

    public void clickBtnEnrolarLuego() {
        String step = "Presiono boton 'Enrolar Luego'";
        String descripcion = "Boton visualizado";
        try {
            if (visualizarObjeto(btnEnrolarLuego, 5)) {
                UtilsWeb.enmarcarObjeto(btnEnrolarLuego);
                PdfBciReports.addWebReportImage(step, descripcion, EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(btnEnrolarLuego);
            }
            btnEnrolarLuego.click();
        } catch (NoSuchElementException e) {
            PdfBciReports.addReport("clickBtnEnrolarLuego", "error: " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }
}
