package pages.Web;

public interface Portal {

    static Portal pageObject() {
        return new PortalWeb();
    }

    void setCampoUsuario(String usuario);

    void setCampoPassword(String password);

    void clickIngresar();

    void clickBtnEnrolarLuego();
}