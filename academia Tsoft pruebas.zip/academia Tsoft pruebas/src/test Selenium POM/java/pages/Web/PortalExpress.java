package pages.Web;

public interface PortalExpress {

    static PortalExpress pageObject() {
        return new BciExpress();
    }

     void visualizoGrillaNumeroPagadoresConDocumentosPublicados();

     void presionarOpcionFinanciamientoFactoring(String opc2);

     void presionarOpcionInformacionProveedor(String opc1);

     void visualizarBciExpress();

     void btnConsultas();

     void clickBtnPagos();

     void clickBtnFactoringCtaCteProveedor();
}
