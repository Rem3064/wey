package pages.Web;

import driverWeb.DriverContextWeb;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;
import utils.web.UtilsWeb;

import java.util.List;

import static utils.web.ControlledActionsWeb.visualizarObjeto;


public class BciExpress implements PortalExpress {
    private WebDriver driver;

    public BciExpress() {
        this.driver = DriverContextWeb.getDriverWeb();
        PageFactory.initElements(this.driver, this);
    }

    @FindBy(xpath = "//a[@id='consultas']")
    private WebElement btnConsultas;

    @FindBy(xpath = "//frame[@name='tophead']")
    private WebElement frame1;

    @FindBy(xpath = "//frame[@name='content']")
    private WebElement frame2;

    @FindBy(xpath = "//div[@id='menu7']//a[contains(@id,'lnk')]//div")
    private List<WebElement> listaConsultas;

    @FindBy(xpath = "//div[contains(@class,'clsCMOver')]")
    private List<WebElement> listaInformacionProveedor;

    @FindBy(xpath = "//*[@id=\"cmimenu1_4e\"]/a/img")
    private WebElement labelInfoProvee;

    @FindBy(xpath = "//*[@id='content']")
    private WebElement titleFinanciamientoFactoring;

    @FindBy(xpath = "//*[@id='salir']")
    private WebElement btnSalir;

    /***Constants ***/
    private static final String ERROR_1 = "error: ";
    private static final String BOTON_1 = "Boton visualizado";

    //------Metodos------
    public void visualizarBciExpress() {
        String step = "Visualizo la pagina \"BCIExpress\"";
        String descripcion = "Se visualiza correctamente";
        try {
            MetodosGenericos.esperar(10);
            PdfBciReports.addWebReportImage(step, descripcion, EstadoPrueba.PASSED, false);
        } catch (NoSuchElementException e) {
            PdfBciReports.addReport(step, ERROR_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void btnConsultas() {
        String step = "Presiono boton 'Consultas'";
        try {
            DriverContextWeb.getDriverWeb().switchTo().parentFrame();
            DriverContextWeb.getDriverWeb().switchTo().frame(frame1);
            if (visualizarObjeto(btnConsultas, 1)) {
                UtilsWeb.enmarcarObjeto(btnConsultas);
                PdfBciReports.addWebReportImage(step, BOTON_1, EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(btnConsultas);
                btnConsultas.click();
            } else {
                PdfBciReports.addWebReportImage(step, "Boton no visualizado", EstadoPrueba.FAILED, true);
            }

        } catch (NoSuchElementException e) {
            PdfBciReports.addReport(step, ERROR_1 + e.getMessage(), EstadoPrueba.FAILED, true);

        }

    }

    public void clickBtnPagos() {
        MetodosGenericos.imprimerConsolaMsjPositivo("clickBtnPagos");

    }

    public void presionarOpcionInformacionProveedor(String opc1) {
        String step = "Presiono boton " + opc1;
        try {
            DriverContextWeb.getDriverWeb().switchTo().defaultContent();
            DriverContextWeb.getDriverWeb().switchTo().parentFrame();
            DriverContextWeb.getDriverWeb().switchTo().frame(frame2);
            MetodosGenericos.imprimerConsolaMsjPositivo("cant de elementos en la lista: " + listaConsultas.size());
            for (int i = 0; i < listaConsultas.size(); i++) {
                String nombreOpcion = listaConsultas.get(i).getText().trim();
                System.out.println("nombreOpcion: " + nombreOpcion);
                if (nombreOpcion.equals(opc1)) {
                    UtilsWeb.enmarcarObjeto(listaConsultas.get(i));
                    PdfBciReports.addWebReportImage(step, BOTON_1, EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(listaConsultas.get(i));
                    listaConsultas.get(i).click();
                    break;
                } else if (i == listaConsultas.size() - 1) {
                    PdfBciReports.addReport(step, "opcion no visualizada: " + opc1, EstadoPrueba.FAILED, true);
                }
            }
        } catch (NoSuchElementException e) {
            PdfBciReports.addReport(step, ERROR_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void presionarOpcionFinanciamientoFactoring(String opc2) {
        String step = "Presiono boton " + opc2;
        try {
            DriverContextWeb.getDriverWeb().switchTo().defaultContent();
            DriverContextWeb.getDriverWeb().switchTo().parentFrame();
            DriverContextWeb.getDriverWeb().switchTo().frame(frame2);
            if (visualizarObjeto(labelInfoProvee, 2)) {
                UtilsWeb.enmarcarObjeto(labelInfoProvee);
                PdfBciReports.addWebReportImage(step, BOTON_1, EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(labelInfoProvee);
                labelInfoProvee.click();
            } else {
                PdfBciReports.addWebReportImage(step, "Boton no visualizado: " + opc2, EstadoPrueba.FAILED, true);
            }

        } catch (NoSuchElementException e) {
            PdfBciReports.addReport(step, ERROR_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoGrillaNumeroPagadoresConDocumentosPublicados() {
        String step = "Visualizo en la grilla el numero de pagadores con documentos publicados";
        String descripcion = "Se visualiza correctamente";
        try {
            MetodosGenericos.esperar(15);
            PdfBciReports.addWebReportImage(step, descripcion, EstadoPrueba.PASSED, false);
        } catch (NoSuchElementException e) {
            PdfBciReports.addReport(step, ERROR_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void clickBtnFactoringCtaCteProveedor() {
        MetodosGenericos.imprimerConsolaMsjPositivo("clickBtnFactoringCtaCteProveedor");
    }
}