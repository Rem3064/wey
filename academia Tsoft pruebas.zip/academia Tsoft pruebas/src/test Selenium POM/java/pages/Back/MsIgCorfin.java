package pages.Back;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

import static constants.Constants.*;
import static io.restassured.path.json.JsonPath.from;

public class MsIgCorfin {
    private static final String CONTENTTYPE_4 = "application/json";
    private static final String AUTHORIZATION_4 = "Authorization";
    private static final String APPLICATIONID_4 = "Application-Id";
    private static final String ASD_1 = "asd";
    private static final String POSTMAN_4 = "postman";
    private static final String CHANNEL_4 = "Channel";
    private static final String REFERENCESERVICE_4 = "Reference-Service";
    private static final String REFERENCEOPERATION_4 = "Reference-Operation";
    private static final String ORIGINADDR_4 = "Origin-addr";
    private static final String TRACKINGID_4 = "Tracking-id";
    private static final String TRACKINGID = "Tracking-Id";
    private static final String VALOR110 = "110";
    private static final String VALOR_1111 = "1111";
    private static final String VALOR_111 = "111";
    private static final String BEARER = "Bearer";
    private static final String BEARER_1 = "bearer";
    private static final String VALOR650 = "650";
    private static final String SAD = "sad";
    private static final String MENSAJESTATUSCODE = "El codigo de Respuesta: ";
    private static final String MENSAJE_STATUSCODE1 = "Codigo de Respuesta";
    private static final String OBTENER_RESPONSEBODY1 = "Obtener Response body";
    private static final String EXCEPTION_1 = "Exception";
    private static final String ERROR_1 = "error: ";

    public void calcularSpreadyTasaDeNegocio(String servicio) {
        String url2 = url;
        try {
            Response res = RestAssured
                    .given()
                    .contentType(CONTENTTYPE_4)
                    .header(AUTHORIZATION_4, BEARER_1 + " " + token1)
                    .header(APPLICATIONID_4, POSTMAN_4)
                    .header(CHANNEL_4, VALOR110)
                    .header(REFERENCESERVICE_4, POSTMAN_4)
                    .header(REFERENCEOPERATION_4, POSTMAN_4)
                    .header(ORIGINADDR_4, VALOR_1111)
                    .header(TRACKINGID_4, VALOR_1111)
                    .get(url2)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            int statusCode = res.getStatusCode();
            if (statusCode == 200) {
                PdfBciReports.addReport(servicio, "" + url2, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(MENSAJE_STATUSCODE1, MENSAJESTATUSCODE + statusCode, EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport(MENSAJE_STATUSCODE1, MENSAJESTATUSCODE + statusCode, EstadoPrueba.FAILED, true);
            }
            String resBody = res.getBody().asString();
            PdfBciReports.addReport(OBTENER_RESPONSEBODY1, "" + resBody, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            PdfBciReports.addReport(EXCEPTION_1, ERROR_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void peticionGetServicioPublicaciones(String servicio) {
        String url2 = url;
        try {
            Response res = RestAssured
                    .given()
                    .header(AUTHORIZATION_4, BEARER + " " + token1)
                    .contentType(CONTENTTYPE_4)
                    .header(APPLICATIONID_4, ASD_1)
                    .header(CHANNEL_4, VALOR650)
                    .header(REFERENCEOPERATION_4, VALOR_111)
                    .header(REFERENCESERVICE_4, SAD)
                    .header(ORIGINADDR_4, VALOR_111)
                    .header(TRACKINGID, ASD_1)
                    .get(url2)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            String resBody = res.getBody().asString();
            PdfBciReports.addReport(OBTENER_RESPONSEBODY1, resBody, EstadoPrueba.PASSED, false);
            int statusCode = res.getStatusCode();
            if (statusCode == 200) {
                PdfBciReports.addReport(servicio, url2, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(MENSAJE_STATUSCODE1, MENSAJESTATUSCODE + statusCode, EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport(MENSAJE_STATUSCODE1, MENSAJESTATUSCODE + statusCode, EstadoPrueba.FAILED, true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            PdfBciReports.addReport(EXCEPTION_1, ERROR_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void peticionGetServicioProveedores(String servicio) {
        String url2 = url;
        try {
            Response res = RestAssured
                    .given()
                    .header(AUTHORIZATION_4, BEARER + " " + token1)
                    .contentType(CONTENTTYPE_4)
                    .header(APPLICATIONID_4, ASD_1)
                    .header(CHANNEL_4, VALOR650)
                    .header(REFERENCEOPERATION_4, VALOR_111)
                    .header(REFERENCESERVICE_4, SAD)
                    .header(ORIGINADDR_4, VALOR_111)
                    .header(TRACKINGID, ASD_1)
                    .get(url2)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            String responseBody = res.getBody().asString();
            PdfBciReports.addReport(OBTENER_RESPONSEBODY1, "" + responseBody, EstadoPrueba.PASSED, false);
            int statusCode = res.getStatusCode();
            if (statusCode == 200) {
                PdfBciReports.addReport(servicio, "" + url2, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(MENSAJE_STATUSCODE1, MENSAJESTATUSCODE + statusCode, EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport(MENSAJE_STATUSCODE1, MENSAJESTATUSCODE + statusCode, EstadoPrueba.FAILED, true);
            }
            proveedorRut1 = from(responseBody).getString("rut").trim();
            proveedorEstado1 = from(responseBody).getString("estado").trim();
            proveedorRazonSocial1 = from(responseBody).getString("razonSocial").trim();
            MetodosGenericos.imprimerConsolaMsjPositivo(proveedorRut1);
            MetodosGenericos.imprimerConsolaMsjPositivo(proveedorEstado1);
            MetodosGenericos.imprimerConsolaMsjPositivo(proveedorRazonSocial1);
        } catch (Exception e) {
            PdfBciReports.addReport(EXCEPTION_1, ERROR_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            MetodosGenericos.imprimerConsolaMsjPositivoMetodos(servicio);
        }
    }
}