package pages.Back;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

import static constants.Constants.*;
import static constants.ViajeConfirming.*;
import static io.restassured.path.json.JsonPath.from;

public class MSConfirming {
    private static final String CONTENTTYPE_3 = "application/json";
    private static final String AUTHORIZATION_3 = "Authorization";
    private static final String APPLICATIONID_3 = "Application-Id";
    private static final String ASD_1 = "asd";
    private static final String POSTMAN_3 = "postman";
    private static final String CHANNEL_3 = "Channel";
    private static final String REFERENCESERVICE_3 = "Reference-Service";
    private static final String REFERENCEOPERATION_3 = "Reference-Operation";
    private static final String ORIGINADDR_3 = "Origin-addr";
    private static final String TRACKINGID_3 = "Tracking-id";
    private static final String VALOR110 = "110";
    private static final String VALOR_1111 = "1111";
    private static final String VALOR_111 = "111";
    private static final String BEARER = "Bearer";
    private static final String VALOR650 = "650";
    private static final String SAD = "sad";
    private static final String MSJ_PETICION_POST = "Realizo una peticion post al servicio ";

    public void ObtenerDetallePublicacionesProveedor(String servicio) {
        try {
            Response res = RestAssured
                    .given()
                    .contentType(CONTENTTYPE_3)
                    .header(AUTHORIZATION_3, BEARER + " " + token1)
                    .header(APPLICATIONID_3, POSTMAN_3)
                    .header(CHANNEL_3, VALOR110)
                    .header(REFERENCESERVICE_3, POSTMAN_3)
                    .header(REFERENCEOPERATION_3, POSTMAN_3)
                    .header(ORIGINADDR_3, VALOR_1111)
                    .header(TRACKINGID_3, VALOR_1111)
                    .get(url)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            body1 = res.asPrettyString();
            statusCode1 = res.getStatusCode();
            if (statusCode1 == 200) {
                PdfBciReports.addReport(MSJ_PETICION_POST + servicio, "Se realiza correctamente", EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport(MSJ_PETICION_POST + servicio, "error, statusCode: " + statusCode1 + "-" + body1, EstadoPrueba.FAILED, true);
            }
            MetodosGenericos.imprimerConsolaMsjPositivo("ObtenerDetallePublicacionesProveedor StatusCode: " + statusCode1);
            MetodosGenericos.imprimerConsolaMsjPositivo("ObtenerDetallePublicacionesProveedor ResponseBody : " + body1);
        } catch (Exception e) {
            PdfBciReports.addReport("ObtenerDetallePublicacionesProveedor", "ObtenerDetallePublicacionesProveedor Error: " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void ObtenerPublicacionesProveedor(String servicio) {
        try {
            Response res = RestAssured
                    .given()
                    .contentType(CONTENTTYPE_3)
                    .header(AUTHORIZATION_3, BEARER + " " + token1)
                    .header(APPLICATIONID_3, POSTMAN_3)
                    .header(CHANNEL_3, VALOR110)
                    .header(REFERENCESERVICE_3, POSTMAN_3)
                    .header(REFERENCEOPERATION_3, POSTMAN_3)
                    .header(ORIGINADDR_3, VALOR_1111)
                    .header(TRACKINGID_3, VALOR_1111)
                    .get(url)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            body1 = res.asPrettyString();
            statusCode1 = res.getStatusCode();
            if (statusCode1 == 200) {
                PdfBciReports.addReport(MSJ_PETICION_POST + servicio, "Se realiza correctamente", EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport(MSJ_PETICION_POST + servicio, "Login fallido, statusCode: " + statusCode1 + "-" + body1, EstadoPrueba.FAILED, true);
            }
            MetodosGenericos.imprimerConsolaMsjPositivo("ObtenerPublicacionesProveedor StatusCode: " + statusCode1);
            MetodosGenericos.imprimerConsolaMsjPositivo("ObtenerPublicacionesProveedor ResponseBody : " + body1);
            String cod = from(body1).getString("publicaciones.estado.codigo");
            MetodosGenericos.imprimerConsolaMsjPositivo(cod);
            cod = cod.replace("[", "");
            cod = cod.replace("]", "");
            codigo1 = cod;
            MetodosGenericos.imprimerConsolaMsjPositivo(codigo1);
            MetodosGenericos.imprimerConsolaMsjPositivo("****--------****");
            String msj = from(body1).getString("publicaciones.estado.mensaje");
            MetodosGenericos.imprimerConsolaMsjPositivo(msj);
            msj = msj.replace("[", "");
            msj = msj.replace("]", "");
            mensaje1 = msj;
            MetodosGenericos.imprimerConsolaMsjPositivo(msj);
        } catch (Exception e) {
            PdfBciReports.addReport("ObtenerPublicacionesProveedor", "ObtenerPublicacionesProveedor Error: " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void obtenerConfiguracionProveedor(String servicio) {
        try {
            Response res = RestAssured
                    .given()
                    .contentType(CONTENTTYPE_3)
                    .header(AUTHORIZATION_3, BEARER + " " + token1)
                    .header(APPLICATIONID_3, POSTMAN_3)
                    .header(CHANNEL_3, VALOR110)
                    .header(REFERENCESERVICE_3, POSTMAN_3)
                    .header(REFERENCEOPERATION_3, POSTMAN_3)
                    .header(ORIGINADDR_3, VALOR_1111)
                    .header(TRACKINGID_3, VALOR_1111)
                    .get(url)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            body1 = res.asPrettyString();
            statusCode1 = res.getStatusCode();
            if (statusCode1 == 200) {
                PdfBciReports.addReport(MSJ_PETICION_POST + servicio, "Se realiza correctamente", EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport(MSJ_PETICION_POST + servicio, "Login fallido, statusCode: " + statusCode1 + "-" + body1, EstadoPrueba.FAILED, true);
            }
            MetodosGenericos.imprimerConsolaMsjPositivo("obtenerConfiguracionProveedor StatusCode: " + statusCode1);
            MetodosGenericos.imprimerConsolaMsjPositivo("obtenerConfiguracionProveedor ResponseBody : " + body1);
        } catch (Exception e) {
            PdfBciReports.addReport("obtenerConfiguracionProveedor", "obtenerConfiguracionProveedor Error: " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void estadoProveedor() {
        try {
            Response res = RestAssured
                    .given()
                    .header(AUTHORIZATION_3, BEARER + " " + token1)
                    .contentType(CONTENTTYPE_3)
                    .header(APPLICATIONID_3, ASD_1)
                    .header(CHANNEL_3, VALOR650)
                    .header(REFERENCEOPERATION_3, VALOR_111)
                    .header(REFERENCESERVICE_3, SAD)
                    .header(ORIGINADDR_3, VALOR_111)
                    .header(TRACKINGID_3, ASD_1)
                    .get(url)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            String body = res.asString();
            statusCode1 = res.getStatusCode();
            MetodosGenericos.imprimerConsolaMsjPositivo("estadoProveedor StatusCode: " + statusCode1);
            MetodosGenericos.imprimerConsolaMsjPositivo("estadoProveedor ResponseBody: " + body);
            codigo1 = from(body).getString("codigo").trim();
            mensaje1 = from(body).getString("mensaje").trim();
            MetodosGenericos.imprimerConsolaMsjPositivo("codigo: " + codigo1);
            MetodosGenericos.imprimerConsolaMsjPositivo("mensaje: " + mensaje1);
        } catch (Exception e) {
            PdfBciReports.addReport("estadoProveedor", "estadoProveedor Error: " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void publicacionesMSdeEXPyNEG() {
        try {
            Response res = RestAssured
                    .given()
                    .header(AUTHORIZATION_3, BEARER + " " + token1)
                    .contentType(CONTENTTYPE_3)
                    .header(APPLICATIONID_3, ASD_1)
                    .header(CHANNEL_3, VALOR650)
                    .header(REFERENCEOPERATION_3, VALOR_111)
                    .header(REFERENCESERVICE_3, SAD)
                    .header(ORIGINADDR_3, VALOR_111)
                    .header(TRACKINGID_3, ASD_1)
                    .get(url)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            String body = res.getBody().asPrettyString();
            statusCode2 = res.getStatusCode();
            if (statusCode2 == 200) {
                MetodosGenericos.imprimerConsolaMsjPositivo("publicacionesMSEXP statusCode: " + statusCode2);
                MetodosGenericos.imprimerConsolaMsjPositivo("publicacionesMSEXP ResponseBody: " + body);
            } else {
                PdfBciReports.addReport("publicaciones MSEXP statusCode: " + statusCode2, "publicaciones MSEXP Response Body: " + body, EstadoPrueba.FAILED, true);
            }
            PdfBciReports.addReport("StatusCode", "" + statusCode2, EstadoPrueba.PASSED, false);
            PdfBciReports.addReport("ResponseBody", "" + body, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            PdfBciReports.addReport("publicacionesMSEXP", "publicacionesMSEXP Error: " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }
}