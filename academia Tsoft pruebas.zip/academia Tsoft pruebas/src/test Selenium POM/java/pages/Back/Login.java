package pages.Back;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

import static constants.Constants.*;

import static io.restassured.path.json.JsonPath.from;
import static utils.FeatureControlled.*;

public class Login {

    private static final String ACCEPT_1 = "Accept";
    private static final String APPLIJSON_1 = "application/json";
    private static final String CONTENTTYPE_1 = "application/x-www-form-urlencoded";
    private static final String AUTHORIZATION_1 = "Authorization";
    private static final String BASIC_1 = "Basic YXBwLXNpc3RlbWFDb2RlbGNvOnNuWXh1SkRuQkdjaFJwNGU=";
    private static final String APPLICATIONID_1 = "Application-Id";
    private static final String POSTMAN_1 = "postman";
    private static final String CHANNEL_1 = "Channel";
    private static final String REFERENCESERVICE_1 = "Reference-Service";
    private static final String REFERENCEOPERATION_1 = "Reference-Operation";
    private static final String ORIGINADDR_1 = "Origin-addr";
    private static final String TRACKINGID_1 = "Tracking-id";
    private static final String VALOR_1 = "1111";
    private static final String RUTLOGIN_1 = "&rut=";
    private static final String GRANDTYPELOGIN_1 = "&grant_type=";
    private static final String ACCESSTOKEN_1 = "access_token";

    public void loginNuevoViajeCRT(String servicio) {
        MetodosGenericos.imprimerConsolaMsjPositivoMetodos(servicio);
        try {
            Response res = RestAssured
                    .given()
                    .header(ACCEPT_1, APPLIJSON_1)
                    .contentType(CONTENTTYPE_1)
                    .header(AUTHORIZATION_1, BASIC_1)
                    .header(APPLICATIONID_1, POSTMAN_1)
                    .header(CHANNEL_1, POSTMAN_1)
                    .header(REFERENCESERVICE_1, POSTMAN_1)
                    .header(REFERENCEOPERATION_1, POSTMAN_1)
                    .header(ORIGINADDR_1, VALOR_1)
                    .header(TRACKINGID_1, VALOR_1)
                    .body(GRANDTYPELOGIN_1 + grandType1 + RUTLOGIN_1 + rut1)
                    .post(url)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            int statusCode = res.getStatusCode();
            if (statusCode == 200) {
                PdfBciReports.addReport("Realizo una peticion post al servicio " + servicio, "Se realiza correctamente", EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport("Realizo una peticion post al servicio " + servicio, "Login fallido, statusCode: " + statusCode, EstadoPrueba.FAILED, true);
            }
            String body = res.asString();
            token1 = from(body).get(ACCESSTOKEN_1);
            MetodosGenericos.imprimerConsolaMsjPositivo("Obtener Valor del AccessToken: " + token1);
        } catch (Exception e) {
            PdfBciReports.addReport("loginNuevoViajeCRT", "error loginNuevoViajeCRT: " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void loginClientes(String servicio) {
        MetodosGenericos.imprimerConsolaMsjPositivoMetodos("loginClientes");
        try {
            Response res = RestAssured
                    .given()
                    .header(ACCEPT_1, APPLIJSON_1)
                    .contentType(CONTENTTYPE_1)
                    .header(AUTHORIZATION_1, BASIC_1)
                    .header(APPLICATIONID_1, POSTMAN_1)
                    .header(CHANNEL_1, POSTMAN_1)
                    .header(REFERENCESERVICE_1, POSTMAN_1)
                    .header(REFERENCEOPERATION_1, POSTMAN_1)
                    .header(ORIGINADDR_1, VALOR_1)
                    .header(TRACKINGID_1, VALOR_1)
                    .body(GRANDTYPELOGIN_1 + grandType2 + RUTLOGIN_1 + rut1)
                    .post(url)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            int statusCode = res.getStatusCode();
            if (statusCode == 200) {
                PdfBciReports.addReport(servicio, "Se setea la URL del MS Login Clientes: " + url, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport("Codigo de Respuesta de MS Login Clientes", "" + statusCode, EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport("Codigo de Respuesta de MS Login Clientes", "" + statusCode, EstadoPrueba.FAILED, true);
            }
            String body = res.asString();
            token1 = from(body).get(ACCESSTOKEN_1);
            PdfBciReports.addReport("Obtener valor del access_token", "El valor obtenido del access_token es: " + token1, EstadoPrueba.PASSED, false);
            numTrans1 = from(body).get("jti");
            PdfBciReports.addReport("Obtener Valor del Jti", "El valor obtenido del Jti es: " + numTrans1, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            PdfBciReports.addReport("loginClientes", "error loginClientes: " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }

    public void login() {
        try {
            Response res = RestAssured
                    .given()
                    .header(ACCEPT_1, APPLIJSON_1)
                    .contentType(CONTENTTYPE_1)
                    .header(AUTHORIZATION_1, BASIC_1)
                    .header(APPLICATIONID_1, POSTMAN_1)
                    .header(CHANNEL_1, POSTMAN_1)
                    .header(REFERENCESERVICE_1, POSTMAN_1)
                    .header(REFERENCEOPERATION_1, POSTMAN_1)
                    .header(ORIGINADDR_1, VALOR_1)
                    .header(TRACKINGID_1, VALOR_1)
                    .body("&password=" + password1 + GRANDTYPELOGIN_1 + grandType1 + RUTLOGIN_1 + rut1)
                    .post(url)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            String body = res.asString();
            statusCode1 = res.getStatusCode();
            if (statusCode1 == 200) {
                PdfBciReports.addReport(step, "Se realiza correctamente", EstadoPrueba.PASSED, false);
                MetodosGenericos.imprimerConsolaMsjPositivo("statusCode: " + statusCode1);
            } else {
                PdfBciReports.addReport("StatusCode de servicio Login: " + statusCode1, "ResponseBody: " + body, EstadoPrueba.FAILED, true);
            }
            MetodosGenericos.imprimerConsolaMsjPositivo("ResponseBody: " + body);
            token1 = from(body).get(ACCESSTOKEN_1);
            MetodosGenericos.imprimerConsolaMsjPositivo("access_token: " + token1);
            numTrans1 = from(body).get("jti");
            MetodosGenericos.imprimerConsolaMsjPositivo("jti: " + numTrans1);
        } catch (Exception e) {
            PdfBciReports.addReport("login", "error login: " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }
}