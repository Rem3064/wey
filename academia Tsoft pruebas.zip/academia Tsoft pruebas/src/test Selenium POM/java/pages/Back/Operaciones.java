package pages.Back;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

import static constants.Constants.*;
import static io.restassured.path.json.JsonPath.from;

public class Operaciones {

    private static final String CONTENTTYPE_5 = "application/json";
    private static final String AUTHORIZATION_5 = "Authorization";
    private static final String APPLICATIONID_5 = "Application-Id";
    private static final String POSTMAN_5 = "postman";
    private static final String CHANNEL_5 = "Channel";
    private static final String REFERENCESERVICE_5 = "Reference-Service";
    private static final String REFERENCEOPERATION_5 = "Reference-Operation";
    private static final String ORIGINADDR_5 = "Origin-addr";
    private static final String TRACKINGID_5 = "Tracking-id";
    private static final String VALOR110 = "110";
    private static final String VALOR_1111 = "1111";
    private static final String BEARER_1 = "bearer";
    private static final String ERROR_1 = "error: ";
    private static final String CODIGOMS_1 = "Codigo de Respuesta de MS Operaciones";
    public void operaciones() {
        String url2 = url;
        try {
            Response res = RestAssured
                    .given()
                    .contentType(CONTENTTYPE_5)
                    .header(AUTHORIZATION_5, BEARER_1 + " " + token1)
                    .header(APPLICATIONID_5, POSTMAN_5)
                    .header(CHANNEL_5, VALOR110)
                    .header(REFERENCESERVICE_5, POSTMAN_5)
                    .header(REFERENCEOPERATION_5, POSTMAN_5)
                    .header(ORIGINADDR_5, VALOR_1111)
                    .header(TRACKINGID_5, VALOR_1111)
                    .body(body1)
                    .post(url2)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            int statusCode = res.getStatusCode();
            if (statusCode == 200) {
                PdfBciReports.addReport(CODIGOMS_1, "" + statusCode, EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport(CODIGOMS_1, "" + statusCode, EstadoPrueba.FAILED, true);
            }
            String body2 = res.getBody().asString();
            num_operacion = from(body2).getInt("Encabezado.numero_operacion");
            num_transaccion = from(body2).getString("Encabezado.numero_transaccion");
            id_pagador = from(body2).getInt("Encabezado.id_pagador");
        } catch (Exception e) {
            PdfBciReports.addReport("operaciones", ERROR_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }
}