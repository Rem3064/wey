package pages.Back;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

import static constants.Constants.*;

public class MSApiKey {

    private static final String CONTENTTYPE_2 = "application/json";
    private static final String AUTHORIZATION_2 = "Authorization";
    private static final String APPLICATIONID_2 = "Application-Id";
    private static final String POSTMAN_2 = "postman";
    private static final String CHANNEL_2 = "Channel";
    private static final String REFERENCESERVICE_2 = "Reference-Service";
    private static final String REFERENCEOPERATION_2 = "Reference-Operation";
    private static final String ORIGINADDR_2 = "Origin-addr";
    private static final String TRACKINGID_2 = "Tracking-id";
    private static final String VALOR110 = "110";
    private static final String VALOR_2 = "1111";
    private static final String BEARER = "Bearer";

    public void actualizarOperacion() {
        String url2 = url;
        MetodosGenericos.imprimerConsolaMsjPositivoMetodos("actualizarOperacion");
        PdfBciReports.addReport("URL del MS actualizar Operacion", "Se setea la URL del MS actualizar Operacion: " + url2, EstadoPrueba.PASSED, false);
        try {
            Response res = RestAssured
                    .given()
                    .contentType(CONTENTTYPE_2)
                    .header(AUTHORIZATION_2, BEARER + " " + token1)
                    .header(APPLICATIONID_2, POSTMAN_2)
                    .header(CHANNEL_2, VALOR110)
                    .header(REFERENCESERVICE_2, POSTMAN_2)
                    .header(REFERENCEOPERATION_2, POSTMAN_2)
                    .header(ORIGINADDR_2, VALOR_2)
                    .header(TRACKINGID_2, VALOR_2)
                    .body(jsonAsociado)
                    .put(url2)
                    .then()
                    .extract()
                    .response();
            res.getStatusCode();
            int statusCode = res.getStatusCode();
            if (statusCode == 200) {
                PdfBciReports.addReport("Realizo una peticion put al servicio Actualizar operacion", "Se realiza la peticion correctamente" + statusCode, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport("Código de Respuesta de MS Actualizar operacion", "El código de Respuesta de MS Actualizar operacion: " + statusCode, EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport("Realizo una peticion put al servicio Actualizar operacion", "peticion put fallida, favor revisar" + statusCode, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport("Código de Respuesta de MS Actualizar operacion", "El código de Respuesta de MS Actualizar operacion: " + statusCode, EstadoPrueba.FAILED, true);
            }
        } catch (Exception e) {
            PdfBciReports.addReport("actualizarOperacion", "error actualizarOperacion: " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
    }
}