package pages.bd;

import dataSources.ConexionAzureSql2;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SqlConsulta2 {
    private static final String queryProveedorNoExiste = "SELECT id_proveedor, rut_proveedor, razon_social_proveedor, estado_proveedor, fec_ingreso\n" +
            "FROM bcirg3crtfacconf001.dbo.prv_proveedor\n" +
            "WHERE rut_proveedor = 000052010334";
    private static final String queryProveedorExiste = "SELECT id_proveedor, rut_proveedor, razon_social_proveedor, estado_proveedor, fec_ingreso\n" +
            "FROM bcirg3crtfacconf001.dbo.prv_proveedor\n" +
            "WHERE rut_proveedor = 000052010331";
    private static final String PROVEEDORSI = "proveedorExiste";
    private static final String PROVEEDORNO = "proveedorNoExiste";

    public void proveedorNoExiste() throws SQLException {
        Connection con = ConexionAzureSql2.getConnection3();
        try (Statement stmt = con.createStatement()) {
            ResultSet rs = stmt.executeQuery(queryProveedorNoExiste);
            MetodosGenericos.imprimerConsolaMsjPositivoMetodos(queryProveedorNoExiste);
            while (rs.next()) {
                PdfBciReports.addReport(PROVEEDORNO, String.valueOf(rs), EstadoPrueba.PASSED, false);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
            PdfBciReports.addReport(PROVEEDORNO, e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }

    public void proveedorExiste() throws SQLException {
        Connection con = ConexionAzureSql2.getConnection3();
        try (Statement stmt = con.createStatement()) {
            ResultSet rs = stmt.executeQuery(queryProveedorExiste);
            while (rs.next()) {
                PdfBciReports.addReport(PROVEEDORSI, String.valueOf(rs), EstadoPrueba.PASSED, false);
            }
            rs.close();
        } catch (SQLException e) {
            PdfBciReports.addReport(PROVEEDORSI, e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }
}