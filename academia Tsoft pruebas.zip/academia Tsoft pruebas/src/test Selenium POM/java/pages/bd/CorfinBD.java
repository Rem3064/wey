package pages.bd;

import dataSources.ConexionBDCorfin;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static constants.Constants.*;
import static constants.QuerysConfirming.*;
import static constants.ViajeConfirming.*;

public class CorfinBD {

    private static final String BDCORFIN_1 = "BDCorfin";
    private static final String MENSAJERRORBDCORFIN_1 = "[BDCorfin] Error de SQl, se detiene prueba: ";
    private static final String SPREAD = "spread";
    private static final String TASANEGOCIO = "tasa_negocio";
    private static final String VALOR_1 = "se obtiene el valor: ";
    private static final String PVR_RUT = "pvr_rut";
    private static final String PAR_COD = "par_cod";
    private static final String PAR_DES = "par_des";
    private static final String RUT_EMPRESA = "rut_empresa";
    private static final String DIG_VERIF_EMPRESA = "dig_verif_empresa";
    private static final String RUT_PROVEE = "rut_proveedor";
    private static final String EMPRESA = "empresa";
    private static final String VALORTASA = "valor_tasa";
    private static final String MONTO_PUBLI = "monto_publicado";
    private static final String CANT_DOCU = "cantidad_documento";
    private static final String VRT_EMPRESA = "vrt_empresa";
    private static final String RAZON_SOCIAL_EMPRESA = "rzn_social_empresa";
    private static final String VRT_PROVEE = "vrt_proveedor";
    private static final String RAZON_SOCIAL_PROVEE = "rzn_social_proveedor";
    private static final String GRUPO = "grupo";
    private static final String MONTO_GRUPO = "monto_grupo";
    private static final String NUM_FOL = "num_fol";
    private static final String NUM_DOC = "num_doc";
    private static final String FECHA_PAGO = "fecha_pago";
    private static final String TIPO_DOCU = "tipo_documento";
    private static final String TASA_BASE = "tasa_base";
    private static final String TASA_BASE_MODIFICADA = "tasa_base_modificada";
    private static final String PLAZO_MINIMO = "plazo_minimo";
    private static final String PLAZO_MAXIMO = "plazo_maximo";
    private static final String MONTO_MINIMO = "monto_minimo";
    private static final String FORMAT_STRING = "%,.0f";

    /**
     * CONSULTAS BD-SQL
     **/

    public void devuelveMontoDisponiblePlazoMinimoPlazoMaximoMontoMinimoPagador() throws SQLException {
        Connection con = ConexionBDCorfin.getConnection2();
        try {
            Statement stmt = con.createStatement();
            String query = "select (ISNULL(S.sbl_mto,0) - ISNULL((SELECT SUM(J.doc_sdo_gpg) FROM doc J\n" +
                    "INNER JOIN opc O ON O.opc_num_cfg = J.opc_num\n" +
                    "WHERE J.gpg_rut = S.gpg_rut\n" +
                    "AND   J.par_est IN(1,2)\n" +
                    "AND   O.par_est = 6),0)) as monto_disponible,\n" +
                    "ISNULL(S.sbl_pla_min,0) as plazo_minimo,\n" +
                    "ISNULL(S.sbl_pla_max,0) as plazo_maximo,\n" +
                    "ISNULL(S.sbl_mto_min,0) as monto_minimo\n" +
                    "from sbl S where S.gpg_rut = '000096844080'";

            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                montoDisponible1 = String.valueOf(rs.getDouble("monto_disponible"));
                double mto = Double.parseDouble(montoDisponible1);
                montoDisponible1 = String.format(FORMAT_STRING, mto);
                plazo_minimo2 = Integer.valueOf(rs.getString(PLAZO_MINIMO));
                plazo_maximo2 = Integer.valueOf(rs.getString(PLAZO_MAXIMO));
                monto_minimo2 = Integer.valueOf(rs.getString(MONTO_MINIMO));
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            PdfBciReports.addReport(BDCORFIN_1, e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }

    public void obtenerTipoGenericoString() throws SQLException {
        Connection con = ConexionBDCorfin.getConnection2();
        try (Statement stmt = con.createStatement()) {
            String query = SP1;
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                StringBuilder resultadoprint = new StringBuilder();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    String nombreColumna = rs.getMetaData().getColumnName(i);
                    String datoColumna = rs.getString(i);
                    resultadoprint.append(nombreColumna).append(":").append(datoColumna).append("\n");
                }
                MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(resultadoprint));
                PdfBciReports.addReport("Resultado de la query: " + query, resultadoprint.toString(), EstadoPrueba.PASSED, false);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            PdfBciReports.addReport(BDCORFIN_1, e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }

    public void obtenerTipoGenericoParPagadorProveedor() throws SQLException {
        Connection con = ConexionBDCorfin.getConnection2();
        try (Statement stmt = con.createStatement()) {
            String query = QUERY1;
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                StringBuilder resultadoprint = new StringBuilder();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    String nombreColumna = rs.getMetaData().getColumnName(i);
                    String datoColumna = rs.getString(i);
                    resultadoprint.append(nombreColumna).append(":").append(datoColumna).append("\n");
                }
                MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(resultadoprint));
                PdfBciReports.addReport("Resultado de la query: " + query, resultadoprint.toString(), EstadoPrueba.PASSED, false);
            }
            rs.close();
        } catch (
                SQLException e) {
            PdfBciReports.addReport(BDCORFIN_1, e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }

    public void consultarProveedor2() throws SQLException {
        Connection con = ConexionBDCorfin.getConnection2();
        try (Statement stmt = con.createStatement()) {
            String query = "SELECT a.pvr_rut, b.par_cod, b.par_des FROM corfin.dbo.pvr a, par b where pvr_rut = '000052010332' AND b.par_tab = 5 AND a.par_est_pvr = b.par_cod";

            ResultSet rs = stmt.executeQuery(query);
            PdfBciReports.addReport("Consulta DataBase cgalileo_iii --> corfin", "Se realizo la siguiente consulta: " + query, EstadoPrueba.PASSED, false);
            while (rs.next()) {
                PdfBciReports.addReport(PVR_RUT, VALOR_1 + rs.getString(PVR_RUT).trim(), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(PAR_COD, VALOR_1 + rs.getString(PAR_COD).trim(), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(PAR_DES, VALOR_1 + rs.getString(PAR_DES).trim(), EstadoPrueba.PASSED, false);
                par_des = rs.getString(PAR_DES).trim();
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            PdfBciReports.addReport(BDCORFIN_1, MENSAJERRORBDCORFIN_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }

    public void consultarProveedor1() throws SQLException {
        Connection con = ConexionBDCorfin.getConnection2();
        try (Statement stmt = con.createStatement()) {
            String query = "SELECT a.pvr_rut, b.par_cod, b.par_des FROM corfin.dbo.pvr a, par b where pvr_rut = '000052010331' AND b.par_tab = 5 AND a.par_est_pvr = b.par_cod";

            ResultSet rs = stmt.executeQuery(query);
            PdfBciReports.addReport("ejecuto la query Consultar Provvedor", "" + query, EstadoPrueba.PASSED, false);
            while (rs.next()) {
                PdfBciReports.addReport(PVR_RUT, VALOR_1 + rs.getString(PVR_RUT).trim(), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(PAR_COD, VALOR_1 + rs.getString(PAR_COD).trim(), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(PAR_DES, VALOR_1 + rs.getString(PAR_DES).trim(), EstadoPrueba.PASSED, false);
                par_des = rs.getString(PAR_DES).trim();
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            PdfBciReports.addReport(BDCORFIN_1, MENSAJERRORBDCORFIN_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }

    public void execSpNvDevuelvePublicacionesProveedorPortal1() throws SQLException {
        Connection con = ConexionBDCorfin.getConnection2();
        try (Statement stmt = con.createStatement()) {
            String query = "exec sp_nv_devuelve_publicaciones_proveedor_portal '52010334','1' ";

            ResultSet rs = stmt.executeQuery(query);
            PdfBciReports.addReport("Ejecuto SP", "" + query, EstadoPrueba.PASSED, false);
            while (rs.next()) {
                PdfBciReports.addReport(RUT_EMPRESA, VALOR_1 + rs.getString(RUT_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(DIG_VERIF_EMPRESA, VALOR_1 + rs.getString(DIG_VERIF_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RUT_PROVEE, VALOR_1 + rs.getString(RUT_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(EMPRESA, VALOR_1 + rs.getString(EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(VALORTASA, VALOR_1 + rs.getString(VALORTASA), EstadoPrueba.PASSED, false);
                int num = rs.getInt(MONTO_PUBLI);
                String resultado = String.format("%,d", num);
                PdfBciReports.addReport(MONTO_PUBLI, VALOR_1 + resultado, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(CANT_DOCU, VALOR_1 + rs.getString(CANT_DOCU), EstadoPrueba.PASSED, false);
            }
            rs.close();
        } catch (SQLException e) {
            PdfBciReports.addReport(BDCORFIN_1, MENSAJERRORBDCORFIN_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }

    public void execSpNvDevuelveDetallePublicacionesProveedorPortal1() throws SQLException {
        Connection con = ConexionBDCorfin.getConnection2();
        try (Statement stmt = con.createStatement()) {
            String query = "exec sp_nv_devuelve_detalle_publicacion_proveedor_portal '52010334','1','96500950','7' ";

            ResultSet rs = stmt.executeQuery(query);
            PdfBciReports.addReport("ejecuto SP Devuelve Detalle Publicaciones Proveedor Portal", "" + query, EstadoPrueba.PASSED, false);
            while (rs.next()) {
                PdfBciReports.addReport(RUT_EMPRESA, VALOR_1 + rs.getString(RUT_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(VRT_EMPRESA, VALOR_1 + rs.getString(VRT_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RAZON_SOCIAL_EMPRESA, VALOR_1 + rs.getString(RAZON_SOCIAL_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RUT_PROVEE, VALOR_1 + rs.getString(RUT_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(VRT_PROVEE, VALOR_1 + rs.getString(VRT_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RAZON_SOCIAL_PROVEE, VALOR_1 + rs.getString(RAZON_SOCIAL_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(GRUPO, VALOR_1 + rs.getString(GRUPO), EstadoPrueba.PASSED, false);
                int num1 = rs.getInt(MONTO_GRUPO);
                String resultado1 = String.format("%,d", num1);
                PdfBciReports.addReport(MONTO_GRUPO, VALOR_1 + resultado1, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(NUM_FOL, VALOR_1 + rs.getString(NUM_FOL), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(NUM_DOC, VALOR_1 + rs.getString(NUM_DOC), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(FECHA_PAGO, VALOR_1 + rs.getString(FECHA_PAGO), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TIPO_DOCU, VALOR_1 + rs.getString(TIPO_DOCU), EstadoPrueba.PASSED, false);
                int num2 = rs.getInt(MONTO_PUBLI);
                String resultado2 = String.format("%,d", num2);
                PdfBciReports.addReport(MONTO_PUBLI, VALOR_1 + resultado2, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TASANEGOCIO, VALOR_1 + rs.getString(TASANEGOCIO), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(SPREAD, VALOR_1 + rs.getString(SPREAD), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TASA_BASE, VALOR_1 + rs.getString(TASA_BASE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TASA_BASE_MODIFICADA, VALOR_1 + rs.getString(TASA_BASE_MODIFICADA), EstadoPrueba.PASSED, false);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            PdfBciReports.addReport(BDCORFIN_1, MENSAJERRORBDCORFIN_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }

    public void generarSpResumenPublicacionesPagadorActivoTasaNegocioParaProveedorPublicacionesPortalProveedores() throws SQLException {
        Connection con = ConexionBDCorfin.getConnection2();
        try (Statement stmt = con.createStatement()) {
            String query = "exec sp_nv_devuelve_publicaciones_proveedor_portal '52010334','1' ";

            ResultSet rs = stmt.executeQuery(query);
            PdfBciReports.addReport("ejecuto la query sql para generar resumen de publicaciones", "" + query, EstadoPrueba.PASSED, false);
            while (rs.next()) {
                PdfBciReports.addReport(RUT_EMPRESA, VALOR_1 + rs.getString(RUT_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(DIG_VERIF_EMPRESA, VALOR_1 + rs.getString(DIG_VERIF_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RUT_PROVEE, VALOR_1 + rs.getString(RUT_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(EMPRESA, VALOR_1 + rs.getString(EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(VALORTASA, VALOR_1 + rs.getString(VALORTASA), EstadoPrueba.PASSED, false);
                int num = rs.getInt(MONTO_PUBLI);
                String resultado = String.format("%,d", num);
                PdfBciReports.addReport(MONTO_PUBLI, VALOR_1 + resultado, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(CANT_DOCU, VALOR_1 + rs.getString(CANT_DOCU), EstadoPrueba.PASSED, false);
            }
        } catch (SQLException e) {
            PdfBciReports.addReport(BDCORFIN_1, MENSAJERRORBDCORFIN_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }

    public void GenerarSpDetallePublicacionesPagadorActivoTasaNegocioParaProveedorPublicacionesPortalProveedores() throws SQLException {
        Connection con = ConexionBDCorfin.getConnection2();
        try (Statement stmt = con.createStatement()) {
            String query = "exec sp_nv_devuelve_detalle_publicacion_proveedor_portal '52010334','1','56065975','K' ";

            ResultSet rs = stmt.executeQuery(query);
            PdfBciReports.addReport("ejecuto la query sql para generar detalle de publicaciones", "" + query, EstadoPrueba.PASSED, false);
            while (rs.next()) {
                PdfBciReports.addReport(RUT_EMPRESA, VALOR_1 + rs.getString(RUT_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(VRT_EMPRESA, VALOR_1 + rs.getString(VRT_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RAZON_SOCIAL_EMPRESA, VALOR_1 + rs.getString(RAZON_SOCIAL_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RUT_PROVEE, VALOR_1 + rs.getString(RUT_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(VRT_PROVEE, VALOR_1 + rs.getString(VRT_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RAZON_SOCIAL_PROVEE, VALOR_1 + rs.getString(RAZON_SOCIAL_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(GRUPO, VALOR_1 + rs.getString(GRUPO), EstadoPrueba.PASSED, false);
                int num1 = rs.getInt(MONTO_GRUPO);
                String resultado1 = String.format("%,d", num1);
                PdfBciReports.addReport(MONTO_GRUPO, VALOR_1 + resultado1, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(NUM_FOL, VALOR_1 + rs.getString(NUM_FOL), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(NUM_DOC, VALOR_1 + rs.getString(NUM_DOC), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(FECHA_PAGO, VALOR_1 + rs.getString(FECHA_PAGO), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TIPO_DOCU, VALOR_1 + rs.getString(TIPO_DOCU), EstadoPrueba.PASSED, false);
                int num2 = rs.getInt(MONTO_PUBLI);
                String resultado2 = String.format("%,d", num2);
                PdfBciReports.addReport(MONTO_PUBLI, VALOR_1 + resultado2, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TASANEGOCIO, VALOR_1 + rs.getString(TASANEGOCIO), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(SPREAD, VALOR_1 + rs.getString(SPREAD), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TASA_BASE, VALOR_1 + rs.getString(TASA_BASE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TASA_BASE_MODIFICADA, VALOR_1 + rs.getString(TASA_BASE_MODIFICADA), EstadoPrueba.PASSED, false);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            PdfBciReports.addReport(BDCORFIN_1, MENSAJERRORBDCORFIN_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }

    public void GenerarSpResumenPublicacionesPagadorActivoSpreadParaProveedorPublicacionesPortalProveedores() throws SQLException {
        Connection con = ConexionBDCorfin.getConnection2();
        try (Statement stmt = con.createStatement()) {
            String query = "exec sp_nv_devuelve_publicaciones_proveedor_portal'52010693','6'";

            ResultSet rs = stmt.executeQuery(query);
            PdfBciReports.addReport("ejecuto la query sql para generar resumen de publicaciones", "" + query, EstadoPrueba.PASSED, false);
            while (rs.next()) {
                PdfBciReports.addReport(RUT_EMPRESA, VALOR_1 + rs.getString(RUT_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(DIG_VERIF_EMPRESA, VALOR_1 + rs.getString(DIG_VERIF_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RUT_PROVEE, VALOR_1 + rs.getString(RUT_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(EMPRESA, VALOR_1 + rs.getString(EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(VALORTASA, VALOR_1 + rs.getString(VALORTASA), EstadoPrueba.PASSED, false);
                int num = rs.getInt(MONTO_PUBLI);
                String resultado = String.format("%,d", num);
                PdfBciReports.addReport(MONTO_PUBLI, VALOR_1 + resultado, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(CANT_DOCU, VALOR_1 + rs.getString(CANT_DOCU), EstadoPrueba.PASSED, false);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            PdfBciReports.addReport(BDCORFIN_1, MENSAJERRORBDCORFIN_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }

    public void GenerarSpDetallePublicacionesPagadorActivoSpreadParaProveedorPublicacionesPortalProveedores() throws SQLException {
        Connection con = ConexionBDCorfin.getConnection2();
        try (Statement stmt = con.createStatement()) {
            String query = "exec sp_nv_devuelve_detalle_publicacion_proveedor_portal'52010693','6','96844080','2'";

            ResultSet rs = stmt.executeQuery(query);
            PdfBciReports.addReport("ejecuto la query sql para generar detalle de publicaciones", "Se realizo la siguiente consulta: " + query, EstadoPrueba.PASSED, false);
            while (rs.next()) {
                PdfBciReports.addReport(RUT_EMPRESA, VALOR_1 + rs.getString(RUT_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(VRT_EMPRESA, VALOR_1 + rs.getString(VRT_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RAZON_SOCIAL_EMPRESA, VALOR_1 + rs.getString(RAZON_SOCIAL_EMPRESA), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RUT_PROVEE, VALOR_1 + rs.getString(RUT_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(VRT_PROVEE, VALOR_1 + rs.getString(VRT_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(RAZON_SOCIAL_PROVEE, VALOR_1 + rs.getString(RAZON_SOCIAL_PROVEE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(GRUPO, VALOR_1 + rs.getString(GRUPO), EstadoPrueba.PASSED, false);
                int num3 = rs.getInt(MONTO_GRUPO);
                String resultado3 = String.format("%,d", num3);
                PdfBciReports.addReport(MONTO_GRUPO, VALOR_1 + resultado3, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(NUM_FOL, VALOR_1 + rs.getString(NUM_FOL), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(NUM_DOC, VALOR_1 + rs.getString(NUM_DOC), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(FECHA_PAGO, VALOR_1 + rs.getString(FECHA_PAGO), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TIPO_DOCU, VALOR_1 + rs.getString(TIPO_DOCU), EstadoPrueba.PASSED, false);
                int num4 = rs.getInt(MONTO_PUBLI);
                String resultado4 = String.format("%,d", num4);
                PdfBciReports.addReport(MONTO_PUBLI, VALOR_1 + resultado4, EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TASANEGOCIO, VALOR_1 + rs.getString(TASANEGOCIO), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(SPREAD, VALOR_1 + rs.getString(SPREAD), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TASA_BASE, VALOR_1 + rs.getString(TASA_BASE), EstadoPrueba.PASSED, false);
                PdfBciReports.addReport(TASA_BASE_MODIFICADA, VALOR_1 + rs.getString(TASA_BASE_MODIFICADA).substring(0, 3), EstadoPrueba.PASSED, false);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            PdfBciReports.addReport(BDCORFIN_1, MENSAJERRORBDCORFIN_1 + e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            con.createStatement().close();
        }
    }
}