package dataSources;

import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;
import utils.ReadProperties;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConexionBDCorfin {

    private ConexionBDCorfin() {
        throw new IllegalStateException("Utility class");
    }

    public static Connection getConnection2() {
        Properties properties = ReadProperties.readFromConfig("bdGalileoIII.properties");
        String url = properties.getProperty("hostQA");
        String usr = properties.getProperty("usrQA");
        String psw = properties.getProperty("pswQA");
        Connection connection = null;

        try {
            String ConnectionUrl = "jdbc:jtds:sybase://" + url + ";user=" + usr + ";password=" + psw + ";encrypt=true;Connection Timeout=30;";
            connection = DriverManager.getConnection(ConnectionUrl);
            return connection;
        } catch (SQLException e) {
            e.printStackTrace();
            PdfBciReports.addReport("[bdGalileoIII-Corfin] getConnection", "Conexion Fallida a bdCorfin: " + e.getMessage(), EstadoPrueba.FAILED, true);
        }
        return connection;
    }
}
