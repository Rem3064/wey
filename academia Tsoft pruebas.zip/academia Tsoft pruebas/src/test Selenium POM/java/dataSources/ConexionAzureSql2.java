package dataSources;

import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.ReadProperties;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConexionAzureSql2 {
    private ConexionAzureSql2() {
        throw new IllegalStateException("Utility class");
    }

    public static Connection getConnection3() {
        Properties properties = ReadProperties.readFromConfig("bdSqlAzure2.properties");
        String url = properties.getProperty("hostQA");
        String usr = properties.getProperty("usrQA");
        String psw = properties.getProperty("pswQA");
        Connection connection = null;

        try {
            String ConnectionUrl = "jdbc:sqlserver://" + url + ";databaseName=bcirg3crtfacconf001;user=" + usr + ";password=" + psw + ";encrypt=true;Connection Timeout=30;";
            connection = DriverManager.getConnection(ConnectionUrl);
            PdfBciReports.addReport("[Azure Sql Server2] getConnection", "Se genero conexion a Azure Sql Server correctamente", EstadoPrueba.PASSED, false);
            return connection;
        } catch (SQLException e) {
            e.printStackTrace();
            PdfBciReports.addReport("[Azure Sql Server] getConnection", "Conexion Fallida a Azure Sql Server: " + e.getMessage(), EstadoPrueba.FAILED, true);
            return connection;
        }
    }
}
