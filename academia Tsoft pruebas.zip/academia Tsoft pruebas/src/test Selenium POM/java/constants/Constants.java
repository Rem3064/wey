package constants;

import utils.MetodosGenericos;

public abstract class Constants {
    private Constants() {
        throw new IllegalStateException("Utility class");
    }

    /*** constants para IGCorfin ***/
    public static String proveedorRut1 = "";
    public static String proveedorEstado1 = "";
    public static String proveedorRazonSocial1 = "";

    public static String par_des = "";


    /*** MS LOGIN ***/
    public static String url = "";
    public static String password1 = "";
    public static String grandType1 = "";
    public static String grandType2 = "";
    public static String username1 = "";

    public static String responseBody1 = "";
    public static int statusCode1 = 0;

    public static int statusCode2 = 0;
    public static String token1 = "";

    public static String tokenDataMart = "";

    public static String tokenFactoring = "eyJhbGciOiJSUzI1NiJ9.eyJpZF9jbGllbnRlIjo5NjMsInVzZXJfbmFtZSI6IjEyMDUzMjA3LTMiLCJydXRfY2xpZW50ZSI6IjEyMDUzMjA3LTMiLCJvcmlnZW4iOm51bGwsImF1dGhvcml0aWVzIjpbIlJPTEVfQ0xJRU5URV9CQ0kiXSwiY2xpZW50X2lkIjoiYXBwLW1vdmlsLXBlcnNvbmFzIiwiYXBlbGxpZG9fcF9jbGllbnRlIjoiQVAuIFBBVEVSTk8iLCJhenAiOiJhcHAtbW92aWwtcGVyc29uYXMiLCJzY29wZSI6WyJyZWFkIiwiIHdyaXRlIl0sImV4cCI6MTY3NjM5NTg1NiwiY2ljIjoiMDcwNTc5MDciLCJqdGkiOiI4ZmEwNGMyOC1lNjQ2LTQ1MDAtYmNkZC0yNWFkYmNkNzQ1YWQiLCJub21icmVfY2xpZW50ZSI6Ik5PTUJSRSJ9.TPquXuMnXmJIkCPB9gDJPy2igABfRhKxPAPhnc5r46y7wRCMXWDAP962FQZwRmV9IaRsgW3m_ci3xttyH2TFdwzp3fmqYuHC3cFN6m07VZ0XfH0e3Tca_TuQNfkPJmnVHt9L-3VnJy6cvOUUacGOJwdxdqX0InaYjqF95EwFunbhi3bB3dNKIgAQVF7EB8tFciU-eInnWYBJkZ6vDCCo8QbyP3w3OoYtvEqfdxlu7FhYIxH4TZcUn1DVFeCLoZUVsEvFbteDBtlw8SiV4u5djqneGspogBTMcu4gW5XClrjAj87l3YViBGH_CerawIAnkS9djRd2lBU77SDrbPnPKQ";
    public static String body1 = "";

    public static String rut1 = "";
    public static int sw = 0;
    public static String numTrans1 = "";

    public static String numOpe1 = "";

    public static String numOpeCreado1 = "";

    public static String num_proveedor1 = "";

    public static String numCtaProvee1 = "";

    public static int montoTopeInversionista1 = 0;

    public static int montoTopeInversionista2 = 0;

    public static String mto_tope_ini_inversionita1 = "";
    public static String mto_tope_ini_inversionita2 = "";

    public static String mto_tope_inversionista_nuevo1 = "";

    public static String mto_tope_inversionista_nuevo2 = "";

    public static String mto_tope_bd_inversionista_nuevo1 = "";

    public static String mto_tope_bd_inversionista_nuevo2 = "";


    public static double montoDesembolso1 = 705167.0;
    public static double montoDesembolso2 = 0;

    public static int montoTopeInversionistaNuevo1 = 0;

    public static int montoTopeInversionistaNuevo2 = 0;
    public static int montoInicialInversionista = 0;
    public static String rutInversionista1 = "";

    public static String rutInversionista2 = "";


    /*** Response Body Encabezado ***/
    public static int num_operacion = 0;
    public static String num_transaccion = "";

    public static int id_pagador = 0;
    public static String dv_pagador = "";
    public static String nom_pagador = "";
    public static int tip_moneda = 0;
    public static int cod_canal = 0;
    public static int id_prove = 0;
    public static String dv_prove = "";
    public static String nom_prove = "";
    public static String email_prove = "";
    public static String tip_cta_prove = "";
    public static String cod_bco_prove = "";
    public static String nom_bco_prove = "";
    public static String num_cta_prove = "";

    public static int total_registros = 0;
    public static int fac_conversion = 0;

    public static String hora_transmision = "";

    public static String fecha_transmision = "";

    public static String sum_mto_total_orig_fact = "";
    public static double sum_mto_total_ced_fact = 0;
    public static double sum_mto_total_pago_prove = 0.0;
    public static double mto_des_inversionista = 0;

    public static String cod_estado = "";

    public static String codigoEstado0 = "";
    public static String codigoEstado1 = "";
    public static String cod_error = "";
    public static String desc_error = "";

    /*** Response Body Facturas ***/
    public static String tipo_ope = "";
    public static String tipo_docum = "";
    public static String mont_t_fac = "";
    public static String m_ced_fac = "";
    public static String mont_abonarFac = "";
    public static String estado_fac = "";

    /*** MS ApiKey ***/
    public static String jsonAsociado = "";

    /*** CUCUMBER ***/
    public static final String AMBIENTE_URL_EMPRESAS = "http://bcicert/empresas/";

    public static String AMBIENTE = MetodosGenericos.setAmbiente("QA");
    public static final boolean smokeTests = false;
    public static final boolean virtualizada = false;

}