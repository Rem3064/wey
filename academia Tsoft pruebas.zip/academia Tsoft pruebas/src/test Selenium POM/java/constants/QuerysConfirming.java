package constants;

public abstract class QuerysConfirming {

    private QuerysConfirming() {
        throw new IllegalStateException("Utility class");
    }

    /*** Querys BD Corfin ***/

    public static String QUERY1 = "";

    public static String queryObtenerTipoCambioParPagadorProveedor = "BEGIN\n" +
            "    DECLARE @var_COMISION INT,\n" +
            "        @var_par_mon INT ,\n" +
            "        @var_tipo_cambio INT,\n" +
            "        @SW INT,\n" +
            "        @FECHA_AUX DATETIME,\n" +
            "        @var_FECHA_DIA_HABIL DATETIME,\n" +
            "        @var_FER_FEC DATETIME\n" +
            "    SELECT @var_COMISION = cpp_com_pag\n" +
            "    FROM cpp\n" +
            "    WHERE gpg_rut = '000058400582'\n" +
            "      AND pvr_rut = '000052010543'\n" +
            "    SELECT @SW = 1\n" +
            "    SELECT @FECHA_AUX = getdate()\n" +
            "    while @SW = 1\n" +
            "        begin\n" +
            "            IF (DATENAME(dw, @FECHA_AUX) = 'Saturday') OR (DATENAME(dw, @FECHA_AUX) = 'Sabado')\n" +
            "                begin\n" +
            "                    SELECT @FECHA_AUX = DATEADD(day, 2, @FECHA_AUX)\n" +
            "                end\n" +
            "            IF (DATENAME(dw, @FECHA_AUX) = 'Sunday') OR (DATENAME(dw, @FECHA_AUX) = 'Domingo')\n" +
            "                begin\n" +
            "                    SELECT @FECHA_AUX = DATEADD(day, 1, @FECHA_AUX)\n" +
            "                end\n" +
            "            SELECT @var_FER_FEC = fer_fec\n" +
            "            FROM fer_proxy\n" +
            "            WHERE convert(varchar(10), fer_fec, 111) = convert(varchar(10), @FECHA_AUX, 111)\n" +
            "            IF @@rowcount = 0\n" +
            "                begin\n" +
            "                    SELECT @SW = 0\n" +
            "                end\n" +
            "            else\n" +
            "                begin\n" +
            "                    SELECT @FECHA_AUX = DATEADD(day, 1, @FECHA_AUX)\n" +
            "                end\n" +
            "            SELECT @var_FECHA_DIA_HABIL = @FECHA_AUX\n" +
            "        end\n" +
            "    SELECT @var_par_mon = par_mon\n" +
            "    FROM cms\n" +
            "    WHERE cms_cod = @var_COMISION\n" +
            "    if @var_par_mon <> 1\n" +
            "        begin\n" +
            "            SELECT @var_tipo_cambio = 0\n" +
            "            set rowcount 1\n" +
            "            SELECT @var_tipo_cambio = ISNULL(par_val, 0)\n" +
            "            FROM par_proxy\n" +
            "            WHERE convert(varchar(10), par_fec, 111) <= CONVERT(VARCHAR(10), @var_FECHA_DIA_HABIL, 111)\n" +
            "              AND pnu_mon = @var_par_mon\n" +
            "              AND ISNULL(par_val, 0) <> 0\n" +
            "            ORDER BY par_fec desc\n" +
            "            set rowcount 0\n" +
            "        end\n" +
            "    else\n" +
            "        SELECT @var_tipo_cambio = 1\n" +
            "    SELECT @var_tipo_cambio tipo_cambio\n" +
            " END";

    public static String obtenerCampoTipoComisiondelParPagadorProveedor = "BEGIN\n" +
            "    DECLARE @var_COMISION INT\n" +
            "    SELECT @var_COMISION = cpp_com_pag\n" +
            "    FROM cpp\n" +
            "    WHERE gpg_rut = '000058400582'\n" +
            "      AND pvr_rut = '000052010543'\n" +
            "    SELECT ISNULL(cms_tip_cms, ' ') tipo_comision\n" +
            "    FROM cms\n" +
            "    WHERE cms_cod = @var_COMISION\n" +
            "END";

    public static String obtenerPorcentajeComisionParPagadorProveedor = "BEGIN\n" +
            "    DECLARE @var_COMISION INT\n" +
            "    SELECT @var_COMISION = cpp_com_pag\n" +
            "    FROM cpp\n" +
            "    WHERE gpg_rut = '000058400582'\n" +
            "      AND pvr_rut = '000052010543'\n" +
            "    SELECT ISNULL(cms_por_com, 0) porcentaje_comision\n" +
            "    FROM cms\n" +
            "    WHERE cms_cod = @var_COMISION\n" +
            "END";

    public static String obtenerComisionMinimaParPagadorProveedor = "BEGIN\n" +
            "    DECLARE @var_COMISION INT\n" +
            "    SELECT @var_COMISION = cpp_com_pag\n" +
            "    FROM cpp\n" +
            "    WHERE gpg_rut = '000058400582'\n" +
            "      AND pvr_rut = '000052010543'\n" +
            "    SELECT ISNULL(cms_mon_min, 0) comision_minima\n" +
            "    FROM cms\n" +
            "    WHERE cms_cod = @var_COMISION\n" +
            "END  ";
    public static String obtenerComisionMaximaParPagadorProveedor = "BEGIN\n" +
            "    DECLARE @var_COMISION INT\n" +
            "    SELECT @var_COMISION = cpp_com_pag\n" +
            "    FROM cpp\n" +
            "    WHERE gpg_rut = '000058400582'\n" +
            "      AND pvr_rut = '000052010543'\n" +
            "    SELECT ISNULL(cms_mon_max, 0) comision_maxima\n" +
            "    FROM cms\n" +
            "    WHERE cms_cod = @var_COMISION\n" +
            "END";
    public static String obtenerComisionFijaParPagadorProveedor = "BEGIN\n" +
            "    DECLARE @var_COMISION INT\n" +
            "    SELECT @var_COMISION = cpp_com_pag\n" +
            "    FROM cpp\n" +
            "    WHERE gpg_rut = '000096844080'\n" +
            "      AND pvr_rut = '000052010693'\n" +
            "    SELECT ISNULL(cms_mon_fij, 0) comision_fija\n" +
            "    FROM cms\n" +
            "    WHERE cms_cod = @var_COMISION\n" +
            "END";
    public static String obtenerCostoPagadorParPagadorProveedor = "SELECT isnull(p.ppp_cpg,2) costo_pagador\n" +
            "FROM ppp p\n" +
            "WHERE p.ppp_gpg_rut = '000058400582'\n" +
            "AND p.ppp_pvr_rut = '000052010543'";
    public static String obtenerIvaParPagadorProveedor = "SELECT ISNULL(sis_iva,0) iva\n" +
            "FROM \tsis";
    public static String obtenerLineaCreditoParPagadorProveedor = "select (ISNULL(S.sbl_mto, 0) - ISNULL(\n" +
            "        (SELECT SUM(J.doc_sdo_gpg)\n" +
            "         FROM doc J\n" +
            "                  INNER JOIN opc O ON O.opc_num_cfg = J.opc_num\n" +
            "         WHERE J.gpg_rut = S.gpg_rut\n" +
            "           AND J.par_est IN (1, 2)\n" +
            "           AND O.par_est = 6), 0))\n" +
            "from sbl S\n" +
            "where S.gpg_rut = '000058400582'";
    public static String obtenerMontoMinimoParPagadorProveedor = "select ISNULL(S.sbl_mto_min,0) monto_minimo\n" +
            "from sbl S where S.gpg_rut = '000058400582'";
    public static String obtenerPlazoMinimoParPagadorProveedor = "select ISNULL(S.sbl_pla_min,0) plazo_minimo\n" +
            "from sbl S where S.gpg_rut = '000058400582'";
    public static String obtenerPlazoMaximoParPagadorProveedor = "select ISNULL(S.sbl_pla_max,0) plazo_maximo\n" +
            "from sbl S where S.gpg_rut = '000058400582'";
    public static String obtenerTipoCostoFondoParPagadorProveedor = "SELECT  p.ppp_tba tipo_costo_fondo\n" +
            "FROM ppp p\n" +
            "WHERE p.ppp_gpg_rut = '000058400582'\n" +
            "AND p.ppp_pvr_rut = '000052010543'";
    public static String obtenerTipoNegocioParPagadorProveedor = "SELECT  p.ppp_tpn tipo_negocio\n" +
            "FROM ppp p\n" +
            "WHERE p.ppp_gpg_rut = '000058400582'\n" +
            "AND p.ppp_pvr_rut = '000052010543'";
    public static String obtenerTipoSpreadParPagadorProveedor = "SELECT case\n" +
            "when p.ppp_tpn = 1 THEN (select case\n" +
            "when spr_ead is not null then convert(VARCHAR(10), spr_ead)\n" +
            "else null end\n" +
            "from spr\n" +
            "inner join gpg on gpg.gpg_cat = spr.gpg_cat\n" +
            "inner join cpp\n" +
            "on cpp.cpp_cat = spr.pvr_cat and cpp.gpg_rut = gpg.gpg_rut and\n" +
            "cpp.cpp_est_aca = 1\n" +
            "where cpp.pvr_rut = p.ppp_pvr_rut\n" +
            "and gpg.gpg_rut = p.ppp_gpg_rut)\n" +
            "end spread\n" +
            "FROM ppp p\n" +
            "WHERE p.ppp_gpg_rut = '000058400582'\n" +
            "AND p.ppp_pvr_rut = '000052010543'";
    public static String obtenerTasaNegocioParPagadorProveedor = "SELECT case\n" +
            "when p.ppp_tpn = 2 then (select case\n" +
            "when tas_neg is not null then convert(VARCHAR(10), tas_neg)\n" +
            "else null end\n" +
            "from tng\n" +
            "inner join gpg on gpg.gpg_cat = tng.gpg_cat\n" +
            "inner join cpp\n" +
            "on cpp.cpp_cat = tng.pvr_cat and cpp.gpg_rut = gpg.gpg_rut and\n" +
            "cpp.cpp_est_aca = 1\n" +
            "where cpp.pvr_rut = p.ppp_pvr_rut\n" +
            "and gpg.gpg_rut = p.ppp_gpg_rut)\n" +
            "end tasa_negocio\n" +
            "FROM ppp p\n" +
            "WHERE p.ppp_gpg_rut = '000096806900'\n" +
            "AND p.ppp_pvr_rut = '000052010693'";
}
