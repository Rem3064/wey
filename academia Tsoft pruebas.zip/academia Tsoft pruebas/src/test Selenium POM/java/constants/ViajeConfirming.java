package constants;

public abstract class ViajeConfirming {
    private ViajeConfirming() {
        throw new IllegalStateException("Utility class");
    }

    public static String campoSP = "";
    public static String montoDisponible1 = "";
    public static String codigo1 = "";
    public static String mensaje1 = "";

    public static String SP1 = "";
    public static Integer tipo_cambio1 = 0;

    public static Integer tipo_cambio2 = 0;
    public static CharSequence tipo_comision1 = "";

    public static CharSequence tipo_comision2 = "";
    public static Integer porcentaje_comision1 = 0;

    public static Integer porcentaje_comision2 = 0;
    public static Integer comision_minima1 = 0;

    public static Integer comision_minima2 = 0;
    public static Integer comision_maxima1 = 0;

    public static Integer comision_maxima2 = 0;
    public static String comision_fija1 = "";
    public static String comision_fija2 = "";
    public static Integer costo_pagador1 = 0;
    public static Integer costo_pagador2 = 0;
    public static Integer iva1 = 0;
    public static Integer iva2 = 0;
    public static Integer gasto1 = 0;
    public static Integer gasto2 = 0;
    public static Integer iva_gasto1 = 0;
    public static Integer iva_gasto2 = 0;
    public static String linea_credito1 = "";
    public static String linea_credito2 = "";
    public static Integer monto_minimo1 = 0;
    public static Integer monto_minimo2 = 0;
    public static String monto_minimo3 = "";
    public static Integer plazo_minimo1 = 0;
    public static String plazo_minimo3 = "";
    public static Integer plazo_minimo2 = 0;
    public static Integer plazo_maximo1 = 0;
    public static Integer plazo_maximo2 = 0;

    public static String plazo_maximo3 = "";
    public static CharSequence tipo_costo_fondo1 = "";
    public static CharSequence tipo_costo_fondo2 = "";
    public static Integer tipo_negocio1 = 0;
    public static Integer tipo_negocio2 = 0;
    public static String spread1 = "";
    public static String spread2 = "";
    public static String tasa_negocio1 = "";
    public static String tasa_negocio2 = "";

}
