package steps;

import io.cucumber.java.en.And;
import pages.bd.SqlConsulta2;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

import java.sql.SQLException;

public class SQLServer2 {
    private static final SqlConsulta2 sqlConsulta2 = new SqlConsulta2();

    @And("Visualizo en la tabla prv_proveedor que no exista")
    public void visualizoEnLaTablaPrv_proveedorQueNoExista() {
        try {
            sqlConsulta2.proveedorNoExiste();
            PdfBciReports.addReport("Visualizo en la tabla prv_proveedor que no exista", "validacion exitosa", EstadoPrueba.PASSED, false);
        } catch (SQLException e) {
            MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(e));
        }
    }

    @And("Visualizo en la tabla prv_proveedor que exista")
    public void visualizoEnLaTablaPrv_proveedorQueExista() {
        try {
            sqlConsulta2.proveedorExiste();
            PdfBciReports.addReport("Visualizo en la tabla prv_proveedor que exista", "validacion exitosa", EstadoPrueba.PASSED, false);
        } catch (SQLException e) {
            MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(e));
        }
    }
}