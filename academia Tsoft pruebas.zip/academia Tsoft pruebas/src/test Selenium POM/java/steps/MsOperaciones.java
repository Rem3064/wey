package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import utils.MetodosGenericos;

import static constants.Constants.*;

public class MsOperaciones {
    @Given("seteo la URL {string} del MS {string} a validar")
    public void seteoLaURLDelMSAValidar(String url_ms, String arg1) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("Seteo la URL del MS a validar " + arg1);
            url = url_ms;
            MetodosGenericos.imprimerConsolaMsjPositivo(url_ms);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("seteo y visualizo credenciales en el body {string} {string} y {string}")
    public void seteoYVisualizoCredencialesEnElBodyY(String password, String grandType, String username) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("seteo y visualizo credenciales en el body:");
            password1 = password;
            grandType1 = grandType;
            username1 = username;
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("seteo y visualizo credenciales en el body {string} y {string}")
    public void seteoYVisualizoCredencialesEnElBodyY(String grandType, String rut) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("seteoYVisualizoCredencialesEnElBody");
            grandType2 = grandType;
            rut1 = rut;
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("visualizo que el campo {string} desplegado corresponda a {string}")
    public void visualizoQueElCampoDesplegadoCorrespondaA(String arg1, String statusCode) {
        try {
            statusCode1 = Integer.parseInt(statusCode);
            MetodosGenericos.imprimerConsolaMsjPositivo("visualizo que el campo " + arg1 + " " + statusCode);
        } catch (NumberFormatException e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("visualizo el campo {string} desplegado como {string}")
    public void visualizoElCampoDesplegadoComo(String arg1, String statusCode) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("visualizo el campo " + arg1 + " desplegado como " + statusCode);
            statusCode1 = Integer.parseInt(statusCode);
        } catch (NumberFormatException e) {
            MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(e));
        }
    }
}