package steps;

import io.cucumber.java.en.And;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;

import static constants.ViajeConfirming.codigo1;

public class ConfirmingMS {
    @And("Valido en respon body codigo {string}")
    public void validoEnResponBodyCodigo(String cod) {
        if (cod.equals(codigo1)) {
            PdfBciReports.addReport("Valido en respon body codigo " + cod, "validacion exitosa", EstadoPrueba.PASSED, false);
        } else {
            PdfBciReports.addReport("Valido en respon body codigo " + cod, "validacion fallida" + codigo1, EstadoPrueba.FAILED, true);
        }
    }
}
