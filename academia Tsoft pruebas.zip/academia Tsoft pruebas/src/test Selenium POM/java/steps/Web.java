package steps;

import driverWeb.DriverContextWeb;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Web.Portal;
import pages.Web.PortalExpress;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

public class Web {
    private static final String OPC_1 = "no se encuentra la opcion: ";
    private EstadoPrueba passed;

    @Given("Ingreso a portal {string}")
    public void ingresoAPortal(String Url) {
        try {
            PdfBciReports.addWebReportImage("Ingreso Portal: " + Url, "Se ingresa correctamente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            PdfBciReports.addReport("Ingreso a portal", "error: " + e.getMessage(), EstadoPrueba.FAILED, true);
        } finally {
            MetodosGenericos.imprimerConsolaMsjPositivoMetodos(Url);
        }
    }

    @And("Ingreso rut {string}")
    public void ingresoRut(String rut) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("Ingreso rut: " + rut);
            Portal.pageObject().setCampoUsuario(rut);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        } finally {
            MetodosGenericos.imprimerConsolaMsjPositivo(rut);
        }
    }

    @And("Ingreso clave {string}")
    public void ingresoClave(String clave) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("Ingreso clave: " + clave);
            Portal.pageObject().setCampoPassword(clave);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        } finally {
            MetodosGenericos.imprimerConsolaMsjPositivo(clave);
        }
    }

    @And("Presiono boton {string}")
    public void presionoBoton(String nombre) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("Presiono boton: " + nombre);
            switch (nombre) {
                case "Ingresar":
                    MetodosGenericos.imprimerConsolaMsjPositivo("Ingresar");
                    //Portal.pageObject().clickIngresar();
                    break;
                case "Enrolar Luego":
                    Portal.pageObject().clickBtnEnrolarLuego();
                    break;
                case "Pagos":
                    PortalExpress.pageObject().clickBtnPagos();
                    break;
                case "FactoringCtaCteProveedor":
                    PortalExpress.pageObject().clickBtnFactoringCtaCteProveedor();
                    break;
                case "Cerrar Sesión":
                    break;
                default:
                    PdfBciReports.addWebReportImage("Boton " + nombre, "no se encuentra la opcion seleccionada: " + nombre, EstadoPrueba.FAILED, true);
            }
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        } finally {
            MetodosGenericos.imprimerConsolaMsjPositivo(nombre);
        }
    }

    @And("Visualizo la pagina {string}")
    public void visualizoLaPagina(String pagina) {
        try {
            switch (pagina) {
                case "BCIExpress":
                    PortalExpress.pageObject().visualizarBciExpress();
                    break;
                case "b":
                    break;
                default:
                    PdfBciReports.addReport("Visualizo la pagina", OPC_1 + pagina, EstadoPrueba.FAILED, true);
                    break;
            }
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        } finally {
            MetodosGenericos.imprimerConsolaMsjPositivo(pagina);
        }
    }

    @When("Presiono la pestana {string}")
    public void presionoLaPestana(String pestana) {
        try {
            switch (pestana) {
                case "Consultas":
                    PortalExpress.pageObject().btnConsultas();
                    break;
                case "b":
                    break;
                default:
                    PdfBciReports.addReport("Visualizo la pestana", OPC_1 + pestana, EstadoPrueba.FAILED, true);
                    break;
            }
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        } finally {
            MetodosGenericos.imprimerConsolaMsjPositivo(pestana);
        }
    }

    @And("Presiono la opcion {string}")
    public void presionoLaOpcion(String opcion) {
        try {
            switch (opcion) {
                case "Informacion Proveedor":
                    PortalExpress.pageObject().presionarOpcionInformacionProveedor(opcion);
                    break;
                case "Financiamiento Factoring":
                    PortalExpress.pageObject().presionarOpcionFinanciamientoFactoring(opcion);
                    break;
                default:
                    PdfBciReports.addReport("Visualizo la opcion", OPC_1 + opcion, EstadoPrueba.FAILED, true);
                    break;
            }
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        } finally {
            MetodosGenericos.imprimerConsolaMsjPositivo(opcion);
        }
    }

    @Then("Visualizo en la grilla el numero de pagadores con documentos publicados")
    public void visualizoEnLaGrillaElNumeroDePagadoresConDocumentosPublicados() {
        try {
            PortalExpress.pageObject().visualizoGrillaNumeroPagadoresConDocumentosPublicados();
            MetodosGenericos.esperar(5);
            DriverContextWeb.getDriverWeb().close();
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        } finally {
            MetodosGenericos.imprimerConsolaMsjPositivo("Visualizo en la grilla el numero de pagadores con documentos publicados");
        }

    }

    @Then("Visualizo en la grilla que no exista pagadores con documentos publicados")
    public void visualizoEnLaGrillaQueNoExistaPagadoresConDocumentosPublicados() {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("Visualizo en la grilla que no exista pagadores con documentos publicados");
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        } finally {
            MetodosGenericos.esperar(1);
        }
    }

    @And("Valido en web {string} con rut {string} y clave {string}")
    public void validoEnWebConRutYClave(String web, String rut, String clave) {
        passed = EstadoPrueba.PASSED;
        PdfBciReports.addReport("Valido en web " + web + " con rut " + rut + " y clave " + clave, "----", EstadoPrueba.PASSED, false);
    }

    @And("Valido mismo grupo y documentos asociados al ms")
    public void validoMismoGrupoYDocumentosAsociadosAlMs() {
        MetodosGenericos.imprimerConsolaMsjPositivo("Valido mismo grupo y documentos asociados al ms");
    }

    @And("Valido campos generados")
    public void validoCamposGenerados() {
        MetodosGenericos.imprimerConsolaMsjPositivo("Valido campos generados");
    }
}