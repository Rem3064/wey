package steps;

import constants.Navegador;
import driverWeb.DriverContextWeb;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

import static constants.Constants.*;
import static featureControlled.CucumberExecution.configExecution;
import static featureControlled.CucumberExecution.finishExecution;
import static utils.UtilsPDF.setTypeExecution;

public class CucumberHooks {
    @Before
    public void beforeScenario(Scenario scenario) {
        /*
        AMBIENTES
        QA: CERTIFICACION
        DEV: DESARROLLO
        */
        MetodosGenericos.setAmbiente("QA");
        configExecution(scenario, "Nombre Release");
        setTypeExecution("ms", "MultiUniverse", false, false);
        PdfBciReports.createPDF();
    }

    @After
    public void afterScenario(Scenario s) {
        finishExecution(s);
        PdfBciReports.finishPDF();
    }
}