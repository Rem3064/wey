package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import pages.bd.CorfinBD;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

import java.sql.SQLException;
import java.util.Objects;

import static constants.Constants.body1;
import static constants.QuerysConfirming.*;
import static constants.ViajeConfirming.*;

public class ConfirmingSP {
    private static final CorfinBD corfinBD = new CorfinBD();
    private static final String MSJ_VALOR = "se obtiene el valor: ";
    private static final String MSJ_VALOR_CAMPO = "Obtengo el valor del campo ";
    private static final String MSJ_SP = " del SP";
    private static final String PORCENTAJE_COMISION = "porcentaje_comision";
    private static final String COMISION_MINIMA = "comision_minima";
    private static final String COMISION_MAXIMA = "comision_maxima";
    private static final String COMISION_FIJA = "comision_fija";
    private static final String COSTO_PAGADOR = "costo_pagador";
    private static final String GASTO = "gasto";
    private static final String IVA_GASTO = "iva_gasto";
    private static final String LINEA_CREDITO = "linea_credito";
    private static final String MONTO_MINIMO = "monto_minimo";
    private static final String PLAZO_MINIMO = "plazo_minimo";
    private static final String PLAZO_MAXIMO = "plazo_maximo";
    private static final String TIPO_COSTO_FONDO = "tipo_costo_fondo";
    private static final String TIPO_NEGOCIO = "tipo_negocio";
    private static final String SPREAD = "spread";
    private static final String TASA_NEGOCIO = "tasa_negocio";
    private static final String MSJ_PAR_PAG_PROV = " del par pagador proveedor";
    private static final String MSJ_VALOR_CAMPO2 = "Obtengo el valor campo ";
    private static final String MSJ_VALOR_CAMPO3 = "Valido que el valor del campo ";
    private static final String MSJ_SP_IGUAL_VALOR_PAR_PAG_PROV = " del SP sea igual al valor del par pagador proveedor";
    private static final String MSJ_RES_BODY = "Visualizo en Respond Body el campo ";
    private static final String MSJ_SQL_VALIDAR_CAMPO = "Ejecuto sql para validar que campo ";
    private static final String MSJ_IGUAL_CAMPO = " sea igual campo ";
    private static final String MSJ_ENDPOINT = " del endpoint ";
    private static final String MSJ_VALIDACION = "validacion";
    private static final String MSJ_PASSED = "se obtiene el valor";
    private static final String MSJ_FAILED = "validacion fallida";
    private static final String TIPO_CAMBIO = "tipo_cambio";
    private static final String TIPO_COMISION = "tipo_comision";
    private static final String IVA = "iva";
    private static final String ENDPOINT = " del endpoint";

    @Given("Ingreso a BD Corfin con Host {string} puerto {string} User {string} PassWord {string}")
    public void ingresoABDCorfinConHostPuertoUserPassWord(String host, String puerto, String user, String passwd) {
        try {
            PdfBciReports.addReport("Ingreso a BD Corfin", "Host: " + host + " Puerto: " + puerto + " User: " + user + " Password: " + passwd, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Verifico la configuracion de la dupla en la ruta de {string}: {string} y busco por el rut del proveedor")
    public void verificoLaConfiguracionDeLaDuplaEnLaRutaDeYBuscoPorElRutDelProveedor(String arg0, String arg1) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("verificoLaConfiguracionDeLaDuplaEnLaRutaDeYBuscoPorElRutDelProveedor" + arg0 + arg1);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @When("Ejecuto SP {string}")
    public void ejecutoSP(String sp) {
        try {
            PdfBciReports.addReport("Ejecuto SP", "" + sp, EstadoPrueba.PASSED, false);
            SP1 = sp;
            MetodosGenericos.imprimerConsolaMsjPositivo("antiguo sp1");
            MetodosGenericos.imprimerConsolaMsjPositivo(SP1);
            SP1 = SP1.replace("(", "");
            SP1 = SP1.replace(")", "");
            SP1 = SP1.replace(";", "");
            MetodosGenericos.imprimerConsolaMsjPositivo("Nuevo sp1");
            MetodosGenericos.imprimerConsolaMsjPositivo(SP1);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Obtengo el valor del campo {string} del SP")
    public void obtengoElValorDelCampoDelSP(String campo) {
        try {
            corfinBD.obtenerTipoGenericoString();
            PdfBciReports.addReport(MSJ_VALOR_CAMPO + campo + MSJ_SP, "se obtiene los datos", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            e.printStackTrace();
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }


    @And("Obtengo el valor campo {string} del par pagador proveedor")
    public void obtengoElValorCampoDelParPagadorProveedor(String campo) {
        try {
            switch (campo) {
                case TIPO_CAMBIO:
                    QUERY1 = queryObtenerTipoCambioParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case TIPO_COMISION:
                    QUERY1 = obtenerCampoTipoComisiondelParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case PORCENTAJE_COMISION:
                    QUERY1 = obtenerPorcentajeComisionParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case COMISION_MINIMA:
                    QUERY1 = obtenerComisionMinimaParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case COMISION_MAXIMA:
                    QUERY1 = obtenerComisionMaximaParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case COMISION_FIJA:
                    QUERY1 = obtenerComisionFijaParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case COSTO_PAGADOR:
                    QUERY1 = obtenerCostoPagadorParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case IVA:
                    QUERY1 = obtenerIvaParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case GASTO:
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_VALOR + gasto2, EstadoPrueba.PASSED, false);
                    break;
                case IVA_GASTO:
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_VALOR + iva_gasto2, EstadoPrueba.PASSED, false);
                    break;
                case LINEA_CREDITO:
                    QUERY1 = obtenerLineaCreditoParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case MONTO_MINIMO:
                    QUERY1 = obtenerMontoMinimoParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case PLAZO_MINIMO:
                    QUERY1 = obtenerPlazoMinimoParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case PLAZO_MAXIMO:
                    QUERY1 = obtenerPlazoMaximoParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case TIPO_COSTO_FONDO:
                    QUERY1 = obtenerTipoCostoFondoParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case TIPO_NEGOCIO:
                    QUERY1 = obtenerTipoNegocioParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case SPREAD:
                    QUERY1 = obtenerTipoSpreadParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                case TASA_NEGOCIO:
                    QUERY1 = obtenerTasaNegocioParPagadorProveedor;
                    corfinBD.obtenerTipoGenericoParPagadorProveedor();
                    PdfBciReports.addReport(MSJ_VALOR_CAMPO2 + campo + MSJ_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
                    break;
                default:
                    PdfBciReports.addReport("no se encuentra el campo seleccionado: " + campo, "", EstadoPrueba.FAILED, true);
                    break;
            }
        } catch (SQLException e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    /**
     * maximo de 15 case permitidos por SONAR
     **/
    @And("Valido que el valor del campo {string} del SP sea igual al valor del par pagador proveedor")
    public void validoQueElValorDelCampoDelSPSeaIgualAlValorDelParPagadorProveedor(String campo) {
        try {
            PdfBciReports.addReport(MSJ_VALOR_CAMPO3 + campo + MSJ_SP_IGUAL_VALOR_PAR_PAG_PROV, MSJ_PASSED, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Visualizo datos seteados en las duplas")
    public void visualizoDatosSeteadosEnLasDuplas() {
        try {
            PdfBciReports.addReport("Visualizo datos seteados en las duplas", "", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Visualizo en Respon body {string} sea igual a numero de pagadores con documentos publicados")
    public void visualizoEnResponBodySeaIgualANumeroDePagadoresConDocumentosPublicados(String b1) {
        try {
            PdfBciReports.addReport("Visualizo en Respon body " + b1 + " sea igual a numero de pagadores con documentos publicados", "", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Valido listado de pagadores con documentos publicados al proveedor")
    public void validoListadoDePagadoresConDocumentosPublicadosAlProveedor() {
        try {
            PdfBciReports.addReport("Valido listado de pagadores con documentos publicados al proveedor", "", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Valido {string} de pagadores con documentos publicados al proveedor")
    public void validoDePagadoresConDocumentosPublicadosAlProveedor(String p1) {
        try {
            PdfBciReports.addReport("Valido " + p1 + " de pagadores con documentos publicados al proveedor", "", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Valido {string} de pagadores publicados al proveedor")
    public void validoDePagadoresPublicadosAlProveedor(String p2) {
        try {
            PdfBciReports.addReport("Valido " + p2 + " de pagadores publicados al proveedor", "", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Visualizo en Respon body {string} sea igual a cero numero de pagadores con documentos publicados")
    public void visualizoEnResponBodySeaIgualACeroNumeroDePagadoresConDocumentosPublicados(String b0) {
        try {
            PdfBciReports.addReport("Visualizo en Respon body " + b0 + " sea igual a cero numero de pagadores con documentos publicados", "", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Valido no exista listado de pagadores con documentos publicados al proveedor")
    public void validoNoExistaListadoDePagadoresConDocumentosPublicadosAlProveedor() {
        try {
            PdfBciReports.addReport("Valido no exista listado de pagadores con documentos publicados al proveedor", "", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Visualizo datos de linea de credito en campo {string}")
    public void visualizoDatosDeLineaDeCreditoEnCampo(String camp1) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("Visualizo datos de linea de credito en campo " + camp1);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Visualizo en Respond Body el campo {string}")
    public void visualizoEnRespondBodyElCampo(String campo) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_RES_BODY + campo);
            PdfBciReports.addReport(MSJ_RES_BODY + campo, "" + body1, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Ejecuto sql para validar que campo {string} sea igual campo {string} del endpoint")
    public void ejecutoSqlParaValidarQueCampoSeaIgualCampoDelEndpoint(String campo1, String campo2) {
        try {
            switch (campo1) {
                case "monto_disponible":
                    MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_SQL_VALIDAR_CAMPO + campo1 + MSJ_IGUAL_CAMPO + campo2 + ENDPOINT);
                    corfinBD.devuelveMontoDisponiblePlazoMinimoPlazoMaximoMontoMinimoPagador();
                    PdfBciReports.addReport("montoDisponible1", "" + montoDisponible1, EstadoPrueba.PASSED, false);
                    PdfBciReports.addReport(MSJ_SQL_VALIDAR_CAMPO + campo1 + MSJ_IGUAL_CAMPO + campo2 + MSJ_ENDPOINT, MSJ_VALIDACION, EstadoPrueba.PASSED, false);
                    break;
                case MONTO_MINIMO:
                    MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_SQL_VALIDAR_CAMPO + campo1 + MSJ_IGUAL_CAMPO + campo2 + ENDPOINT);
                    corfinBD.devuelveMontoDisponiblePlazoMinimoPlazoMaximoMontoMinimoPagador();
                    PdfBciReports.addReport(MONTO_MINIMO, "" + monto_minimo2, EstadoPrueba.PASSED, false);
                    PdfBciReports.addReport(MSJ_SQL_VALIDAR_CAMPO + campo1 + MSJ_IGUAL_CAMPO + campo2 + MSJ_ENDPOINT, MSJ_VALIDACION, EstadoPrueba.PASSED, false);
                    break;
                case PLAZO_MINIMO:
                    MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_SQL_VALIDAR_CAMPO + campo1 + MSJ_IGUAL_CAMPO + campo2 + ENDPOINT);
                    corfinBD.devuelveMontoDisponiblePlazoMinimoPlazoMaximoMontoMinimoPagador();
                    PdfBciReports.addReport(PLAZO_MINIMO, "" + plazo_minimo2, EstadoPrueba.PASSED, false);
                    PdfBciReports.addReport(MSJ_SQL_VALIDAR_CAMPO + campo1 + MSJ_IGUAL_CAMPO + campo2 + MSJ_ENDPOINT, MSJ_VALIDACION, EstadoPrueba.PASSED, false);
                    break;
                case PLAZO_MAXIMO:
                    MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_SQL_VALIDAR_CAMPO + campo1 + MSJ_IGUAL_CAMPO + campo2 + ENDPOINT);
                    corfinBD.devuelveMontoDisponiblePlazoMinimoPlazoMaximoMontoMinimoPagador();
                    PdfBciReports.addReport(PLAZO_MAXIMO, "" + plazo_maximo2, EstadoPrueba.PASSED, false);
                    PdfBciReports.addReport(MSJ_SQL_VALIDAR_CAMPO + campo1 + MSJ_IGUAL_CAMPO + campo2 + MSJ_ENDPOINT, MSJ_VALIDACION, EstadoPrueba.PASSED, false);
                    break;
                default:
                    MetodosGenericos.imprimerConsolaMsjNegativo("campo no encontrado: " + campo1);
                    break;
            }
        } catch (SQLException e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Visualizo que el respond body que la peticion se genero correctamente")
    public void visualizoQueElRespondBodyQueLaPeticionSeGeneroCorrectamente() {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("Visualizo que el respond body que la peticion se genero correctamente");
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("Ejecuto sql para validar suma de aquellos documentos que no esten dentro del rango de dias maximo")
    public void ejecutoSqlParaValidarSumaDeAquellosDocumentosQueNoEstenDentroDelRangoDeDiasMaximo() {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("Ejecuto sql para validar suma de aquellos documentos que no esten dentro del rango de dias maximo");
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }
}