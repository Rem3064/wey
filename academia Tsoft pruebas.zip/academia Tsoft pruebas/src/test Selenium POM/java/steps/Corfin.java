package steps;

import io.cucumber.java.en.And;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

public class Corfin {

    /**
     * private static final CorfinBD corfinBD = new CorfinBD();
     **/

    @And("Visualizo en la tabla sbl campo sbl_mto es mayor a {int}")
    public void visualizoEnLaTablaSblCampoSbl_mtoEsMayorA(int cero) {
        PdfBciReports.addReport("Visualizo en la tabla sbl campo sbl_mto es mayor a " + cero, "", EstadoPrueba.PASSED, false);
    }

    @And("Ingreso en la ruta de {string}: {string} y busco por el rut del pagador")
    public void ingresoEnLaRutaDeYBuscoPorElRutDelPagador(String ruta1, String ruta2) {
        MetodosGenericos.imprimerConsolaMsjPositivo("Ingreso en la ruta de " + ruta1 + " " + ruta2 + " y busco por el rut del pagador");
    }

    @And("Valido que el pagador tiene linea de credito")
    public void validoQueElPagadorTieneLineaDeCredito() {
        MetodosGenericos.imprimerConsolaMsjPositivo("Valido que el pagador tiene linea de credito");
    }

    @And("Visualizo en la tabla sbl campo sbl_mto es igual a {int}")
    public void visualizoEnLaTablaSblCampoSbl_mtoEsIgualA(int cero) {
        PdfBciReports.addReport("Visualizo en la tabla sbl campo sbl_mto es igual a " + cero, "", EstadoPrueba.PASSED, false);
    }

    @And("Valido que el pagador no tiene linea de credito")
    public void validoQueElPagadorNoTieneLineaDeCredito() {
        MetodosGenericos.imprimerConsolaMsjPositivo("Valido que el pagador no tiene linea de credito");
    }

    @And("Visualizo datos del campo {string} es igual a respuesta {string} del ms")
    public void visualizoDatosDelCampoEsIgualARespuestaDelMs(String campo, String respon) {
        PdfBciReports.addReport("Visualizo datos del campo " + campo + " es igual a respuesta " + respon, "", EstadoPrueba.PASSED, false);
    }

    @And("Valido que campo monto disponible es igual a sbl_monto")
    public void validoQueCampoMontoDisponibleEsIgualASbl_monto() {

    }
}
