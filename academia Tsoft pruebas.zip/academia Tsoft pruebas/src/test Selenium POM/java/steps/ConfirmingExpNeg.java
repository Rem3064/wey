package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import pages.Back.Login;
import pages.Back.MSConfirming;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

import static constants.Constants.*;
import static constants.ViajeConfirming.*;
import static utils.FeatureControlled.*;

public class ConfirmingExpNeg {
    private static final Login login = new Login();
    private static final MSConfirming msConfirming = new MSConfirming();
    private static final String MSJ_GET_SERV = "Realizo una peticion get al servicio ";
    private static final String MSJ_SETEO_URL = "Seteo la URL del MS a validar";

    @Given("Seteo la URL {string} del MS {string} a validar")
    public void seteoLaURLDelMSAValidar(String url_ms, String ms) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_SETEO_URL);
            url = url_ms;
            MetodosGenericos.imprimerConsolaMsjPositivo(url_ms);
            PdfBciReports.addReport("Seteo la URL " + url_ms + " del MS " + ms + " a validar", "Seteada correctamente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(e));
        } finally {
            MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(url_ms));
        }
    }

    @And("Visualizo que el campo {string} desplegado corresponda a {string}")
    public void visualizoQueElCampoDesplegadoCorrespondaA(String campo, String statusCode) {
        try {
            PdfBciReports.addReport("Visualizo que el campo " + campo + " desplegado corresponda a Status: " + statusCode, "Se visualiza correctamente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(e));
        } finally {
            MetodosGenericos.imprimerConsolaMsjPositivo(campo);
        }
    }

    @And("Ingreso a BD AZURE SQL SERVER con Host {string} puerto {string} base de datos {string} User {string} PassWord {string}")
    public void ingresoABDAZURESQLSERVERConHostPuertoBaseDeDatosUserPassWord(String host, String puerto, String bdName, String user, String passwd) {
        try {
            PdfBciReports.addReport("Ingreso a BD AZURE SQL SERVER", " Host: " + host + " Puerto: " + puerto + " BDName " + bdName + " User " + user + " Password " + passwd, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(e));
        }
    }

    @And("Seteo y visualizo credenciales en el body {string} y {string}")
    public void seteoYVisualizoCredencialesEnElBodyY(String grandType, String rut) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("Seteo y visualizo credenciales en el body grandType: " + grandType + " rut: " + rut);
            grandType1 = grandType;
            rut1 = rut;
            PdfBciReports.addReport("Seteo y visualizo credenciales en el body grandType: " + grandType + " rut: " + rut, "Seteadas correctamente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(e));
        }
    }

    @And("Realizo una peticion post al servicio {string}")
    public void realizoUnaPeticionPostAlServicio(String servicio) {
        try {
            step = "Realizo una peticion post al servicio " + servicio;
            switch (servicio) {
                case "LOGIN NUEVOVIAJE CRT":
                    MetodosGenericos.imprimerConsolaMsjPositivoMetodos(step);
                    login.loginNuevoViajeCRT(servicio);
                    break;
                case "loginclientes":
                    MetodosGenericos.imprimerConsolaMsjPositivoMetodos(step);
                    login.loginClientes(servicio);
                    break;
                case "Login":
                    MetodosGenericos.imprimerConsolaMsjPositivoMetodos(step);
                    login.login();
                    break;
                default:
                    PdfBciReports.addReport("Realizo una peticion post al servicio:" + servicio, "Servicio no encontrado", EstadoPrueba.FAILED, true);
                    break;
            }
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(e));
        }
    }

    @And("Visualizo el campo {string} desplegado como {string}")
    public void visualizoElCampoDesplegadoComo(String camp, String stacode) {
        try {
            PdfBciReports.addReport("Visualizo el campo " + camp + " desplegado como", "statusCode: " + stacode, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(e));
        }
    }

    @And("Realizo una peticion get al servicio {string}")
    public void realizoUnaPeticionGetAlServicio(String servicio) {
        switch (servicio) {
            case "Obtener Detalle Publicaciones Proveedor":
                MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_GET_SERV + servicio);
                msConfirming.ObtenerDetallePublicacionesProveedor(servicio);
                break;
            case "ObtenerPublicacionesProveedor":
                MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_GET_SERV + servicio);
                msConfirming.ObtenerPublicacionesProveedor(servicio);
                break;
            case "Obtener Configuracion Proveedor":
                MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_GET_SERV + servicio);
                msConfirming.obtenerConfiguracionProveedor(servicio);
                break;
            case "estadoProveedor":
                MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_GET_SERV + servicio);
                PdfBciReports.addReport(MSJ_GET_SERV + servicio, "Peticion realizada correctamente.", EstadoPrueba.PASSED, false);
                msConfirming.estadoProveedor();
                break;
            case "publicaciones ms exp":
                MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_GET_SERV + servicio);
                PdfBciReports.addReport(MSJ_GET_SERV + servicio, "Peticion realizada correctamente..", EstadoPrueba.PASSED, false);
                msConfirming.publicacionesMSdeEXPyNEG();
                break;
            case "publicaciones ms neg":
                MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_GET_SERV + servicio);
                PdfBciReports.addReport(MSJ_GET_SERV + servicio, "Peticion realizada correctamente", EstadoPrueba.PASSED, false);
                msConfirming.publicacionesMSdeEXPyNEG();
                break;
            default:
                PdfBciReports.addReport(MSJ_GET_SERV + servicio, "Servicio no encontrado", EstadoPrueba.FAILED, true);
                break;
        }

    }

    @When("Seteo y visualizo credenciales en el body {string} {string} y {string}")
    public void seteoYVisualizoCredencialesEnElBodyY(String password, String grant_type, String rut) {
        password1 = password;
        grandType1 = grant_type;
        rut1 = rut;
        PdfBciReports.addReport("Seteo y visualizo credenciales en el body password: " + password1 + " grant_type: " + grandType1 + " y rut: " + rut, "Se setean correctamente", EstadoPrueba.PASSED, false);
    }

    @And("Valido en respon body Codigo {string}")
    public void validoEnResponBodyCodigo(String codigo) {
        if (codigo1.equals(codigo)) {
            PdfBciReports.addReport("Valido en respon body Codigo: " + codigo, "Validacion exitosa", EstadoPrueba.PASSED, false);
        } else {
            PdfBciReports.addReport("Valido en respon body Codigo: " + codigo, "Validacion fallida codigo: " + codigo1, EstadoPrueba.FAILED, true);
        }
    }

    @And("Valido en respon body mensaje {string}")
    public void validoEnResponBodyMensaje(String mensaje) {
        MetodosGenericos.imprimerConsolaMsjPositivo(mensaje);
        PdfBciReports.addReport("Valido en respon body mensaje: " + mensaje1, "Validacion exitosa", EstadoPrueba.PASSED, false);
    }

    @When("Seteo la URL {string} a validar")
    public void seteoLaURLAValidar(String url_ms) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo(MSJ_SETEO_URL);
            url = url_ms;
            MetodosGenericos.imprimerConsolaMsjPositivo(url_ms);
            PdfBciReports.addReport("Seteo la URL " + url_ms + " a validar", "Seteada correctamente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjPositivo(String.valueOf(e));
        }
    }

    @And("Valido en respon body con detalle de la publicacion")
    public void validoEnResponBodyConDetalleDeLaPublicacion() {
        PdfBciReports.addReport("Valido en respon body con detalle de la publicacion", body1, EstadoPrueba.PASSED, false);
    }

    @And("Visualizo datos corresponden a respuesta del ms")
    public void visualizoDatosCorrespondenARespuestaDelMs() {
        MetodosGenericos.imprimerConsolaMsjPositivo("Visualizo datos corresponden a respuesta del ms");
    }

    @And("Valido que venga agrupado al grupo correspondiente")
    public void validoQueVengaAgrupadoAlGrupoCorrespondiente() {
        MetodosGenericos.imprimerConsolaMsjPositivo("Valido que venga agrupado al grupo correspondiente");
    }

    @And("Validar que se genere fechaPago correcto para todos iguales")
    public void validarQueSeGenereFechaPagoCorrectoParaTodosIguales() {
        MetodosGenericos.imprimerConsolaMsjPositivo("Validar que se genere fechaPago correcto para todos iguales");
    }

    @And("Validar que campo se genere fecha_pago igual a fechaPago de MS")
    public void validarQueCampoSeGenereFecha_pagoIgualAFechaPagoDeMS() {
        MetodosGenericos.imprimerConsolaMsjPositivo("Validar que campo se genere fecha_pago igual a fechaPago de MS");
    }

    @And("Validar que se genere numeroFolio correcto")
    public void validarQueSeGenereNumeroFolioCorrecto() {
        PdfBciReports.addReport("Validar que se genere numeroFolio correcto", "", EstadoPrueba.PASSED, false);
    }

    @And("Validar que se genere fechaPago correcto")
    public void validarQueSeGenereFechaPagoCorrecto() {
        PdfBciReports.addReport("Validar que se genere fechaPago correcto", "", EstadoPrueba.PASSED, false);

    }

    @And("Validar que se genere tipoDocumento correcto")
    public void validarQueSeGenereTipoDocumentoCorrecto() {
        PdfBciReports.addReport("Validar que se genere tipoDocumento correcto", "", EstadoPrueba.PASSED, false);

    }

    @And("Validar que se genere tasa correcto")
    public void validarQueSeGenereTasaCorrecto() {
        PdfBciReports.addReport("Validar que se genere tasa correcto", "", EstadoPrueba.PASSED, false);

    }

    @And("Validar que se genere diferenciaPrecio correcto")
    public void validarQueSeGenereDiferenciaPrecioCorrecto() {
        PdfBciReports.addReport("Validar que se genere diferenciaPrecio correcto", "", EstadoPrueba.PASSED, false);

    }

    @And("Validar que se genere montoDocumento correcto")
    public void validarQueSeGenereMontoDocumentoCorrecto() {
        PdfBciReports.addReport("Validar que se genere montoDocumento correcto", "", EstadoPrueba.PASSED, false);

    }

    @And("Validar que campo se genere num_doc igual a numeroFolio de MS")
    public void validarQueCampoSeGenereNum_docIgualANumeroFolioDeMS() {
        PdfBciReports.addReport("Validar que campo se genere num_doc igual a numeroFolio de MS", "", EstadoPrueba.PASSED, false);

    }

    @And("Validar que campo se genere tipo_documento igual a tipoDocumento de MS")
    public void validarQueCampoSeGenereTipo_documentoIgualATipoDocumentoDeMS() {
        PdfBciReports.addReport("Validar que campo se genere tipo_documento igual a tipoDocumento de MS", "", EstadoPrueba.PASSED, false);

    }

    @And("Validar que campo se genere tasa")
    public void validarQueCampoSeGenereTasa() {
        PdfBciReports.addReport("Validar que campo se genere tasa", "", EstadoPrueba.PASSED, false);

    }

    @And("Validar que campo se genere diferenciaPrecio")
    public void validarQueCampoSeGenereDiferenciaPrecio() {
        PdfBciReports.addReport("Validar que campo se genere diferenciaPrecio", "", EstadoPrueba.PASSED, false);

    }

    @And("Validar que campo se genere monto_publicado es igual a montoDocumento de MS")
    public void validarQueCampoSeGenereMonto_publicadoEsIgualAMontoDocumentoDeMS() {
        PdfBciReports.addReport("Validar que campo se genere monto_publicado es igual a montoDocumento de MS", "", EstadoPrueba.PASSED, false);

    }

    @And("Validar que se genere {string} correcto")
    public void validarQueSeGenereCorrecto(String dato) {
        PdfBciReports.addReport("Validar que se genere " + dato, "", EstadoPrueba.PASSED, false);
    }

    @And("Valido en respon body grupo {string} plazoHabil es {string}")
    public void validoEnResponBodyGrupoPlazoHabilEs(String grupo, String condicion) {
        PdfBciReports.addReport("Valido en respon body grupo " + grupo + " plazoHabil es " + condicion, "", EstadoPrueba.PASSED, false);
    }

    @And("Valido datos de la linea de credito del pagado")
    public void validoDatosDeLaLineaDeCreditoDelPagado() {
        PdfBciReports.addReport("Valido datos de la linea de credito del pagado", "", EstadoPrueba.PASSED, false);
    }
}