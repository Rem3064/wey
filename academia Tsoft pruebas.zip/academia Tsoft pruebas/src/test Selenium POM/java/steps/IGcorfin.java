package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Back.MsIgCorfin;
import pages.bd.CorfinBD;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.FeatureControlled;
import utils.MetodosGenericos;

import java.sql.SQLException;

import static constants.Constants.*;
import static utils.FeatureControlled.*;

public class IGcorfin {
    private static final MsIgCorfin msIgCorfin = new MsIgCorfin();
    private static final CorfinBD corfinBD = new CorfinBD();

    private static final String VAL_RESBODY_1 = "valido respuesta del respon body: ";
    private static final String VAL_CORRECTAMENTE = "Se valida correctamente";
    private static final String VAL_CAMPO_1 = "campo: ";
    private static final String VAL_RESBODY_2 = "Se obtiene el valor del responseBody: ";
    private static final String VAL_BD_PAR_DES = "visualizo en BD par_des ";

    @Then("realizo una peticion get al servicio {string}")
    public void realizoUnaPeticionGetAlServicio(String servicio) {
        try {
            step = "realizo una peticion get al servicio " + servicio;
            switch (servicio) {
                case "Calcular SPREAD":
                    printStep();
                    msIgCorfin.calcularSpreadyTasaDeNegocio(servicio);
                    break;
                case "Calcular TASANEGOCIO":
                    msIgCorfin.calcularSpreadyTasaDeNegocio(servicio);
                    break;
                case "Publicaciones":
                    msIgCorfin.peticionGetServicioPublicaciones(servicio);
                    break;
                case "Proveedores":
                    msIgCorfin.peticionGetServicioProveedores(servicio);
                    break;
                default:
                    PdfBciReports.addReport("realizo una petcion get al servicio " + servicio, "servicio no encontrado", EstadoPrueba.FAILED, true);
                    break;
            }
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("visualizo que el respond body que la peticion se genero correctamente")
    public void visualizoQueElRespondBodyQueLaPeticionSeGeneroCorrectamente() {
        try {
            PdfBciReports.addReport("visualizo que el respond body que la peticion se genero correctamente", "la peticion se genero correctamente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("ingreso a BD Corfin con Host {string} puerto {string} User {string} PassWord {string}")
    public void ingresoABDCorfinConHostPuertoUserPassWord(String host, String puerto, String user, String passwd) {
        try {
            PdfBciReports.addReport("Ingreso a BD Corfin", " Host: " + host + " Puerto: " + puerto + " User: " + user + " Password: " + passwd, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("ejecuto la query sql para validar que el valor spread sea igual a la respond body del servicio {string}")
    public void ejecutoLaQuerySqlParaValidarQueElValorSpreadSeaIgualALaRespondBodyDelServicio(String service) {
        try {
            PdfBciReports.addReport("ejecuto la query sql para validar que el valor spread sea igual a la respond body del servicio " + service, "se ejecuta la query correctamente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("ejecuto la query sql para validar que el valor tasa de negocio sea igual a la respond body del servicio {string}")
    public void ejecutoLaQuerySqlParaValidarQueElValorTasaDeNegocioSeaIgualALaRespondBodyDelServicio(String service2) {
        try {
            PdfBciReports.addReport("ejecuto la query sql para validar que el valor spread sea igual a la respond body del servicio " + service2, "se ejecuta la query correctamente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("valido que cuando se conecta en certificacion el pod sea desplegado en azure stack")
    public void validoQueCuandoSeConectaEnCertificacionElPodSeaDesplegadoEnAzureStack() {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("valido que cuando se conecta en certificacion el pod sea desplegado en azure stack");
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @When("ejecuto SP {string}")
    public void ejecutoSP(String sp) {
        try {
            switch (sp) {
                case "exec sp_nv_devuelve_publicaciones_proveedor_portal('52010334','1')":
                    corfinBD.execSpNvDevuelvePublicacionesProveedorPortal1();
                    break;
                case "exec sp_nv_devuelve_detalle_publicacion_proveedor_portal('52010334','1','96500950','7')":
                    corfinBD.execSpNvDevuelveDetallePublicacionesProveedorPortal1();
                    break;
                default:
                    PdfBciReports.addReport("ejecuto SP: " + sp, "no se encuentra el SP, favor revisar.", EstadoPrueba.FAILED, true);
                    break;
            }
        } catch (SQLException e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }

    }

    @Then("visualizo respuesta correcta con maquina virtual")
    public void visualizoRespuestaCorrectaConMaquinaVirtual() {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("visualizo respuesta correcta con maquina virtual");
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @When("seteo la URL {string} a validar")
    public void seteoLaURLAValidar(String url_ms) {
        try {
            MetodosGenericos.imprimerConsolaMsjPositivo("Seteo la URL del MS a validar");
            url = url_ms;
            MetodosGenericos.imprimerConsolaMsjPositivo(url_ms);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("comparo con respuesta de SP que el respond body que la peticion se genero correctamente")
    public void comparoConRespuestaDeSPQueElRespondBodyQueLaPeticionSeGeneroCorrectamente() {
        try {
            PdfBciReports.addReport("Comparo Con Respuesta De SP ", "Peticion del ResponseBody Se Genero Correctamente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("valido respuesta del respon body {string} : {string}")
    public void validoRespuestaDelResponBody(String campo, String valor) {
        try {
            PdfBciReports.addReport("valido respuesta del respon body", "" + campo + " : " + valor, EstadoPrueba.PASSED, false);
            switch (campo) {
                case "rut":
                    if (proveedorRut1.equals(valor)) {
                        PdfBciReports.addReport(VAL_RESBODY_1 + campo, VAL_CORRECTAMENTE, EstadoPrueba.PASSED, false);
                    } else {
                        PdfBciReports.addReport(VAL_CAMPO_1 + campo, VAL_RESBODY_2 + proveedorRut1, EstadoPrueba.PASSED, false);
                        PdfBciReports.addReport(VAL_CAMPO_1 + campo, "" + valor, EstadoPrueba.PASSED, false);
                        PdfBciReports.addReport(VAL_RESBODY_1 + campo, "Validacion Incorrecta, revisar", EstadoPrueba.FAILED, true);
                        break;
                    }
                    break;
                case "estado":
                    if (proveedorEstado1.equals(valor)) {
                        PdfBciReports.addReport(VAL_RESBODY_1 + campo, VAL_CORRECTAMENTE, EstadoPrueba.PASSED, false);
                    } else {
                        PdfBciReports.addReport(VAL_CAMPO_1 + campo, VAL_RESBODY_2 + proveedorEstado1, EstadoPrueba.PASSED, false);
                        PdfBciReports.addReport(VAL_CAMPO_1 + campo, "" + valor, EstadoPrueba.PASSED, false);
                        PdfBciReports.addReport(VAL_RESBODY_1 + campo, "Validacion Incorrecta, valores no son iguales favor revisar", EstadoPrueba.FAILED, true);
                        break;
                    }
                    break;
                case "razonSocial":
                    if (proveedorRazonSocial1.equals(valor)) {
                        PdfBciReports.addReport(VAL_RESBODY_1 + campo, VAL_CORRECTAMENTE, EstadoPrueba.PASSED, false);
                    } else {
                        PdfBciReports.addReport(VAL_CAMPO_1 + campo, VAL_RESBODY_2 + proveedorRazonSocial1, EstadoPrueba.PASSED, false);
                        PdfBciReports.addReport(VAL_CAMPO_1 + campo, "" + valor, EstadoPrueba.PASSED, false);
                        PdfBciReports.addReport(VAL_RESBODY_1 + campo, "Validacion Incorrecta, valores no son iguales favor revisar", EstadoPrueba.FAILED, true);
                        break;
                    }
                    break;
                default:
                    PdfBciReports.addReport("No se encuentra el campo seleccionado: " + campo, "favor revisar.", EstadoPrueba.FAILED, true);
                    break;
            }
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("ejecuto la query Consultar Provvedor")
    public void ejecutoLaQueryConsultarProvvedor() {
        try {
            String scenario = FeatureControlled.returnEscenario();
            MetodosGenericos.imprimerConsolaMsjPositivo(scenario);
            switch (scenario) {
                case "1.Desplegar endpoint con proveedor OK en MS para validar respond del servicio habilitado (Example 1)":
                    corfinBD.consultarProveedor1();
                    break;
                case "2.Desplegar endpoint con proveedor No Registrado en MS para validar respond del servicio No registrado (Example 1)":
                    corfinBD.consultarProveedor2();
                    break;
                default:
                    PdfBciReports.addReport("Scenario: " + scenario, "no se encuentra el escenario", EstadoPrueba.FAILED, true);
                    break;
            }
        } catch (SQLException e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @And("visualizo en BD par_des {string}")
    public void visualizoEnBDPar_des(String valor) {
        try {
            switch (valor) {
                case "ACTIVO":
                    if (valor.equals(par_des)) {
                        PdfBciReports.addReport(VAL_BD_PAR_DES + valor, "par_des esta ACTIVO", EstadoPrueba.PASSED, false);
                    } else {
                        PdfBciReports.addReport(VAL_BD_PAR_DES + valor, "par_des esta INACTIVO", EstadoPrueba.FAILED, true);
                    }
                    break;
                case "INACTIVO":
                    if (valor.equals(par_des)) {
                        PdfBciReports.addReport(VAL_BD_PAR_DES + valor, "Se valida que el par_des esta INACTIVO", EstadoPrueba.PASSED, false);
                    } else {
                        PdfBciReports.addReport(VAL_BD_PAR_DES + valor, "par_des esta ACTIVO", EstadoPrueba.FAILED, true);
                    }
                    break;
                default:
                    PdfBciReports.addReport("no se visualizo en BD par_des " + valor, "favor revisar la prueba", EstadoPrueba.FAILED, true);
                    break;
            }
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @When("Ejecuto la query sql para generar resumen de publicaciones")
    public void ejecutoLaQuerySqlParaGenerarResumenDePublicaciones() {
        try {
            PdfBciReports.addReport("ejecuto la query sql para generar resumen de publicaciones", "se ejecuta la query exec", EstadoPrueba.PASSED, false);
            String scenario = FeatureControlled.returnEscenario();
            MetodosGenericos.imprimerConsolaMsjPositivo(scenario);
            switch (scenario) {
                case "1_Generar de un SP para traer un resumen de las publicaciones de un pagador Activo Tasa de Negocio para un proveedor con Publicaciones en el Portal de Proveedores":
                    corfinBD.generarSpResumenPublicacionesPagadorActivoTasaNegocioParaProveedorPublicacionesPortalProveedores();
                    break;
                case "2_Generar de un SP para traer el detalle de las publicaciones de un pagador Activo Tasa de Negocio para un proveedor con Publicaciones en el Portal de Proveedores":
                    corfinBD.GenerarSpDetallePublicacionesPagadorActivoTasaNegocioParaProveedorPublicacionesPortalProveedores();
                    break;
                case "3_Generar de un SP para traer un resumen de las publicaciones de un pagador Activo Spread para un proveedor con Publicaciones en el Portal de Proveedores":
                    corfinBD.GenerarSpResumenPublicacionesPagadorActivoSpreadParaProveedorPublicacionesPortalProveedores();
                    break;
                case "4_Generar de un SP para traer el detalle de las publicaciones de un pagador Activo Spread para un proveedor con Publicaciones en el Portal de Proveedores":
                    corfinBD.GenerarSpDetallePublicacionesPagadorActivoSpreadParaProveedorPublicacionesPortalProveedores();
                    break;
                default:
                    PdfBciReports.addReport("Scenario: " + scenario, "no se encuentra las publicaciones del pagador...", EstadoPrueba.FAILED, true);
                    break;
            }
        } catch (SQLException e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @Then("Visualizo que se genere el resumen de publicaciones")
    public void visualizoQueSeGenereElResumenDePublicaciones() {
        try {
            PdfBciReports.addReport("visualizo que se genere el resumen de publicaciones", "se obtienen los datos correctamente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }

    @Then("Visualizo que se genere el detalle de publicaciones")
    public void visualizoQueSeGenereElDetalleDePublicaciones() {
        try {
            PdfBciReports.addReport("visualizo que se genere el detalle de publicaciones", "se obtienen los datos correctamente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjNegativo(String.valueOf(e));
        }
    }
}