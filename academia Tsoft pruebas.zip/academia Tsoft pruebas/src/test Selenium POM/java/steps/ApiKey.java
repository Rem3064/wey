package steps;

import io.cucumber.java.en.And;
import pages.Back.Login;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.MetodosGenericos;

public class ApiKey {
    private static final Login login = new Login();

    @And("realizo una peticion post al servicio {string}")
    public void realizoUnaPeticionPostAlServicio(String servicio) {
        try {
            switch (servicio) {
                case "loginclientes":
                    MetodosGenericos.imprimerConsolaMsjPositivo("realizo una peticion post al servicio loginclientes");
                    login.loginClientes(servicio);
                    break;
                case "Login":
                    MetodosGenericos.imprimerConsolaMsjPositivo("realizo una peticion post al servicio Login");
                    login.login();
                    break;
                default:
                    PdfBciReports.addReport("nombrePaso", "descripcion ", EstadoPrueba.PASSED, false);
                    break;
            }
        } catch (Exception e) {
            MetodosGenericos.imprimerConsolaMsjPositivoMetodos(String.valueOf(e));
        }
    }
}