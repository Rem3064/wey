package utils;

import org.testng.annotations.Test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class Encriptado {


    @Test()
    public void escriptarIP() {
        MetodosGenericos.imprimerConsolaMsjPositivo("El nuevo valor es ip: " + AES.encrypt("bcirg3crtdbfacod001.database.windows.net"));
    }

    @Test()
    public void escriptarUser() {
        MetodosGenericos.imprimerConsolaMsjPositivo("El nuevo valor es user: " + AES.encrypt("admin_db@bcirg3crtdbfacod001"));

    }

    @Test()
    public void escriptarPass() {
        MetodosGenericos.imprimerConsolaMsjPositivo("El nuevo valor es pass: " + AES.encrypt("C3T4I*_17o"));
    }

    @Test()
    public void desencriptar() {
        MetodosGenericos.imprimerConsolaMsjPositivo("El valor original: " + AES.decrypt("oCNdR/L7iFyreb1MYW/C6g=="));
    }
}