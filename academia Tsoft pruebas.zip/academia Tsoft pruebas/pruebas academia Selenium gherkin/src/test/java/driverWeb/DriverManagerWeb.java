package driverWeb;

import constants.Navegador;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.Assert;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import static utils.MetodosGenericos.esperar;

public class DriverManagerWeb {
    public static final Logger LOGGER = Logger.getLogger("DriverManagerWeb");
    public static final String CONEXION_WINDOWS = "[Maquina Virtual windows]-Se realiza la conexión remota: ";
    private DesiredCapabilities capabilities = new DesiredCapabilities();
    private WebDriver webDriver;
    private File root = new File("driverNavegador");
    private String extensionDriver = "";
    private String seleniumGridMacMini = "http://10.252.152.193:5555/wd/hub";
    private List<String> seleniumGrid184 = Arrays.asList("http://161.131.141.184:5555/wd/hub", "http://161.131.141.184:5556/wd/hub", "http://161.131.141.184:5557/wd/hub", "http://161.131.141.184:5558/wd/hub");
    private String seleniumGrid205 = "http://172.16.98.205:4444/wd/hub";
    private String seleniumGrid150 = "http://172.16.98.150:4444/wd/hub";
    private String seleniumGrid113 = "http://172.16.98.113:4444/wd/hub";
    private String seleniumGrid116 = "http://172.16.98.116:4444/wd/hub";
    private String seleniumGrid116puerto5555 = "http://172.16.98.116:5555/wd/hub";
    private String seleniumGrid226 = "http://172.16.98.226:5566/wd/hub";
    private List<String> seleniumGrid22 = Arrays.asList("http://172.16.98.22:5555/wd/hub", "http://172.16.98.22:5556/wd/hub", "http://172.16.98.22:5557/wd/hub", "http://172.16.98.22:5558/wd/hub");
    private List<String> seleniumGrid136 = Arrays.asList("http://172.16.98.136:5555/wd/hub", "http://172.16.98.136:5556/wd/hub", "http://172.16.98.136:5557/wd/hub", "http://172.16.98.136:5558/wd/hub");
    private List<String> seleniumGrid222 = Arrays.asList("http://172.16.98.222:5555/wd/hub", "http://172.16.98.222:5556/wd/hub", "http://172.16.98.222:5557/wd/hub", "http://172.16.98.222:5558/wd/hub");
    private List<String> seleniumGrid227 = Arrays.asList("http://172.16.98.227:5555/wd/hub", "http://172.16.98.227:5556/wd/hub", "http://172.16.98.227:5557/wd/hub", "http://172.16.98.227:5558/wd/hub");
    private String seleniumGridDevops = "http://172.16.98.117:4444/wd/hub";
    private Navegador tipoNavegador;
    private String seleniumGrip = "";
    private boolean vistaHeadless = true;

    public DriverManagerWeb() {
    }

    public static void iniciarTerminal() {
        ProcessBuilder processBuilder = null;
        Process process = null;

        try {
            processBuilder = new ProcessBuilder(new String[]{"/usr/bin/osascript", "-e", "tell app \"Terminal\"", "-e", "set currentTab to do script (open -n -a /Applications/Google\\ Chrome.app/Contents/MacOS/Google\\ Chrome --args --user-data-dir=\"/tmp/chrome_dev_test\" --disable-testbase.web-security)", "-e", "end tell"});
            process = processBuilder.start();
            process.waitFor();
            esperar(5);
        } catch (Exception var3) {
            var3.printStackTrace();
        }

    }

    public boolean isVistaHeadless() {
        return this.vistaHeadless;
    }

    public void setVistaHeadless(boolean vistaHeadless) {
        this.vistaHeadless = vistaHeadless;
    }

    public Navegador getTipoNavegador() {
        return this.tipoNavegador;
    }

    public void setTipoNavegador(Navegador tipoNavegador) {
        this.tipoNavegador = tipoNavegador;
    }

    protected void resolveDriverWeb(String tipoConexion, Navegador nav, String ambURL) {
        this.seleniumGrip = tipoConexion;
        this.resolveDriverWeb(nav, ambURL, "", false, false, "");
    }

    protected void resolveDriverWeb(String tipoConexion, Navegador nav, String ambURL, boolean headless) {
        this.seleniumGrip = tipoConexion;
        this.setVistaHeadless(headless);
        this.resolveDriverWeb(nav, ambURL, "", false, false, "");
    }

    protected void resolveDriverWeb(Navegador nav, String ambURL) {
        this.resolveDriverWeb(nav, ambURL, "", false, false, "");
    }

    protected void resolveDriverWeb(Navegador nav, String ambURL, String nombreDriverVersion) {
        this.resolveDriverWeb(nav, ambURL, "", false, false, nombreDriverVersion);
    }

    protected void resolveDriverWeb(Navegador nav, String ambURL, String archivoExtension, boolean extensionesNavegador) {
        this.resolveDriverWeb(nav, ambURL, archivoExtension, extensionesNavegador, false, "");
    }

    protected void resolveDriverWeb(Navegador nav, String ambURL, String archivoExtension, boolean extensionesNavegador, boolean argNoSandbox) {
        this.resolveDriverWeb(nav, ambURL, archivoExtension, extensionesNavegador, argNoSandbox, "");
    }

    protected void resolveDriverWeb(Navegador nav, String ambURL, String archivoExtension, boolean extensionesNavegador, boolean argNoSandbox, String nombreDriverVersion) {
        String os = System.getProperty("os.name").toLowerCase();
        LOGGER.info("\nSistema operativo ->" + System.getProperty("os.name").toLowerCase() + "\n");
        if (!os.contains("mac") && !os.contains("linux")) {
            this.extensionDriver = ".exe";
        }

        this.setTipoNavegador(nav);
        File driverPath;
        switch(nav) {
            case Chrome:
                LOGGER.info("Se selecciona Chrome");
                if (!nombreDriverVersion.trim().equals("")) {
                    driverPath = new File(this.root, nombreDriverVersion + this.extensionDriver);
                } else {
                    driverPath = new File(this.root, "chromedriver" + this.extensionDriver);
                }

                System.setProperty("webdriver.chrome.driver", driverPath.getAbsolutePath());
                ChromeOptions options = new ChromeOptions();
                options.addArguments(new String[]{"--disable-notifications"});
                options.setCapability("acceptSslCerts", true);
                options.setCapability("acceptInsecureCerts", true);
                LoggingPreferences logPrefs = new LoggingPreferences();
                logPrefs.enable( LogType.PERFORMANCE, Level.ALL );
                options.setCapability( "goog:loggingPrefs", logPrefs );
                if (argNoSandbox) {
                    options.addArguments(new String[]{" -no-sandbox"});
                }

                if (extensionesNavegador) {
                    File cspPath = new File(this.root, archivoExtension);
                    options.addExtensions(new File[]{cspPath.getAbsoluteFile()});
                    this.capabilities.setCapability("goog:chromeOptions", options);
                    options.merge(this.capabilities);
                }

                HashMap<String, Object> preferencias = new HashMap();
                preferencias.put("profile.default_content_settings.popups", 0);
                //preferencias.put("download.default_directory", this.root.getAbsolutePath());
                options.setExperimentalOption("prefs", preferencias);
                this.webDriver = new ChromeDriver(options);
                this.capabilities.setBrowserName("Chrome");
                this.webDriver.manage().window().maximize();
                break;
            case Explorer:
                LOGGER.info("Se selecciona Explorer");
                if (!nombreDriverVersion.trim().equals("")) {
                    driverPath = new File(this.root, nombreDriverVersion + this.extensionDriver);
                } else {
                    driverPath = new File(this.root, "IEDriverServer" + this.extensionDriver);
                }

                System.setProperty("webdriver.ie.driver", driverPath.getAbsolutePath());
                this.capabilities.setCapability("ignoreProtectedModeSettings", true);
                this.capabilities.setCapability("ie.ensureCleanSession", true);
                this.capabilities.setCapability("ignoreZoomSetting", true);
                this.capabilities.setCapability("acceptSslCerts", true);
                InternetExplorerOptions optionsIE = new InternetExplorerOptions();
                optionsIE.addCommandSwitches(new String[]{"--disable-notifications"});
                this.webDriver = new InternetExplorerDriver(optionsIE);
                this.capabilities.setBrowserName("Explorer");
                this.webDriver.manage().window().maximize();
                break;
            case Firefox:
                LOGGER.info("Se selecciona Firefox");
                if (!nombreDriverVersion.trim().equals("")) {
                    driverPath = new File(this.root, nombreDriverVersion + this.extensionDriver);
                } else {
                    driverPath = new File(this.root, "geckodriver" + this.extensionDriver);
                }

                System.setProperty("webdriver.gecko.driver", driverPath.getAbsolutePath());
                FirefoxOptions optionsf = new FirefoxOptions();
                optionsf.addArguments(new String[]{"--disable-notifications"});
                optionsf.setProfile(this.preferenciasFirefox());
                this.webDriver = new FirefoxDriver(optionsf);
                this.capabilities.setBrowserName("Firefox");
                this.webDriver.manage().window().maximize();
                break;
            case Edge:
                LOGGER.info("Se selecciona Edge");
                if (!nombreDriverVersion.trim().equals("")) {
                    driverPath = new File(this.root, nombreDriverVersion + this.extensionDriver);
                } else {
                    driverPath = new File(this.root, "msedgedriver" + this.extensionDriver);
                }

                System.setProperty("webdriver.edge.driver", driverPath.getAbsolutePath());
                this.webDriver = new EdgeDriver();
                this.capabilities.setBrowserName("Microsoft Edge");
                this.webDriver.manage().window().maximize();
                break;
            case Safari:
                LOGGER.info("Se selecciona Safari");
                if (!nombreDriverVersion.trim().equals("")) {
                    driverPath = new File(this.root, nombreDriverVersion + this.extensionDriver);
                } else {
                    driverPath = new File(this.root, "safaridriver" + this.extensionDriver);
                }

                System.setProperty("webdriver.safari.driver", driverPath.getAbsolutePath());
                this.webDriver = new SafariDriver();
                this.capabilities.setBrowserName("Safari");
                this.webDriver.manage().window().maximize();
                break;
            case ChromeRemote:
                LOGGER.info("Se selecciona Chrome remoto desplegado en ambiente Devops");
                ChromeOptions opt = new ChromeOptions();
                if (this.isVistaHeadless()) {
                    opt.addArguments(new String[]{"headless"});
                }

                opt.addArguments(new String[]{"window-size=1300x900"});
                HashMap<String, Object> preferenciasC = new HashMap();
                preferenciasC.put("profile.default_content_settings.popups", 0);
                preferenciasC.put("download.default_directory", this.root.getAbsolutePath());
                opt.setExperimentalOption("prefs", preferenciasC);
                this.getTipoConexion(opt);
                this.webDriver.manage().window().maximize();
                break;
            case FirefoxRemote:
                LOGGER.info("Se selecciona Firefox remoto desplegado en ambiente Devops");
                FirefoxOptions optionsfr = new FirefoxOptions();
                optionsfr.addArguments(new String[]{"--disable-notifications"});
                optionsfr.setProfile(this.preferenciasFirefox());
                this.getTipoConexion(optionsfr);
                break;
            case EdgeRemote:
                LOGGER.info("Se selecciona Edge remoto desplegado en ambiente Devops");
                EdgeOptions optEdge = new EdgeOptions();
                this.getTipoConexion(optEdge);
                this.webDriver.manage().window().maximize();
                break;
            case IExplorerRemote:
                LOGGER.info("Se selecciona Internet Explorer remoto desplegado en ambiente Devops");
                InternetExplorerOptions optIE = new InternetExplorerOptions();
                optIE.setCapability("ignoreProtectedModeSettings", true);
                optIE.setCapability("ie.ensureCleanSession", true);
                optIE.setCapability("ignoreZoomSetting", true);
                optIE.setCapability("acceptSslCerts", true);
                this.getTipoConexion(optIE);
                this.webDriver.manage().window().maximize();
                break;
            case ChromeProxy:
                LOGGER.info("Se selecciona ChromeProxy");
                ChromeOptions optionsProxy = new ChromeOptions();
                String proxy = "localhost:7070";
                optionsProxy.addArguments(new String[]{"--proxy-server=http://" + proxy});
                optionsProxy.addArguments(new String[]{"--disable-notifications"});
                driverPath = new File(this.root, "chromedriver" + this.extensionDriver);
                System.setProperty("webdriver.chrome.driver", driverPath.getAbsolutePath());
                this.webDriver = new ChromeDriver(optionsProxy);
                this.capabilities.setBrowserName("Chrome");
                this.webDriver.manage().window().maximize();
                break;
            default:
                LOGGER.info("No es posible lanzar el navegador, no se reconoce el navegador: " + nav);
                PdfBciReports.addReport("resolveDriver", "No se reconoce el navegador: " + nav, EstadoPrueba.FAILED, true);
        }

        this.webDriver.get(ambURL);
    }

    protected WebDriver getDriverWeb() {
        return this.webDriver;
    }

    protected void setDriverWeb(WebDriver webDriver) {
        this.webDriver = webDriver;
    }

    protected Dimension getScreenSizeWeb() {
        return this.webDriver.manage().window().getSize();
    }

    private FirefoxProfile preferenciasFirefox() {
        FirefoxProfile profile = new FirefoxProfile();
        profile.setPreference("browser.download.folderList", 2);
        profile.setPreference("browser.download.dir", this.root.getAbsolutePath());
        profile.setPreference("browser.download.useDownloadDir", true);
        profile.setPreference("browser.download.manager.showWhenStarting", false);
        profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/octet-stream");
        profile.setPreference("browser.download.manager.showAlertOnComplete", false);
        profile.setPreference("browser.download.manager.useWindow", false);
        profile.setPreference("pdfjs.disabled", false);
        return profile;
    }

    private void getTipoConexion(Capabilities capability) {
        String seleniumGridNav = "";

        try {
            String var3 = this.seleniumGrip;
            byte var4 = -1;
            switch(var3.hashCode()) {
                case 48659:
                    if (var3.equals("113")) {
                        var4 = 4;
                    }
                    break;
                case 48662:
                    if (var3.equals("116")) {
                        var4 = 5;
                    }
                    break;
                case 48663:
                    if (var3.equals("117")) {
                        var4 = 9;
                    }
                    break;
                case 48780:
                    if (var3.equals("150")) {
                        var4 = 7;
                    }
                    break;
                case 49591:
                    if (var3.equals("205")) {
                        var4 = 8;
                    }
                    break;
                case 49654:
                    if (var3.equals("226")) {
                        var4 = 10;
                    }
                    break;
                case 49667:
                    if (var3.equals("22C")) {
                        var4 = 11;
                    }
                    break;
                case 49669:
                    if (var3.equals("22E")) {
                        var4 = 14;
                    }
                    break;
                case 49670:
                    if (var3.equals("22F")) {
                        var4 = 12;
                    }
                    break;
                case 1510511:
                    if (var3.equals("136C")) {
                        var4 = 15;
                    }
                    break;
                case 1510513:
                    if (var3.equals("136E")) {
                        var4 = 18;
                    }
                    break;
                case 1510514:
                    if (var3.equals("136F")) {
                        var4 = 16;
                    }
                    break;
                case 1515254:
                    if (var3.equals("184C")) {
                        var4 = 0;
                    }
                    break;
                case 1515256:
                    if (var3.equals("184E")) {
                        var4 = 3;
                    }
                    break;
                case 1515257:
                    if (var3.equals("184F")) {
                        var4 = 1;
                    }
                    break;
                case 1539217:
                    if (var3.equals("222C")) {
                        var4 = 19;
                    }
                    break;
                case 1539219:
                    if (var3.equals("222E")) {
                        var4 = 22;
                    }
                    break;
                case 1539220:
                    if (var3.equals("222F")) {
                        var4 = 20;
                    }
                    break;
                case 1539372:
                    if (var3.equals("227C")) {
                        var4 = 23;
                    }
                    break;
                case 1539374:
                    if (var3.equals("227E")) {
                        var4 = 26;
                    }
                    break;
                case 1539375:
                    if (var3.equals("227F")) {
                        var4 = 24;
                    }
                    break;
                case 1539932:
                    if (var3.equals("22IE")) {
                        var4 = 13;
                    }
                    break;
                case 46826096:
                    if (var3.equals("136IE")) {
                        var4 = 17;
                    }
                    break;
                case 46973129:
                    if (var3.equals("184IE")) {
                        var4 = 2;
                    }
                    break;
                case 47715982:
                    if (var3.equals("222IE")) {
                        var4 = 21;
                    }
                    break;
                case 47720787:
                    if (var3.equals("227IE")) {
                        var4 = 25;
                    }
                    break;
                case 1637537828:
                    if (var3.equals("116:5555")) {
                        var4 = 6;
                    }
            }

            switch(var4) {
                case 0:
                    seleniumGridNav = (String)this.seleniumGrid184.get(0);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 1:
                    seleniumGridNav = (String)this.seleniumGrid184.get(1);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 2:
                    seleniumGridNav = (String)this.seleniumGrid184.get(2);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 3:
                    seleniumGridNav = (String)this.seleniumGrid184.get(3);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 4:
                    seleniumGridNav = this.seleniumGrid113;
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 5:
                    seleniumGridNav = this.seleniumGrid116;
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 6:
                    seleniumGridNav = this.seleniumGrid116puerto5555;
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 7:
                    seleniumGridNav = this.seleniumGrid150;
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 8:
                    seleniumGridNav = this.seleniumGrid205;
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 9:
                    seleniumGridNav = this.seleniumGridDevops;
                    LOGGER.info("[Devops]-Se realiza la conexión remota: " + seleniumGridNav);
                    break;
                case 10:
                    seleniumGridNav = this.seleniumGrid226;
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 11:
                    seleniumGridNav = (String)this.seleniumGrid22.get(0);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 12:
                    seleniumGridNav = (String)this.seleniumGrid22.get(1);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 13:
                    seleniumGridNav = (String)this.seleniumGrid22.get(2);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 14:
                    seleniumGridNav = (String)this.seleniumGrid22.get(3);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 15:
                    seleniumGridNav = (String)this.seleniumGrid136.get(0);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 16:
                    seleniumGridNav = (String)this.seleniumGrid136.get(1);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 17:
                    seleniumGridNav = (String)this.seleniumGrid136.get(2);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 18:
                    seleniumGridNav = (String)this.seleniumGrid136.get(3);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 19:
                    seleniumGridNav = (String)this.seleniumGrid222.get(0);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 20:
                    seleniumGridNav = (String)this.seleniumGrid222.get(1);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 21:
                    seleniumGridNav = (String)this.seleniumGrid222.get(2);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 22:
                    seleniumGridNav = (String)this.seleniumGrid222.get(3);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 23:
                    seleniumGridNav = (String)this.seleniumGrid227.get(0);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 24:
                    seleniumGridNav = (String)this.seleniumGrid227.get(1);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 25:
                    seleniumGridNav = (String)this.seleniumGrid227.get(2);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                case 26:
                    seleniumGridNav = (String)this.seleniumGrid227.get(3);
                    LOGGER.info(CONEXION_WINDOWS + seleniumGridNav);
                    break;
                default:
                    seleniumGridNav = this.seleniumGridMacMini;
                    LOGGER.info("[MacMini]-Se realiza la conexión remota: " + seleniumGridNav);
            }

            this.webDriver = new RemoteWebDriver(new URL(seleniumGridNav), capability);
        } catch (MalformedURLException var5) {
            var5.printStackTrace();
            Assert.fail("[getTipoConexion] Error: Al realizar la conexión: " + var5.getMessage());
        }

    }
}
