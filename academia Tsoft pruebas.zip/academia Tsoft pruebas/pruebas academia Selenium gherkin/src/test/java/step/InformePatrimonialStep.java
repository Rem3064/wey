package step;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pages.informePatrimonial.InformePatrimonial;

import java.util.logging.Logger;


public class InformePatrimonialStep {
    public static final Logger LOGGER = Logger.getLogger("InformePatrimonialStep");
    InformePatrimonial informePatrimonial = new InformePatrimonial();


    @And("Visualizo card de informe {string}")
    public void visualizoCardDeInforme(String arg0) {
        informePatrimonial.visualizoCardDeInforme(arg0);
    }

    @And("Visualizo la pagina {string}")
    public void visualizoLaPagina(String arg0) {
        informePatrimonial.visualizoLaPagina(arg0);
    }

    @And("Valido el texto de la solicitud una vez realizada")
    public void validoElTextoDeLaSolicitudUnaVezRealizada(String arg0) {
        informePatrimonial.validoElTextoDeLaSolicitudUnaVezRealizada(arg0);
    }

    @And("Valido que el campo {string} contega informacion")
    public void validoQueElCampoContegaInformacion(String arg0) {
        informePatrimonial.validoQueElCampoContegaInformacion(arg0);
    }

    @Then("Valido modal de {string}")
    public void validoModalDe(String arg0, String arg1) {
        informePatrimonial.validoModalDe(arg0, arg1);
    }

    @And("Presiono el boton de {string} del modal")
    public void presionoElBotonDeDelModal(String arg0) {
        informePatrimonial.presionoElBotonDeDelModal(arg0);
    }

    @Then("Valido que no se visualice la card de informe {string}")
    public void validoQueNoSeVisualiceLaCardDeInforme(String arg0) {
        informePatrimonial.validoQueNoSeVisualiceLaCardDeInforme(arg0);
    }

    @And("Valido que el campo {string} no contega informacion")
    public void validoQueElCampoNoContegaInformacion(String arg0) {
        informePatrimonial.validoQueElCampoNoContegaInformacion(arg0);

    }

    @And("Valido que el boton de {string} se encuentre deshabilitado")
    public void validoQueElBotonDeSeEncuentreDeshabilitado(String arg0) {
        informePatrimonial.validoQueElBotonDeSeEncuentreDeshabilitado(arg0);
    }

    @And("Ingreso mail en formato incorrecto {string}")
    public void ingresoMailEnFormatoIncorrecto(String arg0) {
        informePatrimonial.ingresoMailEnFormatoIncorrecto(arg0);
    }

    @And("Valido el texto de advertencia mail incorrecto {string}")
    public void validoElTextoDeAdvertenciaMailIncorrecto(String arg0) {
        informePatrimonial.validoElTextoDeAdvertenciaMailIncorrecto(arg0);
    }

    @And("Elimino el texto del textbox de mail")
    public void eliminoElTextoDelTextboxDeMail() {
        informePatrimonial.eliminoElTextoDelTextboxDeMail();
    }

    @And("Valido el texto de advertencia mail vacio {string}")
    public void validoElTextoDeAdvertenciaMailVacio(String arg0) {
        informePatrimonial.validoElTextoDeAdvertenciaMailVacio(arg0);
    }
}
