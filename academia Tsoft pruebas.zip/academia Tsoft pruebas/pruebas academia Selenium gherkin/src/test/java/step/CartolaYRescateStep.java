package step;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pages.cartolaYRescate.CartolaYRescate;

import java.util.logging.Logger;
public class CartolaYRescateStep {

    public static final Logger LOGGER = Logger.getLogger("CartolaStep");;
    CartolaYRescate cartolaYRescate = new CartolaYRescate();
    @And("Ingreso nuevo monto a invertir {string} en invertir mas")
    public void ingresoNuevoMontoAInvertirEnInvertirMas(String arg0) {
    cartolaYRescate.ingresoNuevoMontoAInvertirEnInvertirMas(arg0);
    }

    @And("Presiono boton {string} en invertir mas")
    public void presionoBotonEnInvertirMas(String arg0) {
    cartolaYRescate.presionoBotonEnInvertirMas(arg0);
    }

    @And("Presiono el check de declarar y luego el boton de {string}")
    public void presionoElCheckDeDeclararYLuegoElBotonDe(String arg0) {
    cartolaYRescate.presionoElCheckDeDeclararYLuegoElBotonDe(arg0);
    }

    @Then("Presiono el boton de {string} en confirmacion de inversion")
    public void presionoElBotonDeEnConfirmacionDeInversion(String arg0) {
    cartolaYRescate.presionoElBotonDeEnConfirmacionDeInversion(arg0);
    }

    @And("visualizo pantalla de {string}")
    public void visualizoPantallaDe(String arg0) {
    cartolaYRescate.visualizoPantallaDe(arg0);
    }

    @Then("visualizo que no exista el boton de {string} en fondos USD")
    public void visualizoQueNoExistaElBotonDeEnFondosUSD(String arg0) {
   cartolaYRescate.visualizoQueNoExistaElBotonDeEnFondosUSD(arg0);
    }

    @And("Inspecciono la opcion de {string} en {string}")
    public void inspeccionoLaOpcionDeEn(String arg0, String arg1) {
    cartolaYRescate.inspeccionoLaOpcionDeEn(arg0,arg1);
    }

    @And("Modifico la URL y el codigo CLP a {string}")
    public void modificoLaURLYElCodigoCLPA(String arg0) {
    cartolaYRescate.modificoLaURLYElCodigoCLPA(arg0);
    }

    @Then("visualizo mensaje de error")
    public void visualizoMensajeDeError() {
    cartolaYRescate.visualizoMensajeDeError();
    }

    @Then("Visualizo mensaje {string}")
    public void visualizoMensaje(String arg0) {
    cartolaYRescate.visualizoMensaje(arg0);
    }

    @And("Presiono el boton {string} en modal Rescatar en el Fondo Mutuo")
    public void presionoElBotonEnModalRescatarEnElFondoMutuo(String arg0) {
    cartolaYRescate.presionoElBotonEnModalRescatarEnElFondoMutuo(arg0);
    }

    @And("Presiono {string} en {string}")
    public void presionoEn(String arg0, String arg1) {
    cartolaYRescate.presionoEn(arg0,arg1);
    }

    @Then("Visualizo que no existen botones de {string}")
    public void visualizoQueNoExistenBotonesDe(String arg0) {
    cartolaYRescate.visualizoQueNoExistenBotonesDe(arg0);
    }
}
