package step;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pages.carteras.Carteras;
import pages.fondosMutuos.FondosMutuos;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static constants.Constants.EXCEPCION;
import static reporter.EstadoPrueba.PASSED;
import static util.Acciones.reporteConYSinImagen;
import static util.Acciones.validaElemento;


public class CarteraInvertirStep {
    public static final Logger LOGGER = Logger.getLogger("CarteraInvertirStep");
       Carteras carteras = new Carteras();
    FondosMutuos fondosMutuos = new FondosMutuos();
    @And("presiono el boton INVERTIR en la cartera de {string}")
    public void presionoElBotonINVERTIREnLaCarteraDe(String arg0) {
        carteras.presionoElBotonINVERTIREnLaCarteraDe(arg0);
    }

    @And("Presiono boton {string} de la {string}")
    public void presionoBotonDeLa(String arg0, String arg1) {
    carteras.presionoBotonDeLa(arg0,arg1);
    }

    @Then("Valido modal {string}")
    public void validoModal(String arg0, String arg1) {
    carteras.validoModal(arg0,arg1);
    }

    @Then("Valido modal en vitrina {string}")
    public void validoModalEnVitrina(String arg0, String arg1) {
    carteras.validoModal(arg0, arg1);
    }

    @And("Valido los botones {string} Deshabilitado en la vitrina de Carteras")
    public void validoLosBotonesDeshabilitadoEnLaVitrinaDeCarteras(String arg0) {
    carteras.validoLosBotonesDeshabilitadoEnLaVitrinaDeCarteras(arg0);
    }

    @Then("Valido la siguiente alerta")
    public void validoLaSiguienteAlerta(String arg0) {
    carteras.validoLaSiguienteAlerta(arg0);
    }


    @Then("Visualizo el calculo realizado en {string}")
    public void visualizoElCalculoRealizadoEn(String arg0) {
        carteras.visualizoElCalculoRealizadoEn(arg0);
    }

    @And("Presiono check {string} de la cartera {string}")
    public void presionoCheckDeLaCartera(String arg0, String arg1) {
        carteras.presionoCheckDeLaCartera(arg0,arg1);
    }

    @And("Presiono boton de {string} en pantalla de comparacion en la cartera {string}")
    public void presionoBotonDeEnPantallaDeComparacionEnLaCartera(String arg0, String arg1) {
        carteras.presionoBotonDeEnPantallaDeComparacionEnLaCartera(arg0,arg1);
    }

    @And("Visualizo que el boton de invertir en la Cartera {string} se encuentre deshabilitado")
    public void visualizoQueElBotonDeInvertirEnLaCarteraSeEncuentreDeshabilitado(String arg0) {
        carteras.visualizoQueElBotonDeInvertirEnLaCarteraSeEncuentreDeshabilitado(arg0);

    }

    @Then("visualizo el mensaje de alerta correspondiente al cliente {string} sin cuenta usd")
    public void visualizoElMensajeDeAlertaCorrespondienteAlClienteSinCuentaUsd(String arg0) {
        carteras.validoLaSiguienteAlerta(arg0);
    }

    @And("Valido los campos que contegan data")
    public void validoLosCamposQueConteganData(DataTable campo) {
        validoCampos(campo);
    }
   
    protected void validoCampos(DataTable campo) {
        try {
            List<Map<String, String>> rows = campo.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("campo");
                validaElemento("(//p[contains (text(),'Cartera')])[1]", 4);
                PdfBciReports.addWebReportImage("Valido carteras", "Se valida el campo de cartera : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @And("Presiono el boton de {string} en vitrina {string}")
    public void presionoElBotonDeEnVitrina(String arg0, String arg1) {
        carteras.presionoElBotonDeEnVitrina(arg0,arg1);
    }

    @And("Valido los siguientes textos dentro de la vitrina")
    public void validoLosSiguientesTextosDentroDeLaVitrina(DataTable texto) {
        validoTextosVitrina(texto);
    }
    protected void validoTextosVitrina(DataTable texto){
        try {
            List<Map<String, String>> rows = texto.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("texto");
                validaElemento("(//*[contains(text(),'" + name + "')])[1]", 2);
                PdfBciReports.addReport("Valido texto vitrina", "Se valida el texto de la vitrina : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @And("Presiono el boton de {string} en la vitrina {string}")
    public void presionoElBotonDeEnLaVitrina(String arg0, String arg1) {
        carteras.presionoBotonDeEnLaVitrina(arg0,arg1);
    }

    @And("Valido los siguientes textos dentro de ver mas series")
    public void validoLosSiguientesTextosDentroDeVerMasSeries(DataTable texto) {
        validoTextosVerMas(texto);

    }
    protected void validoTextosVerMas(DataTable texto){
        try {
            List<Map<String, String>> rows = texto.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("texto");
                validaElemento("(//*[contains(text(),'" + name + "')])[1]", 3);
                PdfBciReports.addReport("Valido textos dentro del ver más series", "Se validan los textos dentro del ver más series : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @Then("Valido de forma correcta el modal de Inversion de carteras")
    public void validoDeFormaCorrectaElModalDeInversionDeCarteras(String arg0) {
        carteras.validoDeFormaCorrectaElModalDeInversionDeCarteras(arg0);
    }

    @And("Presiono la opcion de {string} en el menu")
    public void presionoLaOpcionDeEnElMenu(String arg0) {
        fondosMutuos.menu(arg0);
    }

    @And("Ingreso monto {string} en pantalla monto obtenido")
    public void ingresoMontoEnPantallaMontoObtenido(String arg0) {
        carteras.ingresoMontoEnPantallaMontoObtenido(arg0);
    }

    @And("Ingreso dias {string} en pantalla monto obtenido")
    public void ingresoDiasEnPantallaMontoObtenido(String arg0) {
        carteras.ingresoDiasEnPantallaMontoObtenido(arg0);
    }

    @Then("Valido de forma correcta el modal de Inversion {string}")
    public void validoDeFormaCorrectaElModalDeInversion(String arg0) {
        fondosMutuos.validoDeFormaCorrectaElModalDeInversion(arg0);
    }


}
