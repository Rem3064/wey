package step;


import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pages.fondosMutuos.FondosMutuos;
import pages.rescate.Rescate;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static constants.Constants.EXCEPCION;
import static reporter.EstadoPrueba.PASSED;
import static util.Acciones.reporteConYSinImagen;
import static util.Acciones.validaElemento;
import static utils.MetodosGenericos.esperar;

public class RescateStep {
    public static final Logger LOGGER = Logger.getLogger("RescateStep");
    FondosMutuos fondosMutuos = new FondosMutuos();
    Rescate rescate = new Rescate();

    @Then("visualizo que no existe ningun boton para rescatar Fondos Mutuos en USD")
    public void visualizoQueNoExisteNingunBotonParaRescatarFondosMutuosEnUSD() {
        rescate.visualizoQueNoExisteNingunBotonParaRescatarFondosMutuosEnUSD();
    }

    @And("Selecciono {string} en el {string}")
    public void seleccionoEnEl(String arg0, String arg1) {
        rescate.seleccionoEnEl(arg0, arg1);
    }

    @And("Selecciono el fondo {string}")
    public void seleccionoElFondo(String arg0) {
        rescate.seleccionoElFondo(arg0);
    }

    @And("Presiono rescatar {string} en el fondo {string}")
    public void presionoRescatarEnElFondo(String arg0, String arg1) {
        rescate.presionoRescatarEnElFondo(arg0, arg1);
    }

    @And("Respondo {string} la opcion {string}")
    public void respondoLaOpcion(String arg0, String arg1) {
        rescate.respondoLaOpcion(arg0, arg1);
    }

    @And("Ingreso monto a rescatar {string} and valido rescate {string}")
    public void ingresoMontoARescatarAndValidoRescate(String arg0, String arg1) {
        rescate.ingresoMontoARescatarAndValidoElRescate(arg0, arg1);
    }

    @And("Presiono checkbox de declarar haber leido y aceptado el reglamento")
    public void presionoCheckboxDeDeclararHaberLeidoYAceptadoElReglamento() {
        rescate.presionoCheckboxDeDeclararHaberLeidoYAceptadoElReglamento();
    }

    @And("Presiono boton {string} en pantalla de {string}")
    public void presionoBotonEnPantallaDe(String arg0, String arg1) {
        rescate.presionoBotonEnPantallaDe(arg0, arg1);
    }

    @Then("Visualizo el comprobante de rescate")
    public void visualizoElComprobanteDeRescate(String arg0) {
        rescate.visualizoElComprobanteDeRescate(arg0);
    }

    @And("Valido boton de {string} en el comprobante de rescate")
    public void validoBotonDeEnElComprobanteDeRescate(String arg0) {
        rescate.validoBotonDeEnElComprobanteDeRescate(arg0);
    }

    @And("Presiono {string} en modal Estas a un paso de solicitar un rescate de dinero")
    public void presionoEnModalEstasAUnPasoDeSolicitarUnRescateDeDinero(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("presiono el boton de {string} motivo de rescate")
    public void presionoElBotonDeMotivoDeRescate(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("Ingreso monto a rescatar {string} and valido el rescate {string}")
    public void ingresoMontoARescatarAndValidoElRescate(String arg0, String arg1) {
        rescate.ingresoMontoARescatarAndValidoElRescate(arg0, arg1);
    }

    @And("Presiono boton de {string} en el comprobante")
    public void presionoBotonDeEnElComprobante(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("valido pantalla principal de {string}")
    public void validoPantallaPrincipalDe(String arg0) {
        rescate.validoPantallaPrincipalDe(arg0);
    }

    @And("Valido que el textbox se encuentre deshabilitado y que el monto sea igual al monto total disponible de rescate")
    public void validoQueElTextboxSeEncuentreDeshabilitadoYQueElMontoSeaIgualAlMontoTotalDisponibleDeRescate() {
        rescate.validoQueElTextboxSeEncuentreDeshabilitadoYQueElMontoSeaIgualAlMontoTotalDisponibleDeRescate();
    }

    @And("Presiono {string}.")
    public void presiono(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("valido que el campo {string} indique el valor de {string} en pantalla de confirmacion")
    public void validoQueElCampoIndiqueElValorDeEnPantallaDeConfirmacion(String arg0, String arg1) {
        rescate.validoQueElCampoIndiqueElValorDeEnPantallaDeConfirmacion(arg0, arg1);
    }

    @And("Valido que el campo {string} indique {string}")
    public void validoQueElCampoIndique(String arg0, String arg1) {
        rescate.validoQueElCampoIndique(arg0, arg1);
    }

    @And("Presiono el label del rescate {string} en la pantalla")
    public void presionoElLabelDelRescateEnLaPantalla(String arg0) {
        rescate.presionoEllabelDelRescateEnLaPantalla(arg0);
    }

    @And("Valido modal fuera de horario {string}")
    public void validoModalFueraDeHorario(String arg0) {
        rescate.validoModalFueraDeHorario(arg0);
    }

    @And("Presiono {string} en modal fuera de horario rescate")
    public void presionoEnModalFueraDeHorarioRescate(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("Visualizo boton {string} dentro del modal de cliente sin cuenta para rescatar")
    public void visualizoBotonDentroDelModalDeClienteSinCuentaParaRescatar(String arg0) {
        rescate.visualizoBotonDentroDelModalDeClienteSinCuentaParaRescatar(arg0);
    }

    @Then("Visualizo modal cliente sin cuenta pero con inversiones FFMM realizada en USD")
    public void visualizoModalClienteSinCuentaPeroConInversionesFFMMRealizadaEnUSD(String arg0) {
        rescate.visualizoModalClienteSinCuentaPeroConInversionesFFMMRealizadaEnUSD(arg0);
    }

    @And("Presiono boton {string} de modal cliente sin cuenta")
    public void presionoBotonDeModalClienteSinCuenta(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("valido que el campo {string} indique el valor de {string} en patanlla de confirmacion")
    public void validoQueElCampoIndiqueElValorDeEnPatanllaDeConfirmacion(String arg0, String arg1) {
        rescate.validoQueElCampoIndiqueElValorDeEnPantallaDeConfirmacion(arg0, arg1);
    }

    @Then("Visualizo que no exista el boton de {string}")
    public void visualizoQueNoExistaElBotonDe(String arg0) {
        rescate.visualizoQueNoExistaElBotonDe(arg0);
    }

    @And("Valido {string} adjunto en la pantalla de confirmacion")
    public void validoAdjuntoEnLaPantallaDeConfirmacion(String arg0) {
        rescate.validoAdjuntoEnLaPantallaDeConfirmacion(arg0);
    }

    @And("Selecciono la cartera {string}")
    public void seleccionoLaCartera(String arg0) {
        rescate.seleccionoLaCartera(arg0);
    }

    @Then("Visualizo que exista el boton de {string}")
    public void visualizoQueExistaElBotonDe(String arg0) {
        rescate.visualizoQueExistaElBotonDe(arg0);
    }

    @Then("Valido que el boton {string} en pantalla de {string} se encuentre deshabilitado")
    public void validoQueElBotonEnPantallaDeSeEncuentreDeshabilitado(String arg0, String arg1) {
        rescate.validoQueElBotonEnPantallaDeSeEncuentreDeshabilitado(arg0,arg1);

    }

    @And("Valido los siguientes datos en pantalla solicitud de rescate en dólares")
    public void validoLosSiguientesDatosEnPantallaSolicitudDeRescateEnDolares(DataTable textos) {
        validoTextosRescate(textos);
    }

    protected void validoTextosRescate(DataTable textos) {
        esperar(12);
        try {
            List<Map<String, String>> rows = textos.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("textos");
                validaElemento("(//*[contains(text(),'" + name + "')])[1]", 2);
                PdfBciReports.addReport("Valido texto rescate", "Se valida el texto de rescate : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @And("valido los textos de confirmacion")
    public void validoLosTextosDeConfirmacion(DataTable textosConfirmacion) {
        validoTextosConfirmacion(textosConfirmacion);
    }

    protected void validoTextosConfirmacion(DataTable textosConfirmacion) {
        esperar(8);
        try {
            List<Map<String, String>> rows = textosConfirmacion.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("textosConfirmacion");
                validaElemento("(//*[contains(text(),'" + name + "')])[1]", 2);
                PdfBciReports.addReport("Valido texto confirmacion", "Se valida el texto de confirmacion : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @And("Valido los campos del comprobante de rescate")
    public void validoLosCamposDelComprobanteDeRescate(DataTable textoComprobante) {
        validoTextosComprobanteRescate(textoComprobante);
    }

    protected void validoTextosComprobanteRescate(DataTable textoComprobante) {
        esperar(10);
        try {
            List<Map<String, String>> rows = textoComprobante.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("textoComprobante");
                validaElemento("(//*[contains(text(),'" + name + "')])[1]", 2);
                PdfBciReports.addReport("Valido texto comprobante rescate", "Se valida el texto de comprobante  rescate : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @And("Valido el boton de {string}")
    public void validoElBotonDe(String arg0) {
        rescate.validoElBotonDe(arg0);
    }

    @And("Visualizo boton {string} deshabilitado en pantalla de motivo")
    public void visualizoBotonDeshabilitadoEnPantallaDeMotivo(String arg0) {
        rescate.visualizoBotonDeshabilitadoEnPantalla(arg0);
    }

    @And("Visualizo boton {string} deshabilitado en pantalla de ingresa los datos del rescate")
    public void visualizoBotonDeshabilitadoEnPantallaDeIngresaLosDatosDelRescate(String arg0) {
        rescate.visualizoBotonDeshabilitadoEnPantalla(arg0);
    }

    @And("Ingreso monto a rescatar {string}en pantalla de ingresa los datos del rescate")
    public void ingresoMontoARescatarEnPantallaDeIngresaLosDatosDelRescate(String arg0) {
        rescate.ingresoMontoARescatarEnPantallaDeIngresaLosDatosDelRescate(arg0);
    }

    @And("Vacio el campo del monto sin ingresar ningun monto en la pantalla de datos")
    public void vacioElCampoDelMontoSinIngresarNingunMontoEnLaPantallaDeDatos() {
        rescate.vacioCampo();
    }

    @And("Visualizo boton {string} deshabilitado en pantalla de confirmacion")
    public void visualizoBotonDeshabilitadoEnPantallaDeConfirmacion(String arg0) {
        rescate.visualizoBotonDeshabilitadoEnPantalla(arg0);
    }

    @And("Ingreso nuevamente el {string} en la pantalla de confirmacion")
    public void ingresoNuevamenteElEnLaPantallaDeConfirmacion(String arg0) {
        rescate.ingresoNuevamenteElEnLaPantallaDeConfirmacion(arg0);
    }

    @And("Suprimo el texto ingresado en el campo {string}")
    public void suprimoElTextoIngresadoEnElCampo(String arg0) {
        rescate.suprimoElTextoIngresadoEnElCampo(arg0);
    }
}