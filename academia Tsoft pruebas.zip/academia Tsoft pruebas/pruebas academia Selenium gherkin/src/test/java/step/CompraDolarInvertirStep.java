package step;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pages.compraDolarInvertir.CompraDolarInvertir;
import pages.fondosMutuos.FondosMutuos;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static constants.Constants.EXCEPCION;
import static reporter.EstadoPrueba.PASSED;
import static util.Acciones.*;


public class CompraDolarInvertirStep {
    public static final Logger LOGGER = Logger.getLogger("CompraDolarInvertirStep");
    CompraDolarInvertir compraDolarInvertir = new CompraDolarInvertir();
    FondosMutuos fondosMutuos = new FondosMutuos();

    @Then("visualizo mensaje de alerta amarillo {string}")
    public void visualizoMensajeDeAlertaAmarillo(String arg0) {
        compraDolarInvertir.visualizoMensajeDeAlertaAmarillo(arg0);
    }


    @And("Visualizo modal fuera de horario en el flujo")
    public void visualizoModalFueraDeHorarioEnElFlujo(String arg0) {
        compraDolarInvertir.visualizoModalFueraDeHorarioEnElFlujo(arg0);
    }


    @Then("visualizo de forma correcta el {string}")
    public void visualizoDeFormaCorrectaEl(String arg0, String arg1) {
        compraDolarInvertir.visualizoDeFormaCorrectaEl(arg0, arg1);
    }

    @And("Visualizo modal Bci Corredora de Bolsa")
    public void visualizoModalBciCorredoraDeBolsa() {
        compraDolarInvertir.visualizoModalBciCorredoraDeBolsa();
    }

    @And("Presiono boton {string} en el modal de Bci Corredora de Bolsa")
    public void presionoBotonEnElModalDeBciCorredoraDeBolsa(String arg0) {
        compraDolarInvertir.presionoBotonEnElModalDeBciCorredoraDeBolsa(arg0);
    }

    @And("Visualizo modal {string}")
    public void visualizoModal(String arg0) {
        compraDolarInvertir.visualizoModal(arg0);
    }

    @And("Selecciono el combobox de como deseo invertir {string}")
    public void seleccionoElComboboxDeComoDeseoInvertir(String arg0) {
        compraDolarInvertir.seleccionoElComboboxDeComoDeseoInvertir(arg0);
    }

    @And("Valido campo {string} en pantalla Datos de tu inversion")
    public void validoCampoEnPantallaDatosDeTuInversion(String arg0) {
        compraDolarInvertir.validoCampoEnPantallaDatosDeTuInversion(arg0);
    }

    @And("Valido el campo {string}")
    public void validoElCampo(String arg0) {
        compraDolarInvertir.validoElCampo(arg0);
    }

    @And("Valido los siguientes campos modal en la compra de dolares")
    public void validoLosSiguientesCamposModalEnLaCompraDeDolares(DataTable campo) {
      validoCamposConfirmar(campo);
    }

    @And("Valido textos en la compra en el confirmar")
    public void validoTextosEnLaCompraEnElConfirmar(DataTable texto) {
        validoTextosConfirmar(texto);
    }

    @And("Valido los siguientes campos modal FFMM")
    public void validoLosSiguientesCamposModalFFMM(DataTable campo) {
        validoCamposConfirmar(campo);
    }

    protected void validoCamposConfirmar(DataTable campo){
        try {
            List<Map<String, String>> rows = campo.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("campo");
                existeElemento("(//*[contains(text(),'" + name + "')])[1]",5);
                PdfBciReports.addReport("Valido campos dentro de la confirmación", "Se validan los campos dentro de la confirmación : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    protected void validoTextosConfirmar(DataTable texto){
        try {
            List<Map<String, String>> rows = texto.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("texto");
                validaElemento("(//*[contains(text(),'" + name + "')])[1]", 3);
                PdfBciReports.addReport("Valido campos dentro de la confirmación", "Se validan los campos dentro de la confirmación : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @And("valido el campo de {string}")
    public void validoElCampoDe(String arg0) {
        compraDolarInvertir.validoElCampoDe(arg0);
    }

    @And("Visualizo modal {string} en la vitrina")
    public void visualizoModalEnLaVitrina(String arg0) {
        compraDolarInvertir.visualizoModalEnLaVitrina(arg0);
    }

    @And("visualizo el modal de fuera de horario")
    public void visualizoElModalDeFueraDeHorario(String arg0) {
        compraDolarInvertir.visualizoElModalDeFueraDeHorario(arg0);
    }

    @And("Valido que el combobox de invertir cuenta corriente en pesos esté deshabilitado")
    public void validoQueElComboboxDeInvertirCuentaCorrienteEnPesosEsteDeshabilitado() {
        compraDolarInvertir.validoQueElComboboxDeInvertirCuentaCorrienteEnPesosEsteDeshabilitado();
    }
}
