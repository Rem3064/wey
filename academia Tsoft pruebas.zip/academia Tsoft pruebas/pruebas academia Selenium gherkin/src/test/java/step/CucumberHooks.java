package step;

import constants.Navegador;
import driverWeb.DriverContextWeb;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import reporter.PdfBciReports;

import java.io.IOException;
import java.util.logging.Logger;

import static constants.Constants.*;
import static featureControlled.CucumberExecution.configExecution;
import static featureControlled.CucumberExecution.finishExecution;
import static utils.UtilsPDF.setTypeExecution;

public  class CucumberHooks {
    public static final Logger LOGGER = Logger.getLogger("CucumberHooks");
    @Before
    public void beforeScenario(Scenario scenario) throws InterruptedException, IOException {
        setTypeExecution(TIPO_SUITE,CELULA, false, false);
        configExecution(scenario, "Prueba automatizada Frontend Web");
        //DriverContextWeb.setUpWeb(BROWSER, AMBIENTE_URL_INVERSIONES);
        DriverContextWeb.setUpWeb(Navegador.Chrome, AMBIENTE_URL_INVERSIONES);
        //DriverContextWeb.setUpWeb(ConexionRemota,BROWSER, AMBIENTE_URL_INVERSIONES);
        //DriverContextWeb.setUpWeb("116C", Navegador.ChromeRemote,AMBIENTE_URL_INVERSIONES);
        //DriverContextWeb.setUpWeb("116:5555", Navegador.ChromeRemote, AMBIENTE_URL_INVERSIONES);
        PdfBciReports.createPDF();
    }

    @After
    public void afterScenario(Scenario s) throws IOException {
        finishExecution(s);
        DriverContextWeb.quitDriverWeb();
        PdfBciReports.finishPDF();
    }
    /*public void afterScenario(Scenario scenario) {
        finishExecution(scenario);

        if (System.getProperty("NAVEGADOR") != null && System.getProperty("NAVEGADOR").toLowerCase().contains("remote") ) {
            LOGGER.info("[quitDriverWeb] [OK]");
            DriverContextWeb.quitDriverWeb();
        }else {
            LOGGER.info("[quitDriverWeb] [NOK]");
        }
        PdfBciReports.finishPDF();
        //UploadReportScenario(scenario,"almOctane.properties");
    }*/
}