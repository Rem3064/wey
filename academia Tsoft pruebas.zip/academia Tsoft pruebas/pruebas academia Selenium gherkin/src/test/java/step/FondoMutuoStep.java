package step;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebElement;
import pages.carteras.Carteras;
import pages.fondosMutuos.FondosMutuos;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static constants.Constants.EXCEPCION;
import static reporter.EstadoPrueba.PASSED;
import static util.Acciones.*;
import static utils.MetodosGenericos.esperar;
import static utils.web.ControlledActionsWeb.visualizarObjetoScroll;

public class FondoMutuoStep {
    public static final Logger LOGGER = Logger.getLogger("FondosMutuostep");
    FondosMutuos fondosMutuos = new FondosMutuos();
    Carteras carteras = new Carteras();
    @Given("ingreso a BCI Personas")
    public void ingresoABCIPersonas() {
        LOGGER.info("se ingresa a la url de Bci Personas");
        PdfBciReports.addWebReportImage("Ingreso a BCI Personas", "Se ingresa a la página de BCI Personas", EstadoPrueba.PASSED, false);
    }

    @Given("Ingreso a BCI Personas")
    public void IngresoABCIPersonas() {
        LOGGER.info("se ingresa a la url de Bci Personas");
        PdfBciReports.addReport("Ingreso a BCI Personas", "Se ingresa a la página de BCI Personas", EstadoPrueba.PASSED, false);
    }

    @And("ingreso con el rut cliente {string} y la clave {string}")
    public void ingresoConElRutClienteYLaClave(String rutCliente, String clave) {
        fondosMutuos.login(rutCliente, clave);
        LOGGER.info("ingreso a bci personas con el rut " + rutCliente + " y la clave " + clave);
    }

    @And("Ingreso con el rut cliente {string} y la clave {string}")
    public void IngresoConElRutClienteYLaClave(String rutCliente, String clave) {
        fondosMutuos.login(rutCliente, clave);
        LOGGER.info("ingreso a bci personas con el rut " + rutCliente + " y la clave " + clave);
    }

    @When("presiono el boton de {string}")
    public void presionoElBotonDe(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
        LOGGER.info("hago click en el botón Banco en línea");
    }

    @When("Presiono el boton de {string}")
    public void PresionoElBotonDe(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("presiono opcion de menu {string}")
    public void presionoOpcionDeMenu(String arg0) {
        fondosMutuos.menu(arg0);
    }

    @And("Presiono opcion de menu {string}")
    public void PresionoOpcionDeMenu(String arg0) {
        fondosMutuos.menu(arg0);
    }

    @And("presiono desde la lista desplegable {string} y luego {string}")
    public void presionoDesdeLaListaDesplegableYLuego(String arg0, String arg1) {
        fondosMutuos.listaDesplegable(arg0, arg1);
    }

    @And("Presiono desde la lista desplegable {string} y luego {string}")
    public void PresionoDesdeLaListaDesplegableYLuego(String arg0, String arg1) {
        fondosMutuos.listaDesplegable(arg0, arg1);
    }

    @And("presiono la opcion de {string}")
    public void presionoLaOpcionDe(String arg0) {
        fondosMutuos.menu(arg0);
    }

    @And("Presiono la opcion de {string}")
    public void PresionoLaOpcionDe(String arg0) {
        fondosMutuos.menu(arg0);
    }

    @And("presiono boton invertir en fondo mutuo perfil conservador {string}")
    public void presionoBotonInvertirEnFondoMutuoPerfilConservador(String arg0) {
        fondosMutuos.presionoBotonInvertirEnFondoMutuoPerfilConservador(arg0);
    }


    @Then("visualizo el modal correspondiente")
    public void visualizoElModalCorrespondiente(String arg0) {
        fondosMutuos.visualizoModal(arg0);
    }

    @And("ingreso clave multipass {string}")
    public void ingresoClaveMultipass(String multipass) {
        fondosMutuos.multipass(multipass);
    }

    @And("Ingreso clave multipass {string}")
    public void IngresoClaveMultipass(String multipass) {
        fondosMutuos.multipass(multipass);
    }

    @And("presiono boton {string}")
    public void presionoBoton(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("Presiono boton {string}")
    public void PresionoBoton(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("presiono boton invertir en fondo mutuo perfil muy agresivo {string}")
    public void presionoBotonInvertirEnFondoMutuoPerfilMuyAgresivo(String arg0) {
        fondosMutuos.presionoBotonInvertirEnFondoMutuoPerfilMuyAgresivo(arg0);
    }


    @And("presiono el boton INVERTIR en el Fondo mutuo de {string}")
    public void presionoElBotonINVERTIREnElFondoMutuoDe(String arg0) {
        fondosMutuos.presionoInvertirEnFondoMutuo(arg0);
    }

    @And("presiono el boton checkbox de Declaro aceptar y manifiesto mi conformidad de invertir en un perfil de riesgo superior")
    public void presionoElBotonCheckboxDeDeclaroAceptarYManifiestoMiConformidadDeInvertirEnUnPerfilDeRiesgoSuperior() {
        fondosMutuos.presionoCheck();
    }


    @And("presiono el boton {string}")
    public void presionoElBoton(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("ingreso los datos en la primera pantalla {string}")
    public void ingresoLosDatosEnLaPrimeraPantalla(String arg0) {
        fondosMutuos.ingresadatosinvFFMMCLPvitrina(arg0);
    }

    @And("ingreso correo valido en {string}")
    public void ingresoCorreoValidoEn(String arg0) {
        fondosMutuos.ingresoCorreo(arg0);
    }

    @And("presiono el boton checkbox de declaro")
    public void presionoElBotonCheckboxDeDeclaro() {
        fondosMutuos.presionoElBotonCheckboxDeDeclaro();
    }

    @Then("visualizo pantalla de solicitud inversion realizada")
    public void visualizoPantallaDeSolicitudInversionRealizada(String arg0) {
        fondosMutuos.visualizoInvRealizada(arg0);
    }


    @And("presiono el boton {string} en la pantalla datos de tu inversion")
    public void presionoElBotonEnLaPantallaDatosDeTuInversion(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }


    @And("presiono el boton {string} en la pantalla datos de tu inversion fuera de horario")
    public void presionoElBotonEnLaPantallaDatosDeTuInversionFueraDeHorario(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);

    }

    @Then("visualizo la advertencia fuera de horario")
    public void visualizoLaAdvertenciaFueraDeHorario() {
        fondosMutuos.visualizoLaAdvertenciaFueraDeHorario();
    }

    @And("presiono los dos checkbox de los dos primeros Fondos Mutuos")
    public void presionoLosDosCheckboxDeLosDosPrimerosFondosMutuos() {
        fondosMutuos.presionoDosCheck();
    }

    @Then("visualizo el grafico de Comparador de Fondos Mutuos de forma correcta")
    public void visualizoElGraficoDeComparadorDeFondosMutuosDeFormaCorrecta(String arg0) {
        fondosMutuos.graficocomparaFFMM(arg0);
    }

    @And("presiono el checkbox de declaro")
    public void presionoElCheckboxDeDeclaro() {
        fondosMutuos.presionoCheck();
    }

    @And("presiono el boton de {string} dentro del modal")
    public void presionoElBotonDeDentroDelModal(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }


    @And("presiono el boton {string} en la pantalla {string}")
    public void presionoElBotonEnLaPantalla(String arg0, String arg1) {
        fondosMutuos.presionoElBotonEnLaPantalla(arg0, arg1);
    }

    @And("presiono ver mas series en fondo mutuo de {string}")
    public void presionoVerMasSeriesEnFondoMutuoDe(String arg0) {
        fondosMutuos.verseriesFFMM(arg0);
    }

    @And("presiono {string} de Serie Bprivada")
    public void presionoDeSerieBprivada(String arg0) {
        fondosMutuos.presionoDeSerieBprivada(arg0);
    }

    @And("presiono el check de Declaro aceptar y manifiesto mi conformidad")
    public void presionoElCheckDeDeclaroAceptarYManifiestoMiConformidad() {
        fondosMutuos.presionoCheck();
    }

    @And("presiono la opcion de {string} en el fondo mutuo de Global Titan")
    public void presionoLaOpcionDeEnElFondoMutuoDeGlobalTitan(String arg0) {
        fondosMutuos.presionoLaOpcionDeEnElFondoMutuoDeGlobalTitan(arg0);
    }

    @Then("visualizo el detalle del Fondo Mutuo Seleccionado")
    public void visualizoElDetalleDelFondoMutuoSeleccionado(String arg0) {
        fondosMutuos.visualizoElDetalleDelFondoMutuoSeleccionado(arg0);
    }
    @Then("visualizo lo que lo que hoy tendria si hubiese invertido hace meses o dias")
    public void visualizoLoQueLoQueHoyTendriaSiHubieseInvertidoHaceMesesODias() {
        fondosMutuos.visualizoLoQueLoQueHoyTendriaSiHubieseInvertidoHaceMesesODias();
    }

    @And("presiono el boton SABER MAS en el Fondo mutuo de Asia")
    public void presionoElBotonSABERMASEnElFondoMutuoDeAsia() {
        fondosMutuos.presionoElBotonSABERMASEnElFondoMutuoDeAsia();
    }

    @And("ingreso los datos en el Calcula la rentabilidad historica del Fondo Mutuo")
    public void ingresoLosDatosEnElCalculaLaRentabilidadHistoricaDelFondoMutuo() {
        fondosMutuos.ingresoLosDatosEnElCalculaLaRentabilidadHistoricaDelFondoMutuo();
    }

    @Then("visualizo pantalla de encuesta")
    public void visualizoPantallaDeEncuesta(String arg0) {
        fondosMutuos.visualizoPantallaDeEncuesta(arg0);
    }

    @And("presiono {string}")
    public void presiono(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("selecciono la opcion {string}")
    public void seleccionoLaOpcion(String arg0) {
        fondosMutuos.seleccionoLaOpcion(arg0);
    }

    @Then("visualizo que se haya ordenado de forma correcta por Horizonte de inversion sugerido")
    public void visualizoQueSeHayaOrdenadoDeFormaCorrectaPorHorizonteDeInversionSugerido(String arg0) {
        fondosMutuos.visualizoQueSeHayaOrdenadoDeFormaCorrectaPorHorizonteDeInversionSugerido(arg0);
    }

    @Then("visualizo que se haya ordenado por rentabilidad anual pasada")
    public void visualizoQueSeHayaOrdenadoPorRentabilidadAnualPasada(String arg0) {
        fondosMutuos.visualizoQueSeHayaOrdenadoPorRentabilidadAnualPasada(arg0);
    }

    @Then("visualizo pantalla de Fondos Mutuos")
    public void visualizoPantallaDeFondosMutuos(String arg0) {
        fondosMutuos.visualizoPantallaDeFondosMutuos(arg0);
    }

    @And("ingreso los datos correspondiente a la pantalla de Tus datos de cliente")
    public void ingresoLosDatosCorrespondienteALaPantallaDeTusDatosDeCliente() {
        fondosMutuos.ingresoLosDatosCorrespondienteALaPantallaDeTusDatosDeCliente();
    }

    @And("ingreso telefono en el campo {string}")
    public void ingresoTelefonoEnElCampo(String arg0) {
        fondosMutuos.ingresoTelefonoEnElCampo(arg0);
    }

    @And("ingreso {string} en {string}")
    public void ingresoEn(String arg0, String arg1) {
        fondosMutuos.ingresoEn(arg0, arg1);

    }

    @And("ingreso los campos que se despliegan")
    public void ingresoLosCamposQueSeDespliegan() {
        fondosMutuos.ingresoLosCamposQueSeDespliegan();
    }

    @And("selecciono el checkbox del recuadro de declaro que solo debo pagar impuestos en chile")
    public void seleccionoElCheckboxDelRecuadroDeDeclaroQueSoloDeboPagarImpuestosEnChile() {
        fondosMutuos.seleccionoElCheckboxDelRecuadroDeDeclaroQueSoloDeboPagarImpuestosEnChile();
    }

    @And("selecciono la opcion para Los Fondos a invertir fueron provistos por US Person entidades o personas")
    public void seleccionoLaOpcionParaLosFondosAInvertirFueronProvistosPorUSPersonEntidadesOPersonas() {
        fondosMutuos.seleccionoLaOpcionParaLosFondosAInvertirFueronProvistosPorUSPersonEntidadesOPersonas();
    }

    @And("selecciono {string} en la opcion De donde provienen los fondos")
    public void seleccionoEnLaOpcionDeDondeProvienenLosFondos(String arg0) {
        fondosMutuos.seleccionoEnLaOpcionDeDondeProvienenLosFondos(arg0);
    }

    @And("selecciono el checkbox de Autorizo a Bci Asset Management")
    public void seleccionoElCheckboxDeAutorizoABciAssetManagement() {
        fondosMutuos.seleccionoElCheckboxDeAutorizoABciAssetManagement();
    }

    @Then("visualizo Cliente US Person")
    public void visualizoClienteUSPerson(String arg0) {
        fondosMutuos.visualizoClienteUSPerson(arg0);
    }

    @And("selecciono la opcion para Eres nacido ciudadano o residente de Estados Unidos de America")
    public void seleccionoLaOpcionParaEresNacidoCiudadanoOResidenteDeEstadosUnidosDeAmerica() {
        fondosMutuos.seleccionoLaOpcionParaEresNacidoCiudadanoOResidenteDeEstadosUnidosDeAmerica();
    }

    @And("ingreso los campos que se despliegan {string} y {string}")
    public void ingresoLosCamposQueSeDesplieganY(String arg0, String arg1) {
        fondosMutuos.ingresoLosCamposQueSeDesplieganY(arg0, arg1);
    }

    @And("selecciono la opcion para Eres o tienes vinculos con personas en cargos publicos PEP")
    public void seleccionoLaOpcionParaEresOTienesVinculosConPersonasEnCargosPublicosPEP() {
        fondosMutuos.seleccionoLaOpcionParaEresOTienesVinculosConPersonasEnCargosPublicosPEP();

    }

    @Then("visualizo el siguiente mensaje")
    public void visualizoElSiguienteMensaje(String arg0) {
        fondosMutuos.visualizoElSiguienteMensaje(arg0);
    }

    @And("visualizo la informacion de los indicadores {string}")
    public void visualizoLaInformacionDeLosIndicadores(String arg0) {
        fondosMutuos.visualizoLaInformacionDeLosIndicadores(arg0);
    }

    @Then("visualizo la pagina de indicadores economicos")
    public void visualizoLaPaginaDeIndicadoresEconomicos(String arg0) {
        fondosMutuos.visualizoLaPaginaDeIndicadoresEconomicos(arg0);
    }

    @And("se muestra pantalla de Habilitarse para invertir en Fondos Mutuos")
    public void seMuestraPantallaDeHabilitarseParaInvertirEnFondosMutuos() {
        fondosMutuos.seMuestraPantallaDeHabilitarseParaInvertirEnFondosMutuos();
    }

    @And("se muestra la lista de contratos")
    public void seMuestraLaListaDeContratos() {
        fondosMutuos.seMuestraLaListaDeContratos();
    }

    @And("presiono el link DESCARGAR TODOS")
    public void presionoElLinkDESCARGARTODOS() {
        fondosMutuos.presionoElLinkDESCARGARTODOS();
    }

    @And("selecciono el check de declaracion de lectura de documentos")
    public void seleccionoElCheckDeDeclaracionDeLecturaDeDocumentos() {
        fondosMutuos.seleccionoElCheckDeDeclaracionDeLecturaDeDocumentos();
    }

    @And("ingreso clave multipass valida")
    public void ingresoClaveMultipassValida() {
        fondosMutuos.ingresoClaveMultipassValida();
    }

    @Then("se muestra pantalla de Felicidades Ya estas listo para invertir en Fondos Mutuos")
    public void seMuestraPantallaDeFelicidadesYaEstasListoParaInvertirEnFondosMutuos() {
        fondosMutuos.seMuestraPantallaDeFelicidadesYaEstasListoParaInvertirEnFondosMutuos();
    }

    @And("visualizo el titulo de la vitrina {string}")
    public void visualizoElTituloDeLaVitrina(String arg0) {
        fondosMutuos.visualizoElTituloDeLaVitrina(arg0);
    }

    @And("presiono la opcion de Ver mas series de alguna cartera")
    public void presionoLaOpcionDeVerMasSeriesDeAlgunaCartera() {
        fondosMutuos.presionoLaOpcionDeVerMasSeriesDeAlgunaCartera();
    }

    @And("visualizo que se muestra la informacion de serie, monto minimo de inversion costo de rescate y rentabilidad de cada serie")
    public void visualizoQueSeMuestraLaInformacionDeSerieMontoMinimoDeInversionCostoDeRescateYRentabilidadDeCadaSerie() {
        fondosMutuos.visualizoQueSeMuestraLaInformacionDeSerieMontoMinimoDeInversionCostoDeRescateYRentabilidadDeCadaSerie();
    }

    @And("visualizo que existe un boton SABER MAS para cada serie")
    public void visualizoQueExisteUnBotonSABERMASParaCadaSerie() {
        fondosMutuos.visualizoQueExisteUnBotonSABERMASParaCadaSerie();
    }

    @And("presiono el boton SABER MAS de una cartera")
    public void presionoElBotonSABERMASDeUnaCartera() {
        fondosMutuos.presionoElBotonSABERMASDeUnaCartera();
    }

    @Then("visualizo el detalle de la cartera")
    public void visualizoElDetalleDeLaCartera() {
        fondosMutuos.visualizoElDetalleDeLaCartera();
    }

    @And("ingreso con el rut cliente consumible {string} y la clave {string}")
    public void ingresoConElRutClienteConsumibleYLaClave(String rutCliente, String clave) {
        fondosMutuos.ingresoConElRutClienteConsumibleYLaClave(rutCliente, clave);
    }

    @And("valido que se visualice la cartera de {string}")
    public void validoQueSeVisualiceLaCarteraDe(String arg0) {
        fondosMutuos.validoQueSeVisualiceLaCarteraDe(arg0);
    }

    @And("selecciono en el menu lateral la opcion {string}")
    public void seleccionoEnElMenuLateralLaOpcion(String arg0) {
        fondosMutuos.menu(arg0);
    }

    @And("despliego los fondos mutuos")
    public void despliegoLosFondosMutuos() {
        fondosMutuos.despliegoLosFondosMutuos();
    }

    @And("presiono sobre el fondo mutuo que deseo traspasar")
    public void presionoSobreElFondoMutuoQueDeseoTraspasar() {
        fondosMutuos.presionoSobreElFondoMutuoQueDeseoTraspasar();
    }

    @And("presiono el boton Traspasar")
    public void presionoElBotonTraspasar() {
        fondosMutuos.presionoElBotonTraspasar();
    }

    @And("selecciono el boton de carteras dinamicas")
    public void seleccionoElBotonDeCarterasDinamicas() {
        fondosMutuos.seleccionoElBotonDeCarterasDinamicas();
    }

    @And("selecciono una cartera para realizar el traspaso")
    public void seleccionoUnaCarteraParaRealizarElTraspaso() {
        fondosMutuos.seleccionoUnaCarteraParaRealizarElTraspaso();
    }

    @And("acepto el modal de perfil mayor")
    public void aceptoElModalDePerfilMayor() {
        fondosMutuos.aceptoElModalDePerfilMayor();
    }

    @And("selecciono el tipo de traspaso Parcial")
    public void seleccionoElTipoDeTraspasoParcial() {
        fondosMutuos.seleccionoElTipoDeTraspasoParcial();
    }

    @And("ingreso el monto a traspasar")
    public void ingresoElMontoATraspasar() {
        fondosMutuos.ingresoElMontoATraspasar();
    }

    @And("selecciono el check de declaracion")
    public void seleccionoElCheckDeDeclaracion() {
        fondosMutuos.seleccionoElCheckDeDeclaracion();
    }

    @And("presiono el boton Confirmar Traspaso")
    public void presionoElBotonConfirmarTraspaso() {
        fondosMutuos.presionoElBotonConfirmarTraspaso();
    }

    @And("visualizo que se muestre el comprobante del traspaso")
    public void visualizoQueSeMuestreElComprobanteDelTraspaso() {
        fondosMutuos.visualizoQueSeMuestreElComprobanteDelTraspaso();
    }

    @Then("descargo el PDF del comprobante")
    public void descargoElPDFDelComprobante() {
        fondosMutuos.descargoElPDFDelComprobante();
    }

    @And("selecciono el boton de fondos mutuos")
    public void seleccionoElBotonDeFondosMutuos() {
        fondosMutuos.seleccionoElBotonDeFondosMutuos();
    }

    @And("selecciono un fondo para realizar el traspaso")
    public void seleccionoUnFondoParaRealizarElTraspaso() {
        fondosMutuos.seleccionoUnFondoParaRealizarElTraspaso();
    }

    @And("selecciono no acceder al beneficio tributario MLT")
    public void seleccionoNoAccederAlBeneficioTributarioMLT() {
        fondosMutuos.seleccionoNoAccederAlBeneficioTributarioMLT();
    }

    @And("selecciono segundo check de declaracion")
    public void seleccionoSegundoCheckDeDeclaracion() {
        fondosMutuos.seleccionoSegundoCheckDeDeclaracion();
    }

    @And("presiono sobre fondo mutuo que deseo traspasar")
    public void presionoSobreFondoMutuoQueDeseoTraspasar() {
        fondosMutuos.presionoSobreFondoMutuoQueDeseoTraspasar();

    }

    @And("visualizo el siguiente mensaje de fuera de horario")
    public void visualizoElSiguienteMensajeDeFueraDeHorario(String arg0) {
        fondosMutuos.visualizoElSiguienteMensajeDeFueraDeHorario(arg0);
    }

    @And("selecciono el tipo de traspaso Total")
    public void seleccionoElTipoDeTraspasoTotal() {
        fondosMutuos.seleccionoElTipoDeTraspasoTotal();
    }

    @And("presiono el check comparar de dos carteras")
    public void presionoElCheckCompararDeDosCarteras() {
        fondosMutuos.presionoDosCheck();
    }

    @And("visualizo la ventana flotante con las carteras a comparar")
    public void visualizoLaVentanaFlotanteConLasCarterasAComparar() {
        fondosMutuos.visualizoLaVentanaFlotanteConLasCarterasAComparar();
    }

    @And("visualizo el Comparador de Carteras")
    public void visualizoElComparadorDeCarteras() {
        fondosMutuos.visualizoElComparadorDeCarteras();
    }

    @And("ingreso el monto a invertir")
    public void ingresoElMontoAInvertir() {
        fondosMutuos.ingresoElMontoAInvertir();
    }

    @And("selecciono una cuenta de cargo")
    public void seleccionoUnaCuentaDeCargo() {
        fondosMutuos.seleccionoUnaCuentaDeCargo();
    }

    @And("visualizo la encuesta de satisfaccion y la cierro")
    public void visualizoLaEncuestaDeSatisfaccionYLaCierro() {
        fondosMutuos.visualizoLaEncuestaDeSatisfaccionYLaCierro();
    }

    @And("visualizo el comprobante de la inversion")
    public void visualizoElComprobanteDeLaInversion() {
        fondosMutuos.visualizoElComprobanteDeLaInversion();
    }

    @Then("descargo el PDF del comprobante inversion")
    public void descargoElPDFDelComprobanteInversion() {
        fondosMutuos.descargoElPDFDelComprobanteInversion();
    }

    @And("visualizo el siguiente mensaje fuera de horario en el comprobante")
    public void visualizoElSiguienteMensajeFueraDeHorarioEnElComprobante(String arg0) {
        fondosMutuos.visualizoElSiguienteMensajeFueraDeHorarioEnElComprobante(arg0);

    }

    @Then("visualizo de forma correcta {string}")
    public void visualizoDeFormaCorrecta(String arg0, String arg1) {
        fondosMutuos.visualizoDeFormaCorrecta(arg0, arg1);
    }

    @And("visualizo boton invertir {string}")
    public void visualizoBotonInvertir(String arg0) {
        fondosMutuos.visualizoBotonInvertirInhabilitado(arg0);
    }

    @Then("visualizo el tab de {string} en Fondos Mutuos")
    public void visualizoElTabDeEnFondosMutuos(String arg0) {
        fondosMutuos.visualizoElTabDeEnFondosMutuos(arg0);
    }

    @And("visualizo de forma correcta el modal de {string}")
    public void visualizoDeFormaCorrectaElModalDe(String arg0, String arg1) {
        fondosMutuos.validoTitulo(arg0, arg1);
    }



    @And("presiono {string} en detalle de mis inversiones")
    public void presionoEnDetalleDeMisInversiones(String arg0) {
        fondosMutuos.presionoEnDetalleDeMisInversiones(arg0);
    }


    @Then("valido los fondos Seleccionados")
    public void validoLosFondosSeleccionados() {
        fondosMutuos.validoLosFondosSeleccionados();
    }

    @And("valido {string} en combobox Selecciona una Cartera Dinamica")
    public void validoEnComboboxSeleccionaUnaCarteraDinamica(String arg0) {
        fondosMutuos.validoEnComboboxSeleccionaUnaCarteraDinamica(arg0);
    }

    @And("valido {string} en combobox Selecciona un Fondo Mutuo")
    public void validoEnComboboxSeleccionaUnFondoMutuo(String arg0) {
        fondosMutuos.validoEnComboboxSeleccionaUnFondoMutuo(arg0);
    }

    @And("presiono la {string} en detalle de mis inversiones")
    public void presionoLaEnDetalleDeMisInversiones(String arg0) {
        fondosMutuos.presionoLaEnDetalleDeMisInversiones(arg0);
    }

    @Then("valido las carteras Seleccionados")
    public void validoLasCarterasSeleccionados() {
        fondosMutuos.validoLasCarterasSeleccionados();
    }

    @But("no se despliega ningun fondo en dolar")
    public void noSeDespliegaNingunFondoEnDolar(String arg0) {
        fondosMutuos.noSeDespliegaNingunFondoEnDolar(arg0);
    }

    @And("presiono el boton INVERTIR en el Fondo mutuo de {string} en SDPBP")
    public void presionoElBotonINVERTIREnElFondoMutuoDeEnSDPBP(String arg0) {
        fondosMutuos.presionoInvertirEnFondoMutuo(arg0);
    }

    @And("presiono el boton INVERTIR en el Fondo mutuo de {string} en SDPRE")
    public void presionoElBotonINVERTIREnElFondoMutuoDeEnSDPRE(String arg0) {
        fondosMutuos.presionoInvertirEnFondoMutuo(arg0);
    }

    @And("presiono el boton INVERTIR en el Fondo mutuo de {string} en SFULL")
    public void presionoElBotonINVERTIREnElFondoMutuoDeEnSFULL(String arg0) {
        fondosMutuos.presionoInvertirEnFondoMutuo(arg0);
    }

    @And("presiono el boton INVERTIR en el Fondo mutuo de {string} en SPBPM")
    public void presionoElBotonINVERTIREnElFondoMutuoDeEnSPBPM(String arg0) {
        fondosMutuos.presionoInvertirEnFondoMutuo(arg0);
    }

    @And("Presiono el tab de {string}")
    public void presionoElTabDe(String arg0) {
        fondosMutuos.presionoElTabDe(arg0);
    }

    @Then("Valido que el boton de {string} se encuentra deshabilitado para invertir en los fondos")
    public void ValidoQueElBotonDeSeEncuentraDeshabilitadoParaInvertirEnLosFondos(String arg0) {
        fondosMutuos.validoQueElBotonDeSeEncuentraDeshabilitadoParaInvertirEnLosFondos(arg0);
    }

    @And("Valido el mensaje en el texto")
    public void validoElMensajeEnElTexto(String arg0) {
        fondosMutuos.validoElMensajeEnElTexto(arg0);
    }

    @And("Selecciono el boton de {string} en {string}")
    public void seleccionoElBotonDeEn(String arg0, String arg1) {
        fondosMutuos.seleccionoElBotonDeEn(arg0, arg1);
    }

    @And("Ingreso el {string} en pantalla Datos de tu inversion")
    public void ingresoElEnPantallaDatosDeTuInversion(String arg0) {
        fondosMutuos.ingresoElEnPantallaDatosDeTuInversion(arg0);
    }

    @And("valido que el campo {string} tenga data")
    public void validoQueElCampoTengaData(String arg0) {
        fondosMutuos.validoQueElCampoTengaData(arg0);
    }

    @And("Presiono boton {string} en pantalla Datos de tu inversion")
    public void presionoBotonEnPantallaDatosDeTuInversion(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("Valido que el campo {string} contenga el campo con un correo")
    public void validoQueElCampoContengaElCampoConUnCorreo(String arg0) {
        fondosMutuos.validoQueElCampoContengaElCampoConUnCorreo(arg0);
    }

    @And("Presiono el check de {string}")
    public void presionoElCheckDe(String arg0) {
        fondosMutuos.presionoElCheckDe(arg0);
    }

    @And("Presiono el boton de {string} en la pantalla {string}")
    public void presionoElBotonDeEnLaPantalla(String arg0, String arg1) {
        fondosMutuos.presionoElBotonDeEnLaPantalla(arg0, arg1);
    }

    @Then("Valido de forma correcta el modal de Inversion")
    public void validoDeFormaCorrectaElModalDeInversion(String arg0) {
        fondosMutuos.validoDeFormaCorrectaElModalDeInversion(arg0);
    }

    @And("Valido el campo {string} en el comprobante")
    public void validoElCampoEnElComprobante(String arg0) {
        fondosMutuos.validoElCampoEnElComprobante(arg0);
    }

    @And("Valido el campo de {string} en el comprobante")
    public void ValidoElCampoDeEnElComprobante(String arg0) {
        fondosMutuos.validoElCampoDeEnElComprobante(arg0);
    }

    @And("valido el campo de {string} en el comprobante")
    public void validoElCampoDeEnElComprobante(String arg0) {
        fondosMutuos.validoElCampoDeEnElComprobante(arg0);
    }

    @And("valido el boton {string} en el comprobante")
    public void validoElBotonEnElComprobante(String arg0) {
        fondosMutuos.validoElBotonEnElComprobante(arg0);
    }

    @And("Valido boton {string} en el comprobante")
    public void validoBotonEnElComprobante(String arg0) {
        fondosMutuos.validoBotonEnElComprobante(arg0);
    }

    @And("presiono boton {string} en el comprobante")
    public void presionoBotonEnElComprobante(String arg0) {
        fondosMutuos.presionoBotonEnElComprobante(arg0);
    }

    @And("visualizo vitrina de {string}")
    public void visualizoVitrinaDe(String arg0) {
        fondosMutuos.visualizoVitrinaDe(arg0);
    }

    @Then("Valido mensaje de error {string}")
    public void validoMensajeDeError(String arg0) {
        fondosMutuos.validoMensajeDeError(arg0);
    }

    @Then("Valido que el campo {string} contenga solo cuentas en dolar")
    public void validoQueElCampoContengaSoloCuentasEnDolar(String arg0) {
        fondosMutuos.validoQueElCampoContengaSoloCuentasEnDolar(arg0);
    }

    @And("valido cuenta en USD {string}")
    public void validoCuentaEnUSD(String arg0) {
        fondosMutuos.validoCuentaEnUSD(arg0);
    }

    @And("Valido el titulo del fondo {string} {string} {string}")
    public void validoElTituloDelFondo(String arg0, String arg1, String arg2) {
        fondosMutuos.validoElTituloDelFondo(arg0, arg1, arg2);
    }

    @Then("valido que el boton de {string} se encuentra deshabilitado para invertir en los fondos")
    public void validoQueElBotonDeSeEncuentraDeshabilitadoParaInvertirEnLosFondos(String arg0) {
        fondosMutuos.validoQueElBotonDeSeEncuentraDeshabilitadoParaInvertirEnLosFondos(arg0);
    }

    @Then("Valido que no exista el filtro cuando hay solo un FFMMM")
    public void validoQueNoExistaElFiltroCuandoHaySoloUnFFMMM() {
        fondosMutuos.validoQueNoExistaElFiltroCuandoHaySoloUnFFMMM();
    }

    @And("Valido que solo se visualice {string} en la vitrina")
    public void validoQueSoloSeVisualiceEnLaVitrina(String arg0) {
        fondosMutuos.validoQueSoloSeVisualiceEnLaVitrina(arg0);
    }

    @Then("Valido que exista el filtro cuando hay varios Fondos Mutuos")
    public void validoQueExistaElFiltroCuandoHayVariosFondosMutuos() {
        fondosMutuos.validoQueExistaElFiltroCuandoHayVariosFondosMutuos();
    }

    @And("Presiono el filtro {string}")
    public void presionoElFiltro(String arg0) {
        fondosMutuos.presionoElFiltro(arg0);
    }

    @And("Selecciono {string} en la opcion de Filtra por Perfil de riesgo")
    public void seleccionoEnLaOpcionDeFiltraPorPerfilDeRiesgo(String arg0) {
        fondosMutuos.seleccionoEnLaOpcionDeFiltraPorPerfilDeRiesgo(arg0);
    }

    @And("Visualizo la cartera de {string} en INVERSION EN DOLARES")
    public void visualizoLaCarteraDeEnINVERSIONENDOLARES(String arg0) {
        fondosMutuos.visualizoLaCarteraDeEnINVERSIONENDOLARES(arg0);
    }

    @And("Visualizo en la pagina texto {string}")
    public void visualizoEnLaPaginaTexto(String arg0) {
        fondosMutuos.visualizoEnLaPaginaTexto(arg0);
    }

    @And("Visualizo boton {string}")
    public void visualizoBoton(String arg0) {
        fondosMutuos.visualizoBoton(arg0);
    }

    @Then("Visualizo modal de cliente sin perfil {string}")
    public void visualizoModalDeClienteSinPerfil(String arg0, String arg1) {
        fondosMutuos.visualizoModalDeClienteSinPerfil(arg0, arg1);
    }

    @And("Valido que dentro del modal exista boton {string}")
    public void validoQueDentroDelModalExistaBoton(String arg0) {
        fondosMutuos.validoQueDentroDelModalExistaBoton(arg0);
    }

    @And("valido campo cuanto quieres invertir debe indicar {string}")
    public void validoCampoCuantoQuieresInvertirDebeIndicar(String arg0) {
        fondosMutuos.validoCampoCuantoQuieresInvertirDebeIndicar(arg0);
    }

    @And("Valido Monto a Invertir {string}")
    public void validoMontoAInvertir(String arg0) {
        fondosMutuos.validoMontoAInvertir(arg0);
    }

    @And("Valido el campo Monto Invertido en el comprobante debe indicar en {string}")
    public void validoElCampoMontoInvertidoEnElComprobanteDebeIndicarEn(String arg0) {
        fondosMutuos.validoElCampoMontoInvertidoEnElComprobanteDebeIndicarEn(arg0);
    }


    @Then("visualizo modal fuera de horario AM")
    public void visualizoModalFueraDeHorarioAM() {
        fondosMutuos.visualizoModalFueraDeHorarioAM();
    }

    @Then("visualizo modal fuera de horario PM")
    public void visualizoModalFueraDeHorarioPM() {
        fondosMutuos.visualizoModalFueraDeHorarioPM();
    }

    @Then("visualizo modal fuera de horario Festivos")
    public void visualizoModalFueraDeHorarioFestivos() {
        fondosMutuos.visualizoModalFueraDeHorarioFestivos();
    }

    @Then("Visualizo modal riesgo perfil mayor a cliente")
    public void visualizoModalRiesgoPerfilMayorACliente() {
        fondosMutuos.visualizoModalRiesgoPerfilMayorACliente();
    }

    @And("valido titulo {string}")
    public void validoTitulo(String arg0, String arg1) {
        fondosMutuos.validoTitulo(arg0, arg1);
    }

    @Then("Visualizo flujo en USD")
    public void visualizoFlujoEnUSD() {
        fondosMutuos.visualizoFlujoEnUSD();
    }

    @And("valido titulo debe indicar fondo mutuo {string}")
    public void validoTituloDebeIndicarFondoMutuo(String arg0) {
        fondosMutuos.validoTituloDebeIndicar(arg0);
    }

    @Then("visualizo que el primer Fondo Mutuo sea de perfil {string}")
    public void visualizoQueElPrimerFondoMutuoSeaDePerfil(String arg0) {
        fondosMutuos.visualizoQueElPrimerFondoMutuoSeaDePerfil(arg0);
    }

    @Then("Visualizo el tab de {string} en Fondos Mutuos")
    public void VisualizoElTabDeEnFondosMutuos(String arg0) {
        fondosMutuos.visualizoElTabDeEnFondosMutuos(arg0);
    }

    @And("Presiono {string}")
    public void Presiono(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("Valido nombre de la cartera {string}")
    public void validoNombreDeLaCartera(String arg0) {
        fondosMutuos.validoNombreDeLaCartera(arg0);
    }

    @And("Borro el campo con el monto asignado")
    public void borroElCampoConElMontoAsignado() {
        fondosMutuos.borroElCampoConElMontoAsignado();

    }

    @And("Visualizo que el primer Fondo Mutuo sea perfil {string}")
    public void visualizoQueElPrimerFondoMutuoSeaPerfil(String arg0) {
        fondosMutuos.visualizoQueElPrimerFondoMutuoSeaPerfil(arg0);
    }

    @And("Presiono invertir en Fondo Mutuo {string}")
    public void presionoInvertirEnFondoMutuo(String arg0) {
        fondosMutuos.presionoInvertirEnFondoMutuo(arg0);
    }

    @And("Presiono check {string}")
    public void presionoCheck(String arg0) {
        fondosMutuos.presionoCheckk(arg0);
    }

    @And("Presiono boton {string} dentro del modal de riesgo mayor")
    public void presionoBotonDentroDelModalDeRiesgoMayor(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @Then("Visualizo primera pantalla {string}")
    public void visualizoPrimeraPantalla(String arg0) {
        fondosMutuos.visualizoPrimeraPantalla(arg0);
    }


    @And("Presiono boton {string} en Carrito pegado en la parte inferior de la pantalla")
    public void presionoBotonEnCarritoPegadoEnLaParteInferiorDeLaPantalla(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("Presiono boton de {string} en pantalla de comparacion en el fondo {string}")
    public void presionoBotonDeEnPantallaDeComparacionEnElFondo(String arg0, String arg1) {
        fondosMutuos.presionoBotonDeEnPantallaDeComparacionEnElFondo(arg0, arg1);
    }

    @Then("Visualizo pantalla de {string}")
    public void visualizoPantallaDe(String arg0) {
        fondosMutuos.visualizoPantallaDe(arg0);
    }

    @Then("Visualizo el boton {string} en el carrito deshabilitado")
    public void visualizoElBotonEnElCarritoDeshabilitado(String arg0) {
        fondosMutuos.visualizoElBotonEnElCarritoDeshabilitado(arg0);
    }

    @And("Visualizo que el boton de invertir en el Fondo {string} se encuentre deshabilitado")
    public void visualizoQueElBotonDeInvertirEnElFondoSeEncuentreDeshabilitado(String arg0) {
        fondosMutuos.visualizoQueElBotonDeInvertirEnElFondoSeEncuentreDeshabilitado(arg0);
    }

    @Then("visualizo el modal correspondiente al cliente {string}")
    public void visualizoElModalCorrespondienteAlCliente(String arg0) {
        fondosMutuos.visualizoElModalCorrespondienteAlCliente(arg0);
    }

    @And("Visualizo modal de {string}")
    public void visualizoModalDe(String arg0) {
        fondosMutuos.visualizoModalDe(arg0);
    }

    @And("visualizo {string} {string}")
    public void visualizo(String arg0, String arg1) {
        fondosMutuos.visualizo(arg0, arg1);
    }

    @And("Selecciono el check de {string} en Fondo {string}")
    public void seleccionoElCheckDeEnFondo(String arg0, String arg1) {
        fondosMutuos.seleccionoElCheckDeEn(arg0, arg1);
    }

    @And("Presiono el boton de {string} en conoce tu nuevo resumen de inversion")
    public void presionoElBotonDeEnConoceTuNuevoResumenDeInversion(String arg0) {
        fondosMutuos.resumenDeInversiones(arg0);
    }

    @And("Presiono {string} en Detalle de mis inversiones")
    public void PresionoEnDetalleDeMisInversiones(String arg0) {
        fondosMutuos.resumenDeInversiones(arg0);
    }

    @And("Presiono {string} en recuadro de Carteras Dinamicas y Patrimoniales")
    public void presionoEnRecuadroDeCarterasDinamicasYPatrimoniales(String arg0) {
        fondosMutuos.resumenDeInversiones(arg0);
    }

    @Then("Visualizo titulo {string}")
    public void visualizoTitulo(String arg0) {
        fondosMutuos.visualizoTitulo(arg0);
    }

    @And("Valido que el boton {string} se encuentre habilitado")
    public void validoQueElBotonSeEncuentreHabilitado(String arg0) {
        fondosMutuos.resumenDeInversiones(arg0);
    }

    @And("Valido boton {string} habilitado")
    public void validoBotonHabilitado(String arg0) {
        fondosMutuos.resumenDeInversiones(arg0);
    }

    @And("Espero minutos despues de horario inhabil")
    public void esperoMinutosDespuesDeHorarioInhabil() {
        fondosMutuos.esperando();
    }

    @Then("Visualizo el modal {string} en la vitrina")
    public void visualizoElModalEnLaVitrina(String arg0, String arg1) {
        fondosMutuos.visualizoElModalEnLaVitrina(arg0, arg1);
    }

    @And("Valido que el boton {string} se encuentre habilitado dentro del modal")
    public void validoQueElBotonSeEncuentreHabilitadoDentroDelModal(String arg0) {
        fondosMutuos.validoQueElBotonSeEncuentreHabilitadoDentroDelModal(arg0);
    }

    @And("Presiono el boton {string} que se encuentra dentro del modal")
    public void presionoElBotonQueSeEncuentraDentroDelModal(String arg0) {
        fondosMutuos.presionoElBotonQueSeEncuentraDentroDelModal(arg0);
    }

    @And("Presiono el boton de {string} dentro del saber mas")
    public void presionoElBotonDeDentroDelSaberMas(String arg0) {
        fondosMutuos.presionoElBotonDeDentroDelSaberMas(arg0);
    }

    @Then("Visualizo que los botones de invertir se encuentren deshabilitado")
    public void visualizoQueLosBotonesDeInvertirSeEncuentrenDeshabilitado() {
        fondosMutuos.visualizoQueLosBotonesDeInvertirSeEncuentrenDeshabilitado();
    }

    @Then("visualizo el mensaje de alerta correspondiente al cliente {string}")
    public void visualizoElMensajeDeAlertaCorrespondienteAlCliente(String arg0) {
        fondosMutuos.visualizoElMensajeDeAlertaCorrespondienteAlCliente(arg0);
    }

    @Then("visualizo el comprobante de forma correcta")
    public void visualizoElComprobanteDeFormaCorrecta() {
        fondosMutuos.visualizoElComprobanteDeFormaCorrecta();
    }


    @And("Valido documento adjunto {string}")
    public void validoDocumentoAdjunto(String arg0) {
        fondosMutuos.validoDocumentoAdjunto(arg0);
    }

    @Then("Valido titulo {string} en pantalla confirma tu inversion")
    public void validoTituloEnPantallaConfirmaTuInversion(String arg0) {
        fondosMutuos.validoTituloEnPantallaConfirmaTuInversion(arg0);
    }

    @And("Valido checkbox de contrato general de fondos")
    public void validoCheckboxDeContratoGeneralDeFondos(String arg0) {
        fondosMutuos.validoCheckboxDeContratoGeneralDeFondos(arg0);

    }

    @And("presiono el boton de {string} desde comparar")
    public void presionoElBotonDeDesdeComparar(String arg0) {
        fondosMutuos.presionoElBotonDeDesdeComparar(arg0);
    }

    @Then("visualizo el mensaje de alerta correspondiente al cliente {string}sin cuenta usd")
    public void visualizoElMensajeDeAlertaCorrespondienteAlClienteSinCuentaUsd(String arg0) {
        fondosMutuos.visualizoElMensajeDeAlertaCorrespondienteAlClienteSinCuentaUsd(arg0);
    }

    @And("Presiono el boton de {string} en la vitrina en el fondo de {string}")
    public void presionoElBotonDeEnLaVitrinaEnElFondoDe(String arg0, String arg1) {
        fondosMutuos.seleccionoElBotonDeEn(arg0, arg1);
    }

    @Then("Valido de forma correcta el boton {string} se encuentre deshabilitado")
    public void validoDeFormaCorrectaElBotonSeEncuentreDeshabilitado(String arg0) {
        fondosMutuos.validoDeFormaCorrectaElBotonSeEncuentreDeshabilitado(arg0);
    }

    @Then("visualizo el modal no disponible correspondiente {string}")
    public void visualizoElModalNoDisponibleCorrespondiente(String arg0, String arg1) {
        fondosMutuos.visualizoElModalNoDisponibleCorrespondiente(arg0, arg1);
    }

    @Then("Valido nombre de la cartera")
    public void validoNombreDeLaCartera(DataTable cartera) {
        validoCarteras(cartera);
    }

    protected void validoCarteras(DataTable cartera) {
        try {
            List<Map<String, String>> rows = cartera.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("cartera");
                if (validaElemento("(//*[normalize-space()='" + name + "'])[1]", 2)) {
                    WebElement objeto = existeElemento("(//*[normalize-space()='" + name + "'])[1]", 2);
                    visualizarObjetoScroll(objeto, 3);
                    PdfBciReports.addWebReportImage("Valido carteras", "Se valida nombre de cartera : " + name, PASSED, false);
                } else validaElemento("(//*[normalize-space()='" + name + "'])[2]", 2);
                {
                    WebElement objeto = existeElemento("(//*[normalize-space()='" + name + "'])[2]", 2);
                    visualizarObjetoScroll(objeto, 3);
                    PdfBciReports.addReport("Valido carteras", "Se valida nombre de cartera : " + name, PASSED, false);
                }
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @And("Presiono boton {string} en modal desplegado.")
    public void presionoBotonEnModalDesplegado(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("Visualizo boton {string} en modal desplegado")
    public void visualizoBotonEnModalDesplegado(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @Then("visualizo el modal correspondiente al cliente {string} en vitrina")
    public void visualizoElModalCorrespondienteAlClienteEnVitrina(String arg0) {
        fondosMutuos.visualizoElModalCorrespondienteAlClienteEnVitrina(arg0);
    }

    @And("Valido los siguientes textos en la pantalla confirmacion de tu inversion")
    public void validoLosSiguientesTextosEnLaPantallaConfirmacionDeTuInversion(DataTable texto) {
        validoLosTextosConfirmacion(texto);
    }

    protected void validoLosTextosConfirmacion(DataTable texto) {
        esperar(15);
        try {
            List<Map<String, String>> rows = texto.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("texto");
                validaElemento("(//*[contains(text(),'" + name + "')])[1]", 2);
                PdfBciReports.addReport("Valido textos Confirmación", "Se valida textos de confirmación : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @And("Valido los siguientes textos en la pantalla datos de tu inversion")
    public void validoLosSiguientesTextosEnLaPantallaDatosDeTuInversion(DataTable texto) {
        validoTextoDatosDeTuInversion(texto);
    }

    protected void validoTextoDatosDeTuInversion(DataTable texto) {
        esperar(20);
        try {
            List<Map<String, String>> rows = texto.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("texto");
                validaElemento("(//*[contains(text(),'" + name + "')])[1]", 3);
                PdfBciReports.addReport("Valido textos Datos de tu inverión", "Se valida textos en la pantalla Datos de tu inversión  : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @And("valido boton {string} dentro de la pantalla de confirmacion")
    public void validoBotonDentroDeLaPantallaDeConfirmacion(String arg0) {
        fondosMutuos.validoBotonDentroDeLaPantallaDeConfirmacion(arg0);
    }

    @And("Valido los siguientes textos en la pantalla de comprobante")
    public void validoLosSiguientesTextosEnLaPantallaDeComprobante(DataTable texto) {
        fondosMutuos.encuestaMedallia();
        validoTextosComprobante(texto);
    }

    protected void validoTextosComprobante(DataTable texto) {
        try {
            List<Map<String, String>> rows = texto.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("texto");
                validaElemento("(//*[contains(text(),'" + name + "')])[1]", 2);
                PdfBciReports.addReport("Valido textos Comprobante", "Se valida textos de Comprobante  : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @And("presiono el boton {string} en la cartera de {string}")
    public void presionoElBotonEnLaCarteraDe(String arg0, String arg1) {
        carteras.presionoElBotonEnLaCarteraDe(arg0, arg1);
    }

    @And("presiono el boton {string} en el modal perfil mayor")
    public void presionoElBotonEnElModalPerfilMayor(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }



    @Then("Valido que el campo {string} en rango valido FFMM USD")
    public void validoQueElCampoEnRangoValidoFFMMUSD(String arg0) {
        fondosMutuos.validoQueElCampoEnRangoValidoFFMMUSD(arg0);
    }

    @Then("Valido que el campo {string} en rango valido Carteras USD")
    public void validoQueElCampoEnRangoValidoCarterasUSD(String arg0) {
        fondosMutuos.validoQueElCampoEnRangoValidoCarterasUSD(arg0);
    }

    @And("ingreso los datos en la primera pantalla dolar {string}")
    public void ingresoLosDatosEnLaPrimeraPantallaDolar(String arg0) {
        fondosMutuos.ingresoLosDatosEnLaPrimeraPantallaDolar(arg0);
    }

    @And("valido los textos dentro del saber mas")
    public void validoLosTextosDentroDelSaberMas(DataTable texto) {
      esperar(8);
      validoTextosSaberMas(texto);
    }

    protected void validoTextosSaberMas(DataTable texto) {
        try {
            List<Map<String, String>> rows = texto.asMaps(String.class, String.class);
            for (Map<String, String> row : rows) {
                String name = row.get("texto");
                validaElemento("(//*[contains(text(),'" + name + "')])[1]", 2);
                PdfBciReports.addReport("Valido textos Saber más", "Se valida textos dentro del Saber más  : " + name, PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @And("Presiono {string} en los tabs de saber mas")
    public void presionoEnLosTabsDeSaberMas(String arg0) {
        fondosMutuos.presionoElBotonEnLaWeb(arg0);
    }

    @And("Valido los textos en el comparador")
    public void validoLosTextosEnElComparador(DataTable texto) {
        esperar(5);
        validoTextosSaberMas(texto);
    }

    @And("Valido el envio de correo electronico de forma correcta")
    public void validoElEnvioDeCorreoElectronicoDeFormaCorrecta() {
        fondosMutuos.ingresoAlCorreoBcicert();
        fondosMutuos.validoAsuntoCorreoFFMM();
        //fondosMutuos.validoTextoCorreo();
    }

    @And("Presiono el boton de {string} en {string}")
    public void presionoElBotonDeEn(String arg0, String arg1) {
        fondosMutuos.seleccionoElBotonDeEn(arg0,arg1);
    }

    @And("Valido etiqueta {string}")
    public void validoEtiqueta(String arg0) {
        fondosMutuos.validoEtiqueta(arg0);
    }

    @And("Valido el texto de alerta {string}")
    public void validoElTextoDeAlerta(String arg0) {
         fondosMutuos.validoMensajeDeError(arg0);
    }

    @And("valido que el boton de {string} se encuentre deshabilitado")
    public void validoQueElBotonDeSeEncuentreDeshabilitado(String arg0) {
        fondosMutuos.validoQueElBotonDeSeEncuentreDeshabilitado(arg0);

    }

    @And("Ingreso un segundo {string}")
    public void ingresoUnSegundo(String arg0) {
        fondosMutuos.ingresoUnSegundo(arg0);
    }

    @Then("valido que el boton de {string} se encuentre habilitado")
    public void validoQueElBotonDeSeEncuentreHabilitado(String arg0) {
        fondosMutuos.validoQueElBotonDeSeEncuentreHabilitado(arg0);
    }

    @And("Selecciono el boton de ver mas {string} en {string}")
    public void seleccionoElBotonDeVerMasEn(String arg0, String arg1) {
        fondosMutuos.seleccionoElBotonDeVerMasEn(arg0,arg1);
    }

    @And("Presiono el boton de {string} en serie {string}")
    public void presionoElBotonDeEnSerie(String arg0, String arg1) {
        fondosMutuos.presionoElBotonDeEnSerie(arg0,arg1);
    }

    @And("Presiono el boton de {string} en serie ap {string}")
    public void presionoElBotonDeEnSerieAp(String arg0, String arg1) {
        fondosMutuos.presionoElBotonDeEnSerieAp(arg0,arg1);
    }

    @Then("Visualizo la opcion de {string}")
    public void visualizoLaOpcionDe(String arg0) {
        fondosMutuos.menu(arg0);
    }


    @And("Valido el titulo del fondo {string} Invierte desde {string}")
    public void validoElTituloDelFondoInvierteDesde(String arg0, String arg1) {
        fondosMutuos.validoElTituloDelFondoInvierteDesde(arg0,arg1);
    }

    @And("Presiono el boton de {string} en la pantalla Confirma tu inversion")
    public void presionoElBotonDeEnLaPantallaConfirmaTuInversion(String arg0) {
        fondosMutuos.presionoElBotonDeEnLaPantallaConfirmaTuInversion(arg0);
    }



}