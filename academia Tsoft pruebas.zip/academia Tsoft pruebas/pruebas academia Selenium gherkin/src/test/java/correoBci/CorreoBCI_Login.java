package correoBci;

import driverWeb.DriverContextWeb;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import util.Acciones;
import utils.MetodosGenericos;
import utils.web.GenericValidations;

import java.util.logging.Logger;

import static constants.Constants.EXCEPCION;

public class CorreoBCI_Login extends Acciones {
    public static final Logger LOGGER = Logger.getLogger("pages.correoBci.CorreoBCI_Login.Class");
    // Elementos
    @FindBy(xpath = "//*[@id='loginBox']") // Cuadro de Login
    protected WebElement cuadroLogin;
    @FindBy(xpath = "//*[@id='loginBox']/h2") // Titulo del cuadro de login
    protected WebElement txtTitulo;
    @FindBy(xpath = "//*[@id='user']") // Campo para el usuario
    protected WebElement campoUsuario;
    @FindBy(xpath = "//*[@id='passwd']") // Campo para la contraseña
    protected WebElement campoContrasena;
    @FindBy(xpath = "//*[@id='loginBox']/p/input") // Boton para iniciar sesion
    protected WebElement btnInicio;


    public CorreoBCI_Login() {
        PageFactory.initElements(DriverContextWeb.getDriverWeb(), this);
    }

    @Step("Validar los objetos de la pagina")
    @Description("Metodo para validar todos los valores que deben estar en esta pagina esten presente")
    public void validarObjeto() {
        try {
            GenericValidations.existElementReport(cuadroLogin, false);
            GenericValidations.existElementReport(txtTitulo, false);
            GenericValidations.existElementReport(campoUsuario, false);
            GenericValidations.existElementReport(campoContrasena, false);
            GenericValidations.existElementReport(btnInicio, false);

            PdfBciReports.addWebReportImage("Login Correo BCI", "Se validan los objetos.", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    @Step("Realizar Login")
    @Description("Ingresa los datos por parametro para realizar el login")
    public void loginCorreo(String user, String pass) {
        try {
            DriverContextWeb.getDriverWeb().get("http://bcicert/mail/");
            MetodosGenericos.esperar(3);
            if (existe("//*[@id='user']")) {
                campoUsuario.sendKeys(user);
                campoContrasena.sendKeys(pass);
                PdfBciReports.addWebReportImage("Correo Bci", "Se ingresa a Correo de certificación con el usuario y la clave jpaineq", EstadoPrueba.PASSED, false);
                clickAlElementoConJavascript(btnInicio);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }



}
