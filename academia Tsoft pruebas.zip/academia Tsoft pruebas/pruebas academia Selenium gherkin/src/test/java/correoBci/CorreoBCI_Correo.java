package correoBci;

import driverWeb.DriverContextWeb;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import util.Acciones;
import utils.web.GenericValidations;

import java.util.logging.Logger;

import static constants.Constants.EXCEPCION;

public class CorreoBCI_Correo extends Acciones {
    public static final Logger LOGGER = Logger.getLogger("pages.correo.CorreoBCI_Correo.Class");
    @FindBy(xpath = "//*[@id=\"main\"]/div[5]/div/table/tbody/tr/td/table") // Contenido del Correo
    protected WebElement txtContenido;


    @FindBy(xpath = "//div[text()='Nombre']") // Contenido del Correo
    protected WebElement txtNombre;
    @FindBy(xpath = "//div[text()='Rut']") // Contenido del Correo
    protected WebElement txtRut;
    @FindBy(xpath = "//div[text()='Email']") // Contenido del Correo
    protected WebElement txtEmail;
    @FindBy(xpath = "//div[text()='Grupo de servicios']") // Contenido del Correo
    protected WebElement txtGrupoServicios;
    @FindBy(xpath = "//div[text()='Empresas']") // Contenido del Correo
    protected WebElement txtEmpresas;
    @FindBy(xpath = "//div[text()='Convenios']") // Contenido del Correo
    protected WebElement txtConvenios;
    @FindBy(xpath = "//div[contains(text(),'Rut Empresa')]") //
    protected WebElement txtRutempresa;
    @FindBy(xpath = "//div[contains(text(),'Seguros')]") //
    protected WebElement txtseguros;


    public CorreoBCI_Correo() {
        PageFactory.initElements(DriverContextWeb.getDriverWeb(), this);
    }

    @Step("Validar los objetos de la pagina")
    @Description("Metodo que realiza click en el asunto del correo")
    public void validarObjeto() {
        try {
            GenericValidations.existElementReport(txtContenido, true);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void seleccionaAsunto(String asunto) {
        try {
            LOGGER.info("se selecciona el asunto");
            WebElement asuntoCorreo = DriverContextWeb.getDriverWeb().findElement(By.xpath(" (//a[contains(text(),'" + asunto + "')])[1]"));
            clickAlElementoConJavascript(asuntoCorreo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @Step("Validar los objetos de la pagina")
    @Description("Metodo que realiza click en el asunto del correo")
    public void verificarTextoCreacionUsuario(String rut) {
        try {

            validaElemento(txtNombre, "texto Nombre", 20, false);
            validaElemento(txtRut, "texto Rut", 20, false);
            WebElement txtUsuarioCreado = DriverContextWeb.getDriverWeb().findElement(By.xpath("//p[text()='" + rut + "']"));
            validaElemento(txtUsuarioCreado, "texto Rut del usuario creado", 20, false);
            validaElemento(txtEmail, "texto Email", 20, false);
            validaElemento(txtGrupoServicios, "texto Grupo servicio", 20, false);
            validaElemento(txtEmpresas, "texto Empresa", 20, false);
            validaElemento(txtConvenios, "texto Convenios", 20, true);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


}
