package correoBci;

import driverWeb.DriverContextWeb;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import util.Acciones;
import util.NetworkChrome;
import utils.web.GenericValidations;

import java.util.List;

import static constants.Constants.EXCEPCION;

public class CorreoBCI_Bandeja extends Acciones {
    @FindBy(xpath = "//*[@id='main']/div[1]/ul/li[1]/a") // Titulo de la pagina
    protected WebElement txtTitulo;
    @FindBy(xpath = "//*[@id='inboxTable']/tbody/tr[1]/th[6]/a") // Asunto de correo
    protected WebElement asuntoCorreo;

    @FindBy(css = "td.column3 > a")
    protected List<WebElement> lblColumnaAsunto;

    @FindBy(xpath = "//a[contains(text(),'Siguiente')]")
    protected WebElement btnSiguiente;

    public CorreoBCI_Bandeja() {
        PageFactory.initElements(DriverContextWeb.getDriverWeb(), this);
    }


    @Step("Validar los objetos de la pagina")
    @Description("Metodo para validar todos los valores que deben estar en esta pagina esten presente")
    public void validarObjeto() {
        try {
            GenericValidations.existElementReport(txtTitulo, false);
            GenericValidations.existElementReport(asuntoCorreo, false);
            PdfBciReports.addWebReportImage("Asunto del correo", "Se validan los objetos.", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void asuntoCorreo() {
        try {
            for (int i = 0; i < lblColumnaAsunto.size(); i++) {
                if (lblColumnaAsunto.get(i).getText().equals("Resultado Aprobacion Credito Hipotecario")) {
                    PdfBciReports.addWebReportImage("Validando asunto del correo", "Validacion del texto del correo OK", EstadoPrueba.PASSED, false);
                    lblColumnaAsunto.get(i).click();
                    NetworkChrome.capturaRequest();
                    break;
                }
                if (lblColumnaAsunto.size() == i) {
                    lblColumnaAsunto.get(i).getText();
                }
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    @Step("Valida el asunto del correo")
    @Description("Metodo que realiza click en el asunto del correo")
    public void asuntoCorreo(String asunto) {
        try {
            boolean encontrado = false;
            for (int i = 0; i < lblColumnaAsunto.size(); i++) {
                if (lblColumnaAsunto.get(i).getText().contains(asunto)) {
                    PdfBciReports.addWebReportImage("Asunto del correo", "Se Valida asunto del correo OK : " + asunto, EstadoPrueba.PASSED, false);
                    lblColumnaAsunto.get(i).click();
                    NetworkChrome.capturaRequest();
                    encontrado = true;
                    break;
                }
                if (lblColumnaAsunto.size() == i) {
                    lblColumnaAsunto.get(i).getText();
                }
            }
            while(!encontrado && existe("(//a[contains(text(),'Siguiente')])[1]")) {
                clickAlElementoConJavascript(btnSiguiente);
                for (WebElement webElement : lblColumnaAsunto) {
                    if (webElement.getText().contains(asunto)) {
                        PdfBciReports.addWebReportImage("Validando asunto del correo", "Validacion del texto del correo OK", EstadoPrueba.PASSED, false);
                        webElement.click();
                        NetworkChrome.capturaRequest();
                        encontrado = true;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    @Step("Valida el asunto del correo")
    @Description("Metodo que realiza click en el asunto del correo")
    public void asuntoCorreoComercial(String asunto) {
        try {
            for (int i = 0; i < lblColumnaAsunto.size(); i++) {

                if (lblColumnaAsunto.get(i).getText().contains(asunto)) {
                    PdfBciReports.addWebReportImage("Validando asunto del correo", "Validacion del texto del correo OK", EstadoPrueba.PASSED, false);
                    lblColumnaAsunto.get(i).click();
                    NetworkChrome.capturaRequest();
                    break;
                }
                if (lblColumnaAsunto.size() == i) {
                    lblColumnaAsunto.get(i).getText();
                }
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @Step("Valida el asunto del correo credito comercial")
    @Description("Metodo que realiza click en el asunto del correo")
    public void asuntoCorreoCreditoComercial1(String asunto) {
        try {
            boolean encontro = false;
            for (WebElement webElement : lblColumnaAsunto) {
                if (webElement.getText().contains(asunto)) {
                    PdfBciReports.addWebReportImage("Validando asunto del correo", "Validacion del texto del correo OK", EstadoPrueba.PASSED, false);
                    webElement.click();
                    NetworkChrome.capturaRequest();
                    encontro = true;
                    break;

                }
            }
            if (!encontro) {
                PdfBciReports.addWebReportImage("Validando asunto del correo", "Validacion del texto del correo NOK", EstadoPrueba.FAILED, true);
            }

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

}
