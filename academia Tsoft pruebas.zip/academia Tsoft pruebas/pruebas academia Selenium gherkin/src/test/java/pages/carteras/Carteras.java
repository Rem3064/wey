package pages.carteras;

import driverWeb.DriverContextWeb;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import util.Acciones;
import utils.web.UtilsWeb;

import java.util.logging.Logger;

import static constants.Constants.EXCEPCION;
import static utils.MetodosGenericos.esperar;
import static utils.web.ControlledActionsWeb.visualizarObjeto;
import static utils.web.ControlledActionsWeb.visualizarObjetoScroll;

public class Carteras extends Acciones {
    public static final Logger LOGGER = Logger.getLogger("Carteras");
    public Carteras() {
        PageFactory.initElements(DriverContextWeb.getDriverWeb(), this);
    }

    @FindBy(xpath = "//span[normalize-space()='la rentabilidad histórica de la Cartera']")
    protected WebElement calculadoraCartera;
    @FindBy (xpath = "//input[@placeholder='Ingresa un monto'][@type = 'text']")
    protected  WebElement inputmonto;

    @FindBy (xpath = "//input[@placeholder='Ingresa días'][@type = 'tel']")
    protected WebElement inputdiashace;

    @FindBy(xpath = "//button[@ng-keypress='handleXPressed($event)']")
    protected WebElement cerrarEncuestaMedallia;
    @FindBy(xpath = "//*[@id=\"kampyleForm12488\"]")
    protected WebElement iframeMedallia;
    @FindBy(xpath = "//input[@value='5']")
    protected WebElement cincoestrellas;
    @FindBy(xpath = "//button[@ng-click='submit()']")
    protected WebElement enviarEncuesta;
    @FindBy(xpath = "(//i[@class='fa fa-times font-size-20'])[1]")
    protected WebElement closeEncuestaMedallia;
    @FindBy(xpath = "//label[contains (text(),'¿Qué tan satisfactoria fue la experiencia que viviste hoy en inversión en')]")
    protected WebElement preguntaInicialMedallia;

    public void presionoElBotonINVERTIREnLaCarteraDe(String arg0) {
        try {
            esperar(5);
            WebElement invertir = existeElemento("//span[contains (text(),'" + arg0 + "')]//ancestor::bci-card//descendant::button[contains(text(),'Invertir')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón invertir Carteras", "Se selecciona boton de Invertir en la cartera  " + arg0, EstadoPrueba.PASSED, false);
            invertir.click();
            UtilsWeb.desenmarcarObjeto(invertir);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoBotonDeLa(String arg0, String arg1) {
        try {
            esperar(7);
            WebElement invertir = existeElemento("//span[contains (text(),'" + arg1 + "')]//ancestor::bci-card//descendant::button[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón  " + arg0 , "Se selecciona boton de " + arg0 + " en  " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(invertir);
            invertir.click();
            esperar(5);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoModal(String arg0, String arg1) {
       try {
        esperar(10);
        WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
        visualizarObjetoScroll(elemento, 2);
        UtilsWeb.enmarcarObjeto(elemento);
        PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + " a cliente  " + arg1 , EstadoPrueba.PASSED, false);
        UtilsWeb.desenmarcarObjeto(elemento);
        esperar(2);
       } catch (Exception e) {
           LOGGER.severe(EXCEPCION + e);
           reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
       }
    }

    public void validoLosBotonesDeshabilitadoEnLaVitrinaDeCarteras(String arg0) {
        try {
            esperar(5);
            WebElement btnInhabil = existeElemento("//*[@id=\"content\"]/app-root/app-highlights/div/div[1]/div/app-hightlight-card/div/div[1]/bci-card/div[2]/div[6]/button[2]", 3);
            visualizarObjetoScroll(btnInhabil, 2);
            UtilsWeb.enmarcarObjeto(btnInhabil);
            PdfBciReports.addWebReportImage("Botón de invertir deshabilitado", "El botón de " + arg0 + " se encuentra deshabilitado en el  Tab de Inversión en Dólares", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(btnInhabil);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }



    public void visualizoElCalculoRealizadoEn(String arg0) {
        try {
            esperar(7);
            WebElement titulo = existeElemento("//p[@class='returns-calculator__result__title text-darker bci-wk-h450']",2);
            PdfBciReports.addWebReportImage("Titulo " + arg0 , "Se viualiza el titulo " + titulo.getText(), EstadoPrueba.PASSED, false);
            WebElement calculo = existeElemento("//p[@class='returns-calculator__result__subtitle wk-text-green-500 bci-wk-h450']", 2);
            UtilsWeb.enmarcarObjeto(calculo);
            PdfBciReports.addWebReportImage("Calculo de Saber más", "Se visualiza resultado del calculo de Saber más " + calculo.getText(), EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(calculo);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoCheckDeLaCartera(String arg0, String arg1) {
        try {
            WebElement compara = existeElemento("//span[contains (text(),'" + arg1 + "')]//ancestor::bci-card//descendant::span[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']", 2);
            visualizarObjetoScroll(compara, 2);
            UtilsWeb.enmarcarObjeto(compara);
            PdfBciReports.addWebReportImage("Check compara cartera dólar", "Se selecciona check de " + arg0 + "  en  " + arg1, EstadoPrueba.PASSED, false);
            compara.click();
            UtilsWeb.desenmarcarObjeto(compara);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoBotonDeEnPantallaDeComparacionEnLaCartera(String arg0, String arg1) {
        try {
            esperar(7);
            WebElement invertir = existeElemento("//div[contains (text(),'" + arg1 + "')]//ancestor::app-mutual-fund-comparator-card-comparator//descendant::button[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón invertir fondo mutuo", "Se selecciona boton de " + arg0 + " en el fondo  " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(invertir);
            invertir.click();
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueElBotonDeInvertirEnLaCarteraSeEncuentreDeshabilitado(String arg0) {
        try {
            esperar(7);
            WebElement invertir = existeElemento("//div[contains (text(),'" + arg0 + "')]//ancestor::app-mutual-fund-comparator-card-comparator//descendant::button[contains(text(),'Invertir')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón invertir fondo mutuo", "Se selecciona boton de Invertir en el fondo  " + arg0, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(invertir);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoLaSiguienteAlerta(String arg0) {
        try {
            esperar(15);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonDeEnVitrina(String arg0, String arg1) {
        try {
            esperar(7);
            WebElement invertir = existeElemento("//span[contains (text(),'" + arg1 + "')]//ancestor::bci-card//descendant::button[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón invertir fondo mutuo", "Se selecciona boton de " + arg0 + " en el fondo  " + arg1, EstadoPrueba.PASSED, false);
            invertir.click();
            UtilsWeb.desenmarcarObjeto(invertir);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoBotonDeEnLaVitrina(String arg0,String arg1) {
        try {
            esperar(7);
            WebElement vermas = existeElemento("//span[contains (text(),'" + arg1 + "')]//ancestor::bci-card//descendant::span[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(vermas, 2);
            UtilsWeb.enmarcarObjeto(vermas);
            PdfBciReports.addWebReportImage("Botón ver mas fondo mutuo", "Se selecciona boton de " + arg0 + " en el fondo  " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(vermas);
            vermas.click();
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoDeFormaCorrectaElModalDeInversionDeCarteras(String arg0) {
        try {
            esperar(40);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeMedallia);
            WebElement marco = existeElemento("//div[@class='modal-live-form ng-scope']",3);
            UtilsWeb.enmarcarObjeto(marco);
            scrollAlElementoConJavascript(closeEncuestaMedallia);
            PdfBciReports.addWebReportImage("Encuesta Medallia", "Se visualiza la encuesta Medallia", EstadoPrueba.PASSED, false);
            visualizarObjeto(enviarEncuesta, 3);
            visualizarObjeto(cincoestrellas,3);
            visualizarObjeto(cerrarEncuestaMedallia, 3);
            visualizarObjeto(preguntaInicialMedallia,3);
            esperar(1);
            UtilsWeb.desenmarcarObjeto(marco);
            PdfBciReports.addWebReportImage("Cierre encuesta Medallia", "Se cierra la encuesta Medallia", EstadoPrueba.PASSED, false);
            esperar(1);
            cerrarEncuestaMedallia.click();
            esperar(1);
            DriverContextWeb.getDriverWeb().switchTo().parentFrame();
            WebElement elemento = existeElemento("//p[@class='confirmation-header_title bci-wk-h1000']", 3);
            visualizarObjetoScroll(elemento, 2);
            validaElemento(elemento, "modal de inversión", 2, true);
            PdfBciReports.addWebReportImage("Modal inversión Carteras", "Valido de forma correcta el Modal de Inversión de Carteras " + arg0 , EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonEnLaCarteraDe(String arg0, String arg1) {
        try {
            esperar(30);
            WebElement invertir = existeElemento("//span[contains (text(),'" + arg1 + "')]//ancestor::bci-card//descendant::button[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón invertir carteras", "Se selecciona boton de " + arg0 + " en el fondo  " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(invertir);
            invertir.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoMontoEnPantallaMontoObtenido(String arg0) {
        try {
        esperar(1);
        visualizarObjetoScroll(calculadoraCartera,3);
        inputmonto.clear();
        inputmonto.sendKeys(arg0);
        PdfBciReports.addWebReportImage("ingreso el monto en la calculadora la rentabilidad historica de la Cartera", "Se ingresa el monto : " + arg0 + "  en la calculadora la rentabilidad historica de Carteras", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoDiasEnPantallaMontoObtenido(String arg0) {
        try {
        inputdiashace.clear();
        inputdiashace.sendKeys("365");
        esperar(2);
        PdfBciReports.addWebReportImage("ingreso los dias en la calculadora la rentabilidad historica de la Cartera", "Se ingresan los dias  :  " + arg0 + " en la calculadora la rentabilidad historica de Carteras", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }
}
