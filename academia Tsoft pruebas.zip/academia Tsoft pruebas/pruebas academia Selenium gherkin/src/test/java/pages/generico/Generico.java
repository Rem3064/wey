package pages.generico;

import driverWeb.DriverContextWeb;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import util.Acciones;
import util.LogErrorInChrome;
import utils.MetodosGenericos;
import utils.web.ControlledActionsWeb;
import utils.web.GenericValidations;

import java.util.logging.Logger;

import static constants.Constants.EXCEPCION;
import static utils.MetodosGenericos.esperar;

public class Generico extends Acciones {
    private WebDriver driver;
    JavascriptExecutor js = (JavascriptExecutor) driver;
    public static final Logger LOGGER = Logger.getLogger("pages.Generico.Class");

    public Generico() {
        this.driver = DriverContextWeb.getDriverWeb();
        PageFactory.initElements(this.driver, this);
    }

    public void validarPantalla(WebElement elemento, String paso, String descripcion, boolean fatal) {
        try {
            boolean cargoPantalla = false;
            int cont = 0;

            do {
                if (ControlledActionsWeb.visualizarObjeto(elemento, 1)) {
                    cargoPantalla = true;

                    reportePasoObjetoDesplegado(true, paso, descripcion,false);
                } else {
                    cont++;
                }
            } while (!cargoPantalla && cont <= 30);
            if (!cargoPantalla || cont >= 30) {
                reportePasoObjetoDesplegado(false,  paso, descripcion, true);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void reportePasoObjetoDesplegado(boolean estadoObjeto, String paso, String descripcion, boolean fatal) {
        try {
        if (estadoObjeto) {
            PdfBciReports.addReport(paso, descripcion, EstadoPrueba.PASSED, false);
        } else {
            PdfBciReports.addReport(paso, descripcion, EstadoPrueba.FAILED, fatal);
        }
    } catch (Exception e) {
        LOGGER.severe(EXCEPCION + e);
        reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
    }
    }

    public static void elementoVisible(WebElement elem,String nombrePaso) {
        try {
        if (ControlledActionsWeb.visualizarObjeto(elem,5)) {
            PdfBciReports.addReport(nombrePaso,"Se visualiza " + elem.getText(),EstadoPrueba.PASSED,false);
        }
        else {
            PdfBciReports.addReport(nombrePaso,"No se visualiza elemento",EstadoPrueba.FAILED,false);
        }
    } catch (Exception e) {
        LOGGER.severe(EXCEPCION + e);
        reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
    }
    }

    public static void elementoContieneTexto(WebElement elem,String nombrePaso,String contieneTexto) {
        try {
        if (elem.getText().contains(contieneTexto)) {
            PdfBciReports.addReport(nombrePaso,"Se visualiza el texto " + elem.getText(),EstadoPrueba.PASSED,false);
        }
        else {
            PdfBciReports.addReport(nombrePaso,"No contiene el texto " + contieneTexto,EstadoPrueba.FAILED,false);
        }
    } catch (Exception e) {
        LOGGER.severe(EXCEPCION + e);
        reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
    }
    }


    public static void Highlight(WebElement element) {
        try {
            JavascriptExecutor jse = (JavascriptExecutor) DriverContextWeb.getDriverWeb();
            jse.executeScript("arguments[0].style.border='2px solid red'", element);
            jse.executeScript("arguments[0].style.border='none'", element);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION, EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }



    public void scrollDown(WebElement element) {
        try {
            js.executeScript("arguments[0].scrollIntoView();", element);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION, EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void scrollEnd() {
        try {
            js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION, EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void scrollBtm() throws InterruptedException {
        try {
            //JavascriptExecutor js = ((JavascriptExecutor) driver);
            JavascriptExecutor js;
            js = (JavascriptExecutor) DriverContextWeb.getDriverWeb();
            js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
            esperar(5);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION, EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaSpan(String campo) {
        try {
            LOGGER.info("valida " + campo);
            WebElement txtTodasLasEmpresas = DriverContextWeb.getDriverWeb().findElement(By.xpath("//span[text()='" + campo + "']"));
            GenericValidations.validarElemento(txtTodasLasEmpresas, 120, true, "valida " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validaTitulo(String campo) {
        try {
            LOGGER.info("valida " + campo);
            WebElement txtObtenInformacionPagos = DriverContextWeb.getDriverWeb().findElement(By.xpath("//h2[text()='" + campo + "']"));
            GenericValidations.validarElemento(txtObtenInformacionPagos, 120, true, "valida " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validaAriaLabel(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            WebElement txPlaceholder = DriverContextWeb.getDriverWeb().findElement(By.xpath("//mat-select[@aria-label='" + campo + "']"));
            GenericValidations.validarElemento(txPlaceholder, 6, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaPlaceHolder(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            WebElement txPlaceholder = DriverContextWeb.getDriverWeb().findElement(By.xpath("(//input[@placeholder='" + campo + "'])[last()]"));
            GenericValidations.validarElemento(txPlaceholder, 320, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void presionaBoton(String campo) {
        try {
            LOGGER.info("presiona " + campo);
            WebElement presionaBtn = DriverContextWeb.getDriverWeb().findElement(By.xpath("//button[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(presionaBtn, 120, true, "valida " + campo);
            clickAlElementoConJavascript(presionaBtn);
            MetodosGenericos.esperar(10);
            spinner();
            reporteConYSinImagen(true, "presiona " + campo, "presiona " + campo,
                    EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionaBotonSpan(String campo) {
        try {
            LOGGER.info("presiona " + campo);
            WebElement presionaBtn = DriverContextWeb.getDriverWeb().findElement(By.xpath("//span[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(presionaBtn, 120, true, "valida " + campo);
            presionaBtn.click();
            LogErrorInChrome.GetJSErrorLog("clic " + campo);
            MetodosGenericos.esperar(3);
            spinner();
            reporteConYSinImagen(true, "presiona " + campo, "presiona " + campo,
                    EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaXpathP(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("//p[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoSpan(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("//span[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
            validaCampo.click();
            spinner();
            MetodosGenericos.esperar(3);
            LogErrorInChrome.GetJSErrorLog("selecciona " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaXpathMatHeaderCell(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(2);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("//mat-header-cell[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaDiv(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("(//div[contains(text(),'" + campo + "')])[1]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaH2(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("//h2[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionaButtonGenerico(String campo) {
        try {
            LOGGER.info("presiona " + campo);
            WebElement presionaBtn = DriverContextWeb.getDriverWeb().findElement(By.xpath("//*[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(presionaBtn, 120, true, "valida " + campo);
            clickAlElementoConJavascript(presionaBtn);
            MetodosGenericos.esperar(3);
            spinner();
            reporteConYSinImagen(true, "presiona " + campo, "presiona " + campo,
                    EstadoPrueba.PASSED, false);
            MetodosGenericos.esperar(3);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validaDivUltimo(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("(//div[contains(text(),'" + campo + "')])[last()]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaH3(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("//h3[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validaH3Segundo(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("//h3[contains(text()[2],'" + campo + "')]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaButtonGenerico(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("//*[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaGenerico(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("//*[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaButton(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("//button[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaH1(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("//h1[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionaH2(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            MetodosGenericos.esperar(3);
            WebElement presionaBtn = DriverContextWeb.getDriverWeb().findElement(By.xpath("//h2[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(presionaBtn, 120, true, "valida campo " + campo);
            clickAlElementoConJavascript(presionaBtn);
            MetodosGenericos.esperar(3);
            spinner();
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionaPagosMasivos(String campo) {
        try {
            LOGGER.info("valida campo " + campo);
            spinner();
            MetodosGenericos.esperar(7);
            spinner();
            WebElement validaCampo = DriverContextWeb.getDriverWeb().findElement(By.xpath("(//h2[contains(text(),'" + campo + "')]/following::span[contains(@class,'mat-expansion-indicator')])[1]"));
            GenericValidations.validarElemento(validaCampo, 120, true, "valida campo " + campo);
            validaCampo.click();
            LogErrorInChrome.GetJSErrorLog("se selecciona " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validaTituloGenerico(String campo) {
        try {
            LOGGER.info("valida " + campo);
            WebElement txtObtenInformacionPagos = DriverContextWeb.getDriverWeb().findElement(By.xpath("//*[contains(text(),'" + campo + "')]"));
            GenericValidations.validarElemento(txtObtenInformacionPagos, 120, true, "valida " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validaH5(String campo) {
        try {
            LOGGER.info("valida " + campo);
            WebElement txtTitulo = DriverContextWeb.getDriverWeb().findElement(By.xpath("//h5[text()='" + campo + "']"));
            GenericValidations.validarElemento(txtTitulo, 120, true, "valida " + campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoTecla(String tecla) {
        try {
            LOGGER.info("presiono tecla " + tecla);
            switch (tecla) {
                case "ENTER":
                    oprimirTecla(Keys.ENTER);
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + tecla);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void cierroElToast() {
        try {
            WebElement close = existeElemento("//i[normalize-space()='close']",10);
            clickAlElementoConJavascript(close);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void volver() {
        try {
            WebElement volver = existeElemento("//button[normalize-space()='Volver']",10);
            clickAlElementoConJavascript(volver);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElBotonVolver() {
        try {
            validaElemento("//button[normalize-space()='Volver']",10);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }
}
