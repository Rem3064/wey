package pages.cartolaYRescate;

import driverWeb.DriverContextWeb;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import util.Acciones;
import utils.web.UtilsWeb;

import java.util.logging.Logger;

import static constants.Constants.EXCEPCION;
import static utils.MetodosGenericos.esperar;
import static utils.web.ControlledActionsWeb.visualizarObjetoScroll;

public class CartolaYRescate extends Acciones {
    public static final Logger LOGGER = Logger.getLogger("Cartola");
    private static final String URL_ENROLAMIENTO_INVERSIONES = "/svcRest/infraestructura/seguridad/servlet/TokenAutorizacion?url=http://front-crt01.bci.cl/nuevaWeb/fe-inversionesenrolamientowebpersonas-re-v3-9";
    private static final String URL_CARTERAS_DESTACADAS_INVERSIONES = "/svcRest/infraestructura/seguridad/servlet/TokenAutorizacion?url=http://front-crt01.bci.cl/nuevaWeb/fe-inversionesfondosmutuoswebpersonas-re-v4-24/fondos-mutuos/destacados";
    //public static final String URL_VITRINA_INVERSIONES = "/svcRest/infraestructura/seguridad/servlet/TokenAutorizacion?url=http://front-crt01.bci.cl/nuevaWeb/fe-inversionesfondosmutuoswebpersonas-re-v4-21/fondos-mutuos/vitrina/";



    public CartolaYRescate() {
        PageFactory.initElements(DriverContextWeb.getDriverWeb(), this);
    }

    public void presionoEn(String arg0, String arg1) {
        try {
            WebElement rescatar = existeElemento("//strong[contains(text(),'" + arg1 + "')]//following::td[@class='align_center']//descendant::a[@title='" + arg0 + "']",2);
            visualizarObjetoScroll(rescatar,3);
            UtilsWeb.enmarcarObjeto(rescatar);
            PdfBciReports.addWebReportImage("Presiono " + arg0 + " desde  el fondo " + arg1, "Se presiona rescatar " + arg0 + " en el fondo " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(rescatar);
            rescatar.click();
            esperar(30);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }
    public void ingresoNuevoMontoAInvertirEnInvertirMas(String arg0) {
        try {
            WebElement inputmonto = existeElemento("//input[@name='formPaso1:montoInvertir']", 5);
            inputmonto.clear();
            inputmonto.sendKeys(arg0);
            PdfBciReports.addWebReportImage("ingreso los datos en invertir más", "Se ingresan los datos en invertir más", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoBotonEnInvertirMas(String arg0) {
        try {
            WebElement acepta = existeElemento("//div[@class='paso1_sin_mensaje']//button[@title='Aceptar'][normalize-space()='Aceptar']", 5);
            acepta.click();
            PdfBciReports.addWebReportImage("ingreso los datos en invertir más", "Se ingresan los datos en invertir más", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElCheckDeDeclararYLuegoElBotonDe(String arg0) {
        try {
            WebElement chec = existeElemento("//input[@id='formPaso2:aceptaReglamento']", 2);
            UtilsWeb.enmarcarObjeto(chec);
            PdfBciReports.addWebReportImage("Check declaro", "Se presiona el check de declaro " + chec.getText(), EstadoPrueba.PASSED, false);
            chec.click();
            UtilsWeb.desenmarcarObjeto(chec);
            WebElement acepta = existeElemento("//button[@title='Aceptar']", 5);
            PdfBciReports.addWebReportImage("Botón aceptar", "Se presiona el botón aceptar", EstadoPrueba.PASSED, false);
            acepta.click();
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonDeEnConfirmacionDeInversion(String arg0) {
        try {

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoPantallaDe(String arg0) {
        try {

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueNoExistaElBotonDeEnFondosUSD(String arg0) {
        try {
        noExiste("//*[contains (text(),'USD')]");
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void inspeccionoLaOpcionDeEn(String arg0,String arg1) {
        try {

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public String modificoLaURLYElCodigoCLPA(String arg0) {
        try {
            LOGGER.info("*** [INI] MODIFICA HTML ***");
            String elementbefore = "<a href=\"javascript:rescatarFFMM('3413','0');\" title=\"Rescatar\"></a>";
            Document doc = Jsoup.parseBodyFragment(elementbefore);
            Elements link = doc.body().getElementsByAttributeValue("href", "\"javascript:rescatarFFMM('3413','0');\"").before(doc.location());
            Elements after = link.attr("href", "javascript:rescatarFFMM('" + arg0 + "','0');");
            //getJavascriptExecutor().executeScript(String.format(JSScripts.MODIFICA_HTML, "iframeContenido",doc ));
            //driver.findElement(By.id("to")).sendKeys("bog@example.com");
            //link.replaceWith(link.attr("href", "javascript:rescatarFFMM('" + arg0 + "','0');"));
            //oprimirTecla(Keys.ENTER);
            PdfBciReports.addWebReportImage("Modifico el elemento con el codigo  " + arg0 + " desde  el html ", "Modifico el elemento por el codigo " + arg0 + " desde el html ", EstadoPrueba.PASSED, false);
            esperar(20);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
        return arg0;
    }

    public void visualizoMensajeDeError() {
        try {

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoMensaje(String arg0) {
        try {
            esperar(20);
            WebElement titulo = existeElemento("//h2[@class='inversion_titulo']",3);
            visualizarObjetoScroll(titulo,3);
            WebElement mensaje = existeElemento("//h2[normalize-space()='¿Estás seguro de que quieres rescatar tu dinero?']",3);
            WebElement advertencia = existeElemento("//p[contains(text(),'Estimado Cliente, en estos momentos no es posible ')]",3);
        PdfBciReports.addWebReportImage("Visualizo mensaje  " + arg0 , "Se visualiza el mensaje : " + mensaje.getText() + " \n " + advertencia.getText() , EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonEnModalRescatarEnElFondoMutuo(String arg0) {
        try {
            esperar(10);
            WebElement aceptar = existeElemento("//button[@title='Aceptar'])",3);
            aceptar.click();
            PdfBciReports.addWebReportImage("boton rescatar " , "Se presiona el botón Aceptar dentrod del modal ", EstadoPrueba.PASSED,false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueNoExistenBotonesDe(String arg0) {
        try {
            noExiste("//button[@title='Rescatar']");
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }
}
