package pages.loginWeb;

import driverWeb.DriverContextWeb;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.web.ControlledActionsWeb;

import java.util.logging.Logger;


public class LoginWeb {
    public static final Logger LOGGER = Logger.getLogger("LoginWeb");
    @FindBy(id = "bancoenlinea")
    private WebElement bancoEnLinea;
    @FindBy(className = "fancybox-iframe")
    private WebElement iframe;
    @FindBy(id = "rut_aux")
    private WebElement rut;
    @FindBy(id = "clave")
    private WebElement password;
    @FindBy(xpath = "//input[@value=\"Ingresar\"]")
    private  WebElement enviar;


    public LoginWeb() {
        PageFactory.initElements(DriverContextWeb.getDriverWeb(), this);


    }

    public void ClickBanca() {
        try {
            //WebElement bancoEnLinea = driver.findElement(By.id("bancoenlinea"));
            bancoEnLinea.click();
        } catch (NoSuchElementException e) {
            LOGGER.info(e.getMessage());

        }
    }

    public void ChangeFrame() {
        //  WebElement iframe = driver.findElement(By.className("fancybox-iframe"));
        DriverContextWeb.getDriverWeb().switchTo().frame(iframe);
    }

    public void SetRut(String rutCliente) {
        //  WebElement rut = driver.findElement(By.id("rut_aux"));
        rut.sendKeys(rutCliente);
    }


    public void SetPassword(String passCliente) {
        //   WebElement password = driver.findElement(By.id("clave"));
        password.sendKeys(passCliente);
    }

    public void SendRequest() {
        //  WebElement enviar = driver.findElement(By.className("submit"));
        if (ControlledActionsWeb.visualizarObjeto(enviar,30)) {
        enviar.submit();
        } else
            {
                LOGGER.info("Elemento no visible");

            }

    }

    public void FillText(String rutCliente, String passwordCliente) {

        try {

            this.SetRut(rutCliente);
            this.SetPassword(passwordCliente);
            this.SendRequest();
        } catch (NoSuchElementException e) {
            LOGGER.info("Error al realizar login: " + e.getMessage());
        }


    }
}
