package pages.rescate;

import driverWeb.DriverContextWeb;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import util.Acciones;
import utils.web.UtilsWeb;

import java.util.logging.Logger;

import static constants.Constants.EXCEPCION;
import static utils.MetodosGenericos.esperar;
import static utils.web.ControlledActionsWeb.visualizarObjeto;
import static utils.web.ControlledActionsWeb.visualizarObjetoScroll;

public class Rescate extends Acciones {
    public static final Logger LOGGER = Logger.getLogger("Rescate");
    public Rescate() {
        PageFactory.initElements(DriverContextWeb.getDriverWeb(), this);
    }

    @FindBy(xpath ="//button[contains(text(),'Rescatar')]")
    protected WebElement btnRescatar;
    @FindBy(xpath = "(//input[@type='text'])[1]")
    protected WebElement inputMontoRescatar;
    @FindBy(xpath = "//button[@ng-keypress='handleXPressed($event)']")
    protected WebElement cerrarEncuestaMedallia;
    @FindBy(xpath = "//*[@id=\"kampyleForm12488\"]")
    protected WebElement iframeMedallia;
    @FindBy(xpath = "//input[@value='5']")
    protected WebElement cincoestrellas;
    @FindBy(xpath = "//button[@ng-click='submit()']")
    protected WebElement enviarEncuesta;
    @FindBy(xpath = "(//i[@class='fa fa-times font-size-20'])[1]")
    protected WebElement closeEncuestaMedallia;
    @FindBy(xpath = "//label[contains (text(),'¿Qué tan satisfactoria fue la experiencia que viviste hoy en inversión en')]")
    protected WebElement preguntaInicialMedallia;


    public void visualizoQueNoExisteNingunBotonParaRescatarFondosMutuosEnUSD() {
        try {
            esperar(5);
            validaElementoNoExiste(btnRescatar,"boton Rescatar", 3,true);
            PdfBciReports.addWebReportImage("Valida botón no existe ", "Se visualiza que no existe boton rescatar ", EstadoPrueba.PASSED, false);
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoEnEl(String arg0, String arg1) {
        try {
            esperar(5);
            WebElement invertir = existeElemento("//bci-accordion-title[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            WebElement titulo = existeElemento("//h1[contains (text(),'" + arg1 + "')]",2);
            visualizarObjetoScroll(titulo,2);
            UtilsWeb.enmarcarObjeto(titulo);
            PdfBciReports.addWebReportImage("Acordión de Mis fondos Mutuos", "Se selecciona accordion  de " + arg0 + " en el  " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(invertir);
            UtilsWeb.desenmarcarObjeto(titulo);
            invertir.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElFondo(String arg0) {
        try {
            esperar(3);
            WebElement invertir = existeElemento("(//div[contains (text(),'" + arg0 + "')])[1]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Selección fondo de Mis fondos Mutuos", "Se selecciona el fondo de " + arg0 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(invertir);
            invertir.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoRescatarEnElFondo(String arg0, String arg1) {
        try {
            esperar(2);
            WebElement invertir = existeElemento("//div[contains(text(),'" + arg1 + "')]//ancestor::div[@class='card-details-holder FFMM open']//descendant::button[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Selección boton rescatar en fondo de Mis fondos Mutuos", "Se selecciona el boton  " + arg0 + "  en el fondo de " + arg1 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(invertir);
            invertir.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void respondoLaOpcion(String arg0, String arg1) {
        try {
            esperar(6);
            WebElement titulo = existeElemento("(//p[contains (text(),'" + arg0 + "')])[1]", 2);
            WebElement opcion = existeElemento("(//label[contains (text(),'" + arg1 + "')])[1]", 2);
            visualizarObjetoScroll(titulo, 2);
            UtilsWeb.enmarcarObjeto(titulo);
            UtilsWeb.enmarcarObjeto(opcion);
            PdfBciReports.addWebReportImage("Selección boton rescatar en fondo de Mis fondos Mutuos", "Se selecciona el boton rescatar en el fondo de " + arg0 + " la opcion : \n" + arg1 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(titulo);
            opcion.click();
            UtilsWeb.desenmarcarObjeto(opcion);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoCheckboxDeDeclararHaberLeidoYAceptadoElReglamento() {
        try {
            esperar(4);
            WebElement elemento = existeElemento("//label[@for='bci-wk-checkbox0']", 3);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Check de Acepto el reglamento ", "Se presiona el check de Acepto con el siguiente discleimer : \n " + elemento.getText(), EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            elemento.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoBotonEnPantallaDe(String arg0, String arg1) {
        try {
            esperar(2);
            WebElement rescatar = existeElemento("//button[contains(text(),'" + arg0 + "')]", 5);
            visualizarObjetoScroll(rescatar, 2);
            PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + " en la pantalla de " + arg1 , EstadoPrueba.PASSED, false);
            clickElemento(rescatar, "click a rescatar", "Se da click al boton rescatar");
            esperar(10);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElComprobanteDeRescate(String arg0) {
        try {
            esperar(15);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeMedallia);
            WebElement marco = existeElemento("//div[@class='modal-live-form ng-scope']",3);
            UtilsWeb.enmarcarObjeto(marco);
            scrollAlElementoConJavascript(closeEncuestaMedallia);
            PdfBciReports.addWebReportImage("Encuesta Medallia", "Se visualiza la encuesta Medallia", EstadoPrueba.PASSED, false);
            visualizarObjeto(enviarEncuesta, 3);
            visualizarObjeto(cincoestrellas,3);
            visualizarObjeto(cerrarEncuestaMedallia, 3);
            visualizarObjeto(preguntaInicialMedallia,3);
            esperar(1);
            UtilsWeb.desenmarcarObjeto(marco);
            PdfBciReports.addWebReportImage("Cierre encuesta Medallia", "Se cierra la encuesta Medallia", EstadoPrueba.PASSED, false);
            esperar(1);
            cerrarEncuestaMedallia.click();
            esperar(1);
            DriverContextWeb.getDriverWeb().switchTo().parentFrame();
            WebElement elemento = existeElemento("//p[@class='confirmation-header_title bci-wk-h1000']", 3);
            visualizarObjetoScroll(elemento, 2);
            validaElemento(elemento, "Comprobante de rescate", 2, false);
            PdfBciReports.addWebReportImage("Comprobante rescate","Se visualiza el comprobante de rescate  con el siguiente formato \n "  + arg0 , EstadoPrueba.PASSED,false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoBotonDeEnElComprobanteDeRescate(String arg0) {
        try {
            esperar(5);
            WebElement btn = existeElemento("//button[contains(text(),'" + arg0 + "')]", 5);
            visualizarObjetoScroll(btn, 2);
            UtilsWeb.enmarcarObjeto(btn);
            PdfBciReports.addWebReportImage("Valida botón  ", "Se visualiza que existe boton  " + arg0 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(btn);
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoMontoARescatarAndValidoElRescate(String arg0, String arg1) {
        try {
            esperar(15);
            inputMontoRescatar.clear();
            inputMontoRescatar.sendKeys(arg0);
            WebElement cuadroinput = existeElemento("//label[normalize-space()='Indica el monto a rescatar']", 2);
            validaElemento(cuadroinput, "cuadro de input con la frase : Indica el monto a rescatar", 2, false);
            WebElement selec = existeElemento("//label[normalize-space()='" + arg1 + "']",2);
            UtilsWeb.enmarcarObjeto(selec);
            PdfBciReports.addWebReportImage("Pantalla datos de tu rescate", "Se ingresa el monto en la pantalla datos de tu rescate", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(selec);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }

    }

    public void presionoEllabelDelRescateEnLaPantalla(String arg0) {
        try {
            esperar(15);
            WebElement cuadroinput = existeElemento("//label[normalize-space()='Indica el monto a rescatar']", 2);
            validaElemento(cuadroinput, "cuadro de input con la frase : Indica el monto a rescatar", 2, false);
            WebElement selec = existeElemento("//label[normalize-space()='" + arg0 + "']",2);
            UtilsWeb.enmarcarObjeto(selec);
            selec.click();
            PdfBciReports.addWebReportImage("Pantalla datos de tu rescate", "Se selecciona el rescate total en la pantalla datos de tu rescate", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(selec);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }

    }

    public void validoPantallaPrincipalDe(String arg0) {
        try {
            esperar(4);
            validaElemento("(//h3[contains (text(),'Resumen de tus inversiones')])[1]",2);
            validaElemento("(//div[contains (text(),'Así van tus inversiones')])[1]",2);
            validaElemento("(//*[contains (text(),'¿Qué quieres ver hoy?')])[1]",2);
            validaElemento("(//*[contains (text(),'Ir al detalle de mis inversiones ')])[1]",2);
            validaElemento("(//*[contains (text(),'Detalle de mis inversiones')])[1]",2);
            PdfBciReports.addWebReportImage("Pantalla Resumen inversiones", "Se valida que se vuelva a la pantalla de  " + arg0 , EstadoPrueba.PASSED, false);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoModalFueraDeHorario(String arg0) {
        try {
            esperar(5);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoBotonDentroDelModalDeClienteSinCuentaParaRescatar(String arg0) {
        try {
            esperar(5);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Botón " + arg0 , "Se visualiza el botón " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoModalClienteSinCuentaPeroConInversionesFFMMRealizadaEnUSD(String arg0) {
        try {
            esperar(5);
            WebElement elemento = existeElemento("//*[contains (text(),'Acude a una sucursal para hacer el rescate')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElTextboxSeEncuentreDeshabilitadoYQueElMontoSeaIgualAlMontoTotalDisponibleDeRescate() {
        try {
            esperar(5);
            WebElement elemento = existeElemento("(//input[@type='text'])[1][@disabled]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            WebElement textmonto = existeElemento( "//*[bci-wk-input-money]",2);
            PdfBciReports.addWebReportImage("Textbox para rescate total", "Se visualiza el textbox deshabilitado a cliente y el monto total es de " + textmonto.getText(), EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElCampoIndiqueElValorDeEnPantallaDeConfirmacion(String arg0,String arg1) {
        try {
            esperar(5);
            WebElement elemento = existeElemento("//p[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            WebElement textmonto = existeElemento( "//span[contains(text(),'" + arg1 + "')]",2);
            PdfBciReports.addWebReportImage("Valida Campo", "Se visualiza el texto de : " + textmonto.getText() + " en la pantalla de confirmación", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElCampoIndique(String arg0, String arg1) {
        try {
            esperar(5);
            WebElement elemento = existeElemento("//p[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            WebElement textmonto = existeElemento( "//span[contains(text(),'" + arg1 + "')]",2);
            PdfBciReports.addWebReportImage("Valida Campo", "Se visualiza el texto de : " + textmonto.getText() + " en el comprobante de rescate ", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueNoExistaElBotonDe(String arg0) {
        try {
            esperar(5);
            validaElementoNoExiste(btnRescatar,"boton Rescatar", 3,true);
            PdfBciReports.addWebReportImage("Valida botón no existe ", "Se visualiza que no existe boton de  " + arg0, EstadoPrueba.PASSED, false);
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoAdjuntoEnLaPantallaDeConfirmacion(String arg0) {
        try {
            esperar(5);
            WebElement elemento = existeElemento("//*[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Valida CGF", "Se visualiza el contrato general de fondos ", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoLaCartera(String arg0) {
        try {
            esperar(2);
            WebElement invertir = existeElemento("(//div[contains (text(),'" + arg0 + "')])[1]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Selección cartera ", "Se selecciona la cartera de " + arg0 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(invertir);
            invertir.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueExistaElBotonDe(String arg0) {
        try {
            esperar(3);
            validaExist(btnRescatar);
            PdfBciReports.addWebReportImage("Valida botón existe ", "Se visualiza que existe boton  " + arg0, EstadoPrueba.PASSED, false);
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElBotonDe(String arg0) {
        try {
            esperar(2);
            WebElement btn = existeElemento("(//button[contains(text(),'" + arg0 + "')])[1]", 2);
            visualizarObjetoScroll(btn, 2);
            UtilsWeb.enmarcarObjeto(btn);
            PdfBciReports.addWebReportImage("Valida botón  ", "Se valida botón  de " + arg0 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(btn);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoBotonDeshabilitadoEnPantalla(String arg0) {
        try {
            esperar(10);
            WebElement elemento = existeElemento("(//button[contains(text(),'" + arg0 + "')])[1][@disabled]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Botón deshabilitado", "Se visualiza el botón  " +  arg0 +  " Deshabilitado en pantalla ", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void vacioCampo() {
        try {
            esperar(2);
            inputMontoRescatar.clear();
            PdfBciReports.addWebReportImage("Vacio el input", "Se vacia el input", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoNuevamenteElEnLaPantallaDeConfirmacion(String arg0) {
            try {
                esperar(5);
                WebElement inputCorreo = existeElemento("//input[@formcontrolname='email']", 3);
                validaElemento(inputCorreo, "input de correo", 3, false);
                inputCorreo.clear();
                inputCorreo.sendKeys(arg0);
                PdfBciReports.addReport("ingreso correo", "Se ingresa el correo " + arg0 + " en la pantalla de confirmacion", EstadoPrueba.PASSED, false);
            } catch (Exception e) {
                LOGGER.severe(EXCEPCION + e);
                reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
            }
        }

    public void suprimoElTextoIngresadoEnElCampo(String arg0) {
        try {
            esperar(5);
            WebElement inputCorreo = existeElemento("//input[@formcontrolname='email']", 3);
            validaElemento(inputCorreo, "input de correo", 3, false);
            inputCorreo.clear();
            PdfBciReports.addReport("borra correo", "Se borra el " + arg0 + " en la pantalla de confirmacion", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoMontoARescatarEnPantallaDeIngresaLosDatosDelRescate(String arg0) {
        try {
            esperar(15);
            inputMontoRescatar.clear();
            inputMontoRescatar.sendKeys(arg0);
            WebElement cuadroinput = existeElemento("//label[normalize-space()='Indica el monto a rescatar']", 2);
            validaElemento(cuadroinput, "cuadro de input con la frase : Indica el monto a rescatar", 2, false);
            UtilsWeb.enmarcarObjeto(cuadroinput);
            PdfBciReports.addWebReportImage("Pantalla datos de tu rescate", "Se ingresa el monto en la pantalla datos de tu rescate", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(cuadroinput);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validoQueElBotonEnPantallaDeSeEncuentreDeshabilitado(String arg0, String arg1) {
        try {
            esperar(10);
            WebElement elemento = existeElemento("(//button[contains(text(),'" + arg0 + "')])[1][@disabled]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Botón deshabilitado", "Se visualiza el botón  " +  arg0 +  " Deshabilitado en pantalla " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }
}

