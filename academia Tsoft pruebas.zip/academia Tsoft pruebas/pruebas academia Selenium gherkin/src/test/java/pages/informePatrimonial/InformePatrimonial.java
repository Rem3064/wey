package pages.informePatrimonial;

import org.openqa.selenium.WebElement;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import util.Acciones;
import utils.web.UtilsWeb;

import java.util.logging.Logger;

import static constants.Constants.EXCEPCION;
import static utils.MetodosGenericos.esperar;
import static utils.web.ControlledActionsWeb.visualizarObjetoScroll;

public class InformePatrimonial extends Acciones {
    public static final Logger LOGGER = Logger.getLogger("InformePatrimonial");


    public void visualizoCardDeInforme(String arg0) {
        try {
            esperar(3);
            WebElement card = existeElemento("//span[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(card, 2);
            UtilsWeb.enmarcarObjeto(card);
            PdfBciReports.addWebReportImage("Card de informe patrimonial", "Se despliega card de  " + arg0 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(card);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }



    public void visualizoLaPagina(String arg0) {
        try {
            WebElement card = existeElemento("//h1[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(card, 2);
            UtilsWeb.enmarcarObjeto(card);
            PdfBciReports.addWebReportImage("Página de informe patrimonial", "Se despliega página de  " + arg0 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(card);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElTextoDeLaSolicitudUnaVezRealizada(String arg0) {
        try {
            esperar(2);
            WebElement texto = existeElemento("//p[contains (text(),'Una vez realizada la solicitud,')]", 2);
            UtilsWeb.enmarcarObjeto(texto);
            UtilsWeb.desenmarcarObjeto(texto);
            WebElement tuinforme = existeElemento("//span[contains (text(),'te enviaremos tu Informe Patrimonial a tu correo electrónico')]", 2);
            UtilsWeb.enmarcarObjeto(tuinforme);
            UtilsWeb.desenmarcarObjeto(tuinforme);
            PdfBciReports.addWebReportImage("Texto solicitud de informe patrimonial", "Se despliega texto  de  " + arg0 , EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }

    }

    public void validoQueElCampoContegaInformacion(String arg0) {
        try {
            esperar(3);
            WebElement card = existeElemento("//label[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(card, 2);
            UtilsWeb.enmarcarObjeto(card);
            WebElement input = existeElemento("//input[@placeholder='Ingresa un correo electrónico']", 2);
            PdfBciReports.addWebReportImage("Input de correo de informe patrimonial", "Se despliega input de  " + arg0 + "  con el siguiente  correo  " + input , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(card);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoModalDe(String arg0, String arg1) {
        try {
            esperar(2);
            WebElement card = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(card, 2);
            UtilsWeb.enmarcarObjeto(card);
            PdfBciReports.addWebReportImage("Modal de informe patrimonial", "Se despliega modal de  " + arg0 + "   " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(card);
            WebElement cardd = existeElemento("//*[contains (text(),'" + arg1 + "')]", 2);
            UtilsWeb.enmarcarObjeto(cardd);
            UtilsWeb.desenmarcarObjeto(cardd);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonDeDelModal(String arg0) {
        try {
            esperar(2);
            WebElement card = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(card, 2);
            UtilsWeb.enmarcarObjeto(card);
            PdfBciReports.addWebReportImage("Botón Solicitar Informe Patrimonial", "Se despliega botón de  " + arg0 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(card);
            card.click();
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
        
    }

    public void validoQueNoSeVisualiceLaCardDeInforme(String arg0) {
        try {
            esperar(8);
            noExiste("//span[contains (text(),'" + arg0 + "')]");
            PdfBciReports.addWebReportImage("Card de informe patrimonial", "Se valida que no se despliega card de  " + arg0 , EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElCampoNoContegaInformacion(String arg0) {
        try {
            esperar(2);
            WebElement card = existeElemento("//label[contains (text(),'" + arg0 + "')]", 2);
            UtilsWeb.enmarcarObjeto(card);
            WebElement input = existeElemento("//input[@placeholder='Ingresa un correo electrónico']", 2);
            PdfBciReports.addWebReportImage("Input de informe patrimonial", "Se valida que el input no contiene  información  de  " + arg0 + "  con el siguiente  correo  " + input , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(card);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElBotonDeSeEncuentreDeshabilitado(String arg0) {
        try {
            esperar(2);
            WebElement card = existeElemento("//button[contains (text(),'" + arg0 + "')][@disabled]", 2);
            UtilsWeb.enmarcarObjeto(card);
            PdfBciReports.addWebReportImage("Botón Solicitar Informe Patrimonial", "Se valida botón inhabilitado de  " + arg0 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(card);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoMailEnFormatoIncorrecto(String arg0) {
        try {
            esperar(3);
            WebElement input = existeElemento("//input[@placeholder='Ingresa un correo electrónico']", 2);
            input.clear();
            input.sendKeys(arg0);
            UtilsWeb.enmarcarObjeto(input);
            PdfBciReports.addWebReportImage("Input de informe patrimonial", "Se ingresa un correo incorrecto  " + arg0  , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(input);

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElTextoDeAdvertenciaMailIncorrecto(String arg0) {
        try {
            esperar(2);
            WebElement texto = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            UtilsWeb.enmarcarObjeto(texto);
            PdfBciReports.addWebReportImage("Input de informe patrimonial", "Se alerta de  un correo incorrecto  " + arg0  , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(texto);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void eliminoElTextoDelTextboxDeMail() {
        try {
            esperar(2);
            WebElement input = existeElemento("//input[@placeholder='Ingresa un correo electrónico']", 2);
            input.clear();
            PdfBciReports.addWebReportImage("Texto alerta de input correo de informe patrimonial", "Se  elimina el texto ingresado  "  , EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElTextoDeAdvertenciaMailVacio(String arg0) {
        try {
            esperar(2);
            WebElement texto = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            UtilsWeb.enmarcarObjeto(texto);
            PdfBciReports.addWebReportImage("Input de informe patrimonial", "Se alerta de input vacio   " + arg0  , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(texto);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }
}
