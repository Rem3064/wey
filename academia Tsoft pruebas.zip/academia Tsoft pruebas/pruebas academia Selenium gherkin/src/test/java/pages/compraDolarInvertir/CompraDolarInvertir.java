package pages.compraDolarInvertir;

import org.openqa.selenium.WebElement;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import util.Acciones;
import utils.web.UtilsWeb;

import java.util.logging.Logger;

import static constants.Constants.*;
import static utils.MetodosGenericos.esperar;
import static utils.web.ControlledActionsWeb.visualizarObjetoScroll;

public class CompraDolarInvertir extends Acciones {
    public static final Logger LOGGER = Logger.getLogger("CompraDolarInvertir");

    public void visualizoDeFormaCorrectaEl(String arg0, String arg1) {
        try {
            esperar(12);
            if (existe("//*[normalize-space()='Bci Corredora de Bolsa']")) {
                WebElement elemento = existeElemento("//*[contains (text(),'Bci Corredora de Bolsa')]", 2);
                visualizarObjetoScroll(elemento, 2);
                UtilsWeb.enmarcarObjeto(elemento);
                PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal Bci Corredora de Bolsa a cliente  " + arg0 + "  " + arg1 , EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(elemento);
                WebElement verproductos = existeElemento("//button[contains(text(),'Quiero ver los productos')]", 2);
                clickElemento(verproductos, "click a " + verproductos , "Se da click al botón " + verproductos);
                esperar(2);
                WebElement element = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
                visualizarObjetoScroll(element, 2);
                UtilsWeb.enmarcarObjeto(element);
                PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + "  \n  " + arg1 + " a cliente", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(element);
                esperar(2);
            } else {
                esperar(2);
                WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
                visualizarObjetoScroll(elemento, 2);
                UtilsWeb.enmarcarObjeto(elemento);
                PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + "  \n  " + arg1 + " a cliente", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(elemento);
                esperar(2);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }
    public void visualizoMensajeDeAlertaAmarillo(String arg0) {
        try {
            esperar(10);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            WebElement elemento2 = existeElemento("//*[contains (text(),'Habilitarme ahora')]", 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage(ALERTA , ALERTA_A + arg0 + elemento2 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoModalFueraDeHorarioEnElFlujo(String arg0) {
        try {
            esperar(10);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage(ALERTA, ALERTA_A + arg0 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoModalBciCorredoraDeBolsa() {
        try {
            esperar(8);
            if (existe("//*[contains (text(),'Bci Corredora de Bolsa')]")) {
                WebElement elemento = existeElemento("//*[contains (text(),'Bci Corredora de Bolsa')]", 2);
                visualizarObjetoScroll(elemento, 2);
                UtilsWeb.enmarcarObjeto(elemento);
                PdfBciReports.addWebReportImage(MODAL, MODAL_A + " Bci Corredora de Bolsa a cliente", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(elemento);
                esperar(2);
            } else {
                PdfBciReports.addWebReportImage(MODAL, NO_MODAL_A + " Bci Corredora de Bolsa a cliente", EstadoPrueba.PASSED, false);

            }

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoModal(String arg0) {
        try {
            esperar(15);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal Bci Corredora de Bolsa a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElComboboxDeComoDeseoInvertir(String arg0) {

        try {
            esperar(10);
            WebElement elemento = existeElemento("//label[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Combobox", "Se selecciona el combobox de como desea realizar la inversión dólar ", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            elemento.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoCampoEnPantallaDatosDeTuInversion(String arg0) {

        try {
            esperar(1);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal Bci Corredora de Bolsa a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElCampo(String arg0) {
        try {
            esperar(1);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Campo", "Se visualiza el campo  Bci Corredora de Bolsa a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElCampoDe(String arg0) {
        try {
            esperar(1);
            WebElement elemento = existeElemento("//p[3]", 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Campo", "Se visualiza el campo  Bci Corredora de Bolsa a cliente  " + arg0 , EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoModalEnLaVitrina(String arg0) {
        try {
            esperar(6);
            if (existe("//*[contains (text(),'Bci Corredora de Bolsa')])")) {
                WebElement elemento = existeElemento("//*[contains (text(),'Bci Corredora de Bolsa')]", 2);
                visualizarObjetoScroll(elemento, 2);
                UtilsWeb.enmarcarObjeto(elemento);
                PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal Bci Corredora de Bolsa a cliente  " + arg0  , EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(elemento);
                WebElement verproductos = existeElemento("//button[contains(text(),'Quiero ver los productos')]", 2);
                clickElemento(verproductos, "click a " + verproductos , "Se da click al botón " + verproductos);
                esperar(2);
                WebElement element = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
                visualizarObjetoScroll(element, 2);
                UtilsWeb.enmarcarObjeto(element);
                PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(element);
                esperar(2);
            } else {
                esperar(2);
                WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
                visualizarObjetoScroll(elemento, 2);
                UtilsWeb.enmarcarObjeto(elemento);
                PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(elemento);
                esperar(2);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoBotonEnElModalDeBciCorredoraDeBolsa(String arg0) {
        try {
            if (existe("//button[contains(text(),'Quiero ver los productos')]")) {
                esperar(1);
                WebElement comparar = existeElemento("//button[contains(text(),'" + arg0 + "')]", 5);
                visualizarObjetoScroll(comparar, 2);
                PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_BOTON + arg0, EstadoPrueba.PASSED, false);
                clickAlElementoConJavascript(comparar);
                esperar(2);
            }
            PdfBciReports.addWebReportImage(CLICK + arg0 , NO_CLICK_A + arg0, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElModalDeFueraDeHorario(String arg0) {
        try {
            esperar(8);
            if (existe("//*[contains (text(),'" + arg0 + "')]")) {
                WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
                visualizarObjetoScroll(elemento, 2);
                UtilsWeb.enmarcarObjeto(elemento);
                PdfBciReports.addWebReportImage(MODAL, MODAL_A + " Fuera de horario Bci Corredora de Bolsa a cliente", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(elemento);
                esperar(2);
            } else {
                PdfBciReports.addWebReportImage(MODAL, NO_MODAL_A + " Fuera de horario Bci Corredora de Bolsa a cliente", EstadoPrueba.PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElComboboxDeInvertirCuentaCorrienteEnPesosEsteDeshabilitado() {
        try {
            esperar(10);
            WebElement elemento = existeElemento("//*[@id='bci-wk-radio1'][@disabled]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Combobox", "Se obserba deshabilitado el combobox de cuenta corriente en pesos ", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }
}
