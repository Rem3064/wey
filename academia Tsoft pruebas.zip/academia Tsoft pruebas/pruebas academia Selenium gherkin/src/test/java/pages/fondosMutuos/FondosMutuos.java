package pages.fondosMutuos;

import correoBci.CorreoBCI_Bandeja;
import correoBci.CorreoBCI_Login;
import driverWeb.DriverContextWeb;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import util.Acciones;
import util.WebUtils;
import utils.MetodosGenericos;
import utils.web.GenericValidations;
import utils.web.UtilsWeb;

import java.io.File;
import java.util.Arrays;
import java.util.Properties;
import java.util.logging.Logger;

import static constants.Constants.*;
import static utils.MetodosGenericos.esperar;
import static utils.web.ControlledActionsWeb.visualizarObjeto;
import static utils.web.ControlledActionsWeb.visualizarObjetoScroll;


public class FondosMutuos extends Acciones {
    public static final Logger LOGGER = Logger.getLogger("FondosMutuos");
    @FindBy(xpath = "//img[contains(@alt,\"Banco\")]")
    protected WebElement botonBancoEnLinea;
    @FindBy(id = "rut_aux")
    protected WebElement campoRut;
    @FindBy(id = "clave")
    protected WebElement campoClave;
    @FindBy(xpath = "//input[@value='Ingresar']")
    protected WebElement btnIngresar;
    @FindBy(className = "fancybox-iframe")
    protected WebElement iframe;
    @FindBy(xpath = "//*[@id=\"iframeContenido\"]")
    protected WebElement iframeContenido;
    @FindBy(xpath = "//a[@title='Inversiones']")
    protected WebElement linkInversiones;
    @FindBy(xpath = "//span[@id='asesoria_digital']")
    protected WebElement menuInvierte;
    @FindBy(xpath = "//span[@id='mis_inversiones']")
    protected WebElement misInversiones;
    @FindBy(xpath = "//a[@title='Resumen de inversiones']")
    protected WebElement resumenInversiones;
    @FindBy(xpath = "//a[@title='Cartola de saldos']")
    protected WebElement cartolaDeSaldos;
    @FindBy(xpath = "//a[@title='Portafolios Accionarios']")
    protected WebElement portafoliosAccionarios;
    @FindBy(xpath = "//span[@id='fondos_mutuos_core']//following::a[(@title='Rescatar')]")
    protected WebElement rescatar;
    @FindBy(xpath = "//span[@id='fondos_mutuos_core']")
    protected WebElement misFondosMutuos;
    @FindBy(xpath = "//span[@id='asesoramos_para_invertir']")
    protected WebElement menuteasesoramos;
    @FindBy(xpath = "(//a[@title='Carteras'])[1]")
    protected WebElement menuCarteras;
    @FindBy(xpath = "//span[@id='alternativas_inversion']")
    protected WebElement alternativInver;
    @FindBy(xpath = "(//a[@title='Fondos Mutuos'])[1]")
    protected WebElement menuFondosMutuos;
    @FindBy(xpath = "(//a[@title='Fondos Mutuos'])[2]")
    protected WebElement menuFondosMutuos2;
    @FindBy(xpath = "//span[@id='habilitarse_para_invertir']")
    protected WebElement habilitateParaInvertir;
    @FindBy(xpath = "//input[@type='password']")
    protected WebElement inputClaveMultipass;
    @FindBy(xpath = "//input[@value='Aceptar']")
    protected WebElement botonAceptarClaveMultipass;
    @FindBy(xpath = "//button[normalize-space()='Invertir']")
    protected WebElement btnInvertirVitrina;
    @FindBy(xpath = "//button[normalize-space()='INVERTIR']")
    protected WebElement botonInvertirAntiguo;
    @FindBy(xpath = "//div[@class='highlight-comparador-container']//div[1]//bci-card[1]//div[1]//div[4]//button[1]")
    protected WebElement botonInvertirComparado;
    @FindBy(xpath = "//label[@for='bci-wk-checkbox0']")
    protected WebElement check;
    @FindBy(xpath = "//span[@class='mat-checkbox-inner-container']")
    protected WebElement checkk;
    @FindBy(xpath = "//div[@class='mat-checkbox-inner-container']")
    protected WebElement checkkk;
    @FindBy(xpath = "//button[normalize-space()='CONTINUAR']")
    protected WebElement btnContinu;
    @FindBy(xpath = "//button[normalize-space()='Continuar']")
    protected WebElement btnContinuar;
    @FindBy(xpath = "(//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin'])[2]")
    protected WebElement checkBox_2;
    @FindBy(xpath = "(//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin'])[3]")
    protected WebElement checkBox_3;
    @FindBy(xpath = "(//input[@type='text'])[2]")
    protected WebElement inputMontoInvertir;
    @FindBy(xpath = "(//input[@type='text'])[1]")
    protected WebElement inputMontoInvertirCLP;
    @FindBy(xpath = " //bci-card[@class='container-modal grey-text']")
    protected WebElement txtModal;
    @FindBy(xpath = "//i[@class='material-icons'][contains(text(),'close')]")
    protected WebElement closePopUpRescate;
    @FindBy(xpath = "//p[@class='alert__text']")
    protected WebElement alertafuerahorario;
    @FindBy(xpath = "//button[@ng-keypress='handleXPressed($event)']")
    protected WebElement cerrarEncuestaMedallia;
    @FindBy(xpath = "//label[contains (text(),'¿Qué tan satisfactoria fue la experiencia que viviste hoy en inversión en')]")
    protected WebElement preguntaInicialMedallia;
    @FindBy(xpath = "//*[@id=\"kampyleForm12488\"]")
    protected WebElement iframeMedallia;
    @FindBy(xpath = "//input[@value='5']")
    protected WebElement cincoestrellas;
    @FindBy(xpath = "//button[@ng-click='submit()']")
    protected WebElement enviarEncuesta;
    @FindBy(xpath = "(//i[@class='fa fa-times font-size-20'])[1]")
    protected WebElement closeEncuestaMedallia;
    @FindBy(xpath = "//textarea[@id='Page 11']")
    protected WebElement textoEncuesta;
    @FindBy(xpath = "//input[@type='email']")
    protected WebElement inputCorre;
    @FindBy(xpath = "(//div//descendant::button)[@disabled][1]")
    protected WebElement INVcomparaUsddesa1;
    @FindBy(xpath = "(//div//descendant::button)[@disabled][2]")
    protected WebElement INVcomparaUsddesa2;
    @FindBy(xpath = "(//div//descendant::button)[@disabled][3]")
    protected WebElement INVcomparaUsddesa3;
    @FindBy(xpath = "(//span[contains (text(),'Ver m')])[1]")
    protected WebElement vermas1;
    @FindBy(xpath = "(//span[contains (text(),'Ver m')])[2]")
    protected WebElement vermas2;
    @FindBy(xpath = "(//button[contains (text(),'SABER MÁS')])[1]")
    protected WebElement sabermas1;
    @FindBy(xpath = "//p[contains(text(),'Solicitud enviada')]")
    protected WebElement exito;
    @FindBy(xpath = "//p[@class='data-completed spaced bci-wk-h200 ng-star-inserted']")
    protected WebElement yahascompletadotusdatos;
    @FindBy(xpath = "//div[@title='Cartera Dinámica Balanceada']")
    protected WebElement titleDinamica;
    @FindBy(xpath = "//div[@title='Preferencial Ahorro']")
    protected WebElement titlePatrimonial;
    @FindBy(xpath = "//span[normalize-space()='Dólar Cash']")
    protected WebElement dolarCash;
    @FindBy(xpath = "//span[normalize-space()='Retorno Dolar IG']")
    protected WebElement retornoDolarIG;
    @FindBy(xpath = "//span[normalize-space()='Retorno Dolar IG']")
    protected WebElement BciUsa;
    @FindBy(xpath = "//bci-wk-select[@class='width-element investment-element-charge default ng-untouched ng-pristine ng-valid']//select")
    protected WebElement variasCuentas;
    @FindBy(xpath = "(//input[@type='text'])[1]")
    protected WebElement unaCuenta;
    @FindBy(xpath = "//bci-accordion-title[contains(text(),'Mis Carteras Dinámicas y Patrimoniales')]")
    protected WebElement btnCarteraDesplegable;
    @FindBy(xpath = "//button[contains(text(),' Conocer después ')]")
    protected WebElement btnConocerDespues;
    @FindBy(xpath = "//div[contains(text(),'Cuenta 0')]")
    protected WebElement btnCtaCero;
    @FindBy(xpath = "//button[contains(text(),'Rescatar')]")
    protected WebElement btnRescatarResumen;
    @FindBy(xpath = "//button[contains(text(),'Traspasar')]")
    protected WebElement btnTraspasarResumen;
    @FindBy(xpath = "//button[contains(text(),'Invertir más')]")
    protected WebElement btnInvertirMas;
    @FindBy(xpath = "//bci-accordion-title[contains(text(),'Mis Fondos Mutuos')]")
    protected WebElement btnDesplegableFFMM;
    @FindBy(xpath = "//button[contains(text(),'Invertir en otros fondos')]")
    protected WebElement btnInvertirEnOtrosFondosCartera;
    CorreoBCI_Login loginCorreo = new CorreoBCI_Login();
    CorreoBCI_Bandeja bandejaCorreo = new CorreoBCI_Bandeja();
    public FondosMutuos() {
        PageFactory.initElements(DriverContextWeb.getDriverWeb(), this);
    }

    public void presionoElBotonEnLaWeb(String arg0) {
        try {
            switch (arg0) {
                case "Banco en Línea":
                    esperar(2);
                    GenericValidations.validarElemento(botonBancoEnLinea, 5, false, "botón banco en linea");
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                    botonBancoEnLinea.click();
                    break;
                case "Acepto":
                    esperar(2);
                    WebElement acepto = existeElemento("//button[contains (text(),'Acepto')]", 2);
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                    JavascriptExecutor ejecutador = (JavascriptExecutor) DriverContextWeb.getDriverWeb();
                    ejecutador.executeScript("arguments[0].click();", acepto);
                    esperar(2);
                    break;
                case "Aceptar":
                    botonAceptarClaveMultipass.click();
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                    break;
                case "No Acepto":
                    esperar(2);
                    WebElement noacepto = existeElemento("//button[contains (text(),'acepto')]", 3);
                    noacepto.click();
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                    break;
                case "CONTINUAR":
                case "Continuar":
                    esperar(3);
                    if (visualizarObjetoScroll(btnContinu, 2)) {
                        PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                        btnContinu.click();
                    } else {
                        visualizarObjetoScroll(btnContinuar, 2);
                        PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                        btnContinuar.click();
                    }
                    break;
                case "INVERTIR":
                    esperar(5);
                    if (visualizarObjetoScroll(botonInvertirAntiguo, 3)) {
                        PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_BOTON + arg0, EstadoPrueba.PASSED, false);
                        botonInvertirAntiguo.click();
                        esperar(2);
                    }
                    if (visualizarObjetoScroll(btnInvertirVitrina, 3)) {
                        PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_BOTON + arg0, EstadoPrueba.PASSED, false);
                        btnInvertirVitrina.click();
                        esperar(2);
                    }
                    if (visualizarObjetoScroll(botonInvertirComparado, 3)) {
                        PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_BOTON + arg0, EstadoPrueba.PASSED, false);
                        botonInvertirComparado.click();
                        esperar(2);
                    } else {
                        PdfBciReports.addWebReportImage(CLICK + arg0 , NO_CLICK_A + arg0, EstadoPrueba.PASSED, false);}
                    break;
                case "FINALIZAR":
                    esperar(5);
                    WebElement finalizar = existeElemento("//button[contains(text(),'FINALIZAR')]", 3);
                    finalizar.click();
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_BOTON + arg0, EstadoPrueba.PASSED, false);
                    break;
                case "COMPARAR":
                case "Comparar":
                case "Perfilarme":
                case "Habilitarme":
                case "Si, continuar":
                case "Entiendo":
                case "Solicitar":
                case "Quiero ver los productos":
                    esperar(1);
                    WebElement comparar = existeElemento("//button[contains(text(),'" + arg0 + "')]", 5);
                    visualizarObjetoScroll(comparar, 2);
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_BOTON + arg0, EstadoPrueba.PASSED, false);
                    clickAlElementoConJavascript(comparar);
                    esperar(2);
                    break;
                case "IR A INVERTIR":
                    esperar(3);
                    WebElement irainvertir = existeElemento("(//button[contains (text(),'IR A INVERTIR')])[1]", 3);
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_BOTON + arg0, EstadoPrueba.PASSED, false);
                    irainvertir.click();
                    break;
                case "FILTRAR POR":
                    esperar(3);
                    DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    WebElement filtro = existeElemento("//label[@for='filterControl']", 5);
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                    filtro.click();
                    break;
                case "GUARDAR Y CONTINUAR":
                    esperar(3);
                    WebElement btnGuardarContinuar = existeElemento("//button[contains (text(),'GUARDAR Y CONTINUAR')]", 3);
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_BOTON + arg0, EstadoPrueba.PASSED, false);
                    btnGuardarContinuar.click();
                    esperar(20);
                    break;
                case "Inversión en dólares":
                case "Inversión en pesos":
                case "Valor Cuota":
                case "Documentos":
                    esperar(3);
                    WebElement tab = existeElemento("//span[contains(text(),'" + arg0 + "')]", 3);
                    visualizarObjetoScroll(tab, 2);
                    UtilsWeb.enmarcarObjeto(tab);
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(tab);
                    tab.click();
                    break;
                case "Rescatar mi dinero":
                case "Entendido":
                case "Rescatar":
                case "Volver al inicio":
                    esperar(2);
                    WebElement rescatar = existeElemento("//button[normalize-space()='" + arg0 + "']", 2);
                    visualizarObjetoScroll(rescatar, 2);
                    UtilsWeb.enmarcarObjeto(rescatar);
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_BOTON + arg0, EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(rescatar);
                    rescatar.click();
                    esperar(2);
                    break;
                case "Carteras Dólar":
                    esperar(6);
                    WebElement carterasDolar = existeElemento("//span[normalize-space()='Carteras Dólar']", 2);
                    UtilsWeb.enmarcarObjeto(carterasDolar);
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(carterasDolar);
                    carterasDolar.click();
                    esperar(2);
                    break;
                case "Más sobre el Fondo Mutuo Retorno Dolar Ig":
                    esperar(3);
                    WebElement icono = existeElemento("//div[@class='arrow']", 2);
                    icono.click();
                    PdfBciReports.addWebReportImage("icono ver más del Fondo", "Se da click al icono flecha de ver más en el fondo ", EstadoPrueba.PASSED, false);
                    esperar(5);
                    break;
                case "Ir al resumen":
                    esperar(2);
                    WebElement direc = existeElemento("//a[normalize-space()='" + arg0 + "']", 2);
                    UtilsWeb.enmarcarObjeto(direc);
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(direc);
                    direc.click();
                    esperar(2);
                    break;
                case "Volver al Resumen de inversiones":
                    esperar(3);
                    WebElement tabvolver = existeElemento("//h6[contains(text(),'" + arg0 + "')]", 3);
                    visualizarObjetoScroll(tabvolver, 2);
                    UtilsWeb.enmarcarObjeto(tabvolver);
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(tabvolver);
                    tabvolver.click();
                    break;
                case "Solicitar Informe Patrimonial":
                    esperar(2);
                    WebElement direcc = existeElemento("//a[normalize-space()='" + arg0 + "']", 2);
                    UtilsWeb.enmarcarObjeto(direcc);
                    PdfBciReports.addWebReportImage(CLICK + arg0 , CLICK_A + arg0, EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(direcc);
                    //WebUtils.embeberUrlEnIframeContenido(URL_INFORME_PATRIMONIAL);
                    //DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    direcc.click();
                    esperar(20);
                    break;
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    @Step("Login")
    @Description("Ingresa los datos para realizar el login")
    public void login(String rutCliente, String clave) {
        try {
            esperar(4);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframe);
            Actions builder = new Actions(DriverContextWeb.getDriverWeb());
            Action seriesOfActions = builder.moveToElement(campoRut).click().sendKeys(campoRut, rutCliente).keyUp(campoRut, Keys.SHIFT).build();
            seriesOfActions.perform();
            campoClave.click();
            campoClave.sendKeys(clave);
            PdfBciReports.addWebReportImage("Ingreso de Credenciales", "Se ingresa con el Rut " + rutCliente + " y clave " + clave + "", EstadoPrueba.PASSED, false);
            btnIngresar.click();
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void menu(String arg0) {
        try {
            switch (arg0) {
                case "Inversiones":
                    esperar(12);
                    visualizarObjeto(linkInversiones, 3);
                    UtilsWeb.enmarcarObjeto(linkInversiones);
                    PdfBciReports.addWebReportImage("Click al menu " + arg0 + "", "Se da click al menu " + arg0 + "", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(linkInversiones);
                    linkInversiones.click();
                    esperar(2);
                    break;
                case "Fondos Mutuos":
                    visualizarObjeto(menuFondosMutuos, 3);
                    UtilsWeb.enmarcarObjeto(menuFondosMutuos);
                    PdfBciReports.addWebReportImage("Click al menu " + arg0 + "", "Se da click al menu " + arg0 + "", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(menuFondosMutuos);
                    WebUtils.embeberUrlEnIframeContenido(URL_VITRINA_INVERSIONES);
                    PdfBciReports.addWebReportImage("Embebe la URL de  " + arg0 + "", "Se embebe la URL de " + arg0 + "", EstadoPrueba.PASSED, false);
                    DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    break;
                case "Carteras":
                    visualizarObjeto(menuCarteras, 2);
                    UtilsWeb.enmarcarObjeto(menuCarteras);
                    PdfBciReports.addWebReportImage("Click al menu " + arg0 + "", "Se da click al menu " + arg0 + "", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(menuCarteras);
                    WebUtils.embeberUrlEnIframeContenido(URL_CARTERAS_DESTACADAS_INVERSIONES);
                    PdfBciReports.addWebReportImage("Embebe la URL de  " + arg0 + "", "Se embebe la URL de " + arg0 + "", EstadoPrueba.PASSED, false);
                    DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    break;
                case "VER TODOS LOS FONDOS MUTUOS":
                    DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    WebElement ver = existeElemento("//a[@class='see-all-funds-btn bci-wk-link']", 5);
                    UtilsWeb.enmarcarObjeto(ver);
                    PdfBciReports.addWebReportImage("Click al menu " + arg0 + "", "Se da click al menu " + arg0 + "", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(ver);
                    WebUtils.embeberUrlEnIframeContenido(URL_VITRINA_INVERSIONES);
                    PdfBciReports.addWebReportImage("Embebe la URL de  " + arg0 + "", "Se embebe la URL de " + arg0 + "", EstadoPrueba.PASSED, false);
                    DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    break;
                case "Resumen de inversiones":
                    misInversiones.click();
                    UtilsWeb.enmarcarObjeto(resumenInversiones);
                    PdfBciReports.addWebReportImage("Click al menu " + arg0 + "", "Se da click al menu " + arg0 + "", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(resumenInversiones);
                    //resumenInversiones.click();
                    WebUtils.embeberUrlEnIframeContenido(URL_RESUMEN_INVERSIONES);
                    PdfBciReports.addWebReportImage("Embebe la URL de  " + arg0 + "", "Se embebe la URL de " + arg0 + "", EstadoPrueba.PASSED, false);
                    DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    break;
                case "Cartola de saldos":
                    UtilsWeb.enmarcarObjeto(cartolaDeSaldos);
                    PdfBciReports.addWebReportImage("Click al menu " + arg0 + "", "Se da click al menu " + arg0 + "", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(cartolaDeSaldos);
                    cartolaDeSaldos.click();
                    esperar(30);
                    DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    break;
                case "Rescatar":
                    visualizarObjeto(rescatar, 3);
                    UtilsWeb.enmarcarObjeto(rescatar);
                    PdfBciReports.addWebReportImage("Click al menu " + arg0 + "", "Se da click al menu " + arg0 + "", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(rescatar);
                    rescatar.click();
                    esperar(20);
                    DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    break;
                case "Portafolios Accionarios":
                    visualizarObjeto(portafoliosAccionarios, 3);
                    UtilsWeb.enmarcarObjeto(portafoliosAccionarios);
                    PdfBciReports.addWebReportImage("Click al menu " + arg0 + "", "Se da click al menu " + arg0 + "", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(portafoliosAccionarios);
                    esperar(1);
                    break;
                case "Inversiones home":
                    esperar(10);
                    visualizarObjeto(linkInversiones, 3);
                    UtilsWeb.enmarcarObjeto(linkInversiones);
                    PdfBciReports.addWebReportImage("Click al menu " + arg0 + "", "Se da click al menu " + arg0 + "", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(linkInversiones);
                    linkInversiones.click();
                    esperar(1);
                    misInversiones.click();
                    UtilsWeb.enmarcarObjeto(resumenInversiones);
                    UtilsWeb.desenmarcarObjeto(resumenInversiones);
                    WebUtils.embeberUrlEnIframeContenido(URL_HOME_INVERSIONES);
                    PdfBciReports.addWebReportImage("Embebe la URL de  " + arg0 + "", "Se embebe la URL de " + arg0 + "", EstadoPrueba.PASSED, false);
                    DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    break;
            }

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }

    }

    public void listaDesplegable(String arg0, String arg1) {
        try {
            switch (arg0) {
                case "Invierte":
                    visualizarObjeto(menuInvierte, 3);
                    menuInvierte.click();
                    esperar(1);
                    break;
                case "Habilitate para invertir":
                    visualizarObjeto(habilitateParaInvertir, 3);
                    habilitateParaInvertir.click();
                    esperar(1);
                    break;
                case "Mis Inversiones":
                    visualizarObjeto(misInversiones, 3);
                    misInversiones.click();
                    esperar(1);
                    break;
            }
            switch (arg1) {
                case "Alternativas de Inversión":
                    visualizarObjeto(alternativInver, 3);
                    alternativInver.click();
                    esperar(1);
                    break;
                case "Te asesoramos":
                    visualizarObjeto(menuteasesoramos, 3);
                    menuteasesoramos.click();
                    esperar(1);
                    break;
                case "Fondos Mutuos":
                    visualizarObjeto(menuFondosMutuos2, 3);
                    UtilsWeb.enmarcarObjeto(menuFondosMutuos2);
                    UtilsWeb.desenmarcarObjeto(menuFondosMutuos2);
                    WebUtils.embeberUrlEnIframeContenido(URL_VITRINA_INVERSIONES);
                    DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    break;
                case "Resumen de inversiones":
                    UtilsWeb.enmarcarObjeto(resumenInversiones);
                    PdfBciReports.addWebReportImage("Click al menu " + arg0 + "", "Se da click al menu " + arg0 + "", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(resumenInversiones);
                    WebUtils.embeberUrlEnIframeContenido(URL_RESUMEN_INVERSIONES);
                    PdfBciReports.addWebReportImage("Embebe la URL de  " + arg0 + "", "Se embebe la URL de " + arg0 + "", EstadoPrueba.PASSED, false);
                    DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
                    closePopUpRescate.click();
                    esperar(2);
                    break;
                case "Mis Fondos Mutuos":
                    visualizarObjeto(misFondosMutuos, 3);
                    misFondosMutuos.click();
                    esperar(2);
                    break;

            }
            PdfBciReports.addWebReportImage("Presiono desde la lista desplegable " + arg0 + " y luego " + arg1, "Se presiona desde la lista desplegable " + arg0 + " y luego " + arg1, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void visualizoModal(String arg0) {
        try {
            pausa(5);
            LOGGER.info("Compara el texto del modal ");
            switch (arg0) {
                case "close\n" + "Estás a un paso de invertir\n" + "Sólo nos falta conocer tu perfil de inversionista el cuál nos permitirá saber tu nivel de tolerancia al riesgo. Puedes perfilarte después pero deberás obtener tu perfil antes de realizar tu primera inversión.\n" + "En Otro Momento Conocer Mi Perfil":
                    validaElemento(txtModal, "Estás a un paso de invertir", 2, false);
                    break;
                case "close\n" + "Este Fondo Mutuo es de un riesgo superior a tu actual perfil de inversionista.\n" + "Quieres invertir en un fondo de un perfil Muy Agresivo y tu actual perfil es Balanceado. Para continuar con tu inversión acepta la Declaración Resultado Perfil de Riesgo.\n" + "Por medio de la presente, declaro expresamente haber sido informado cabal y oportunamente por el Banco Crédito e Inversiones o sus empresas filiales, según corresponda, respecto del resultado obtenido en la encuesta Perfil de Inversionista, siendo por tanto adecuados a mi perfil de inversionista, sólo aquellos productos que forman parte de ese perfil de riesgo o de otros perfiles de menor riesgo, respecto de los cuales he sido informado y que declaro conocer y aceptar. No obstante lo anterior, y aunque he sido expresamente informado por el Banco Crédito e Inversiones o sus empresas filiales, según corresponda, a que invierta en aquellos productos que se ajustan de mejor manera a mi perfil de riesgo y que cualquier otro producto que presente un riego mayor al que he obtenido en la encuesta Perfil de Inversionista no resulta adecuado a mi persona, estoy consciente y manifiesto en forma libre y espontánea mi intención de invertir en productos que presentan un grado de riesgo mayor al que se me ha recomendado asumir.\n" + "Declaro aceptar y manifiesto mi conformidad de invertir en un perfil de riesgo superior.\n" + "No Acepto Acepto":
                    validaElemento(txtModal, "Este Fondo Mutuo es de un riesgo superior a tu actual perfil de inversionista", 2, false);
                    break;
                case "close\n" + "Tuvimos un problema con tu solicitud\n" + "Para solucionarlo, acércate a cualquiera de nuestras sucursales o llámanos al (2) 2540 4599 de lunes a jueves entre las 9:00 y 18:00 horas o viernes entre las 9:00 y 15:30 horas.\n" + "Aceptar":
                    validaElemento(txtModal, "Tuvimos un problema con tu solicitud", 3, false);
                    break;
                case "close\n" + "Saldo insuficiente\n" + "El saldo disponible en tu cuenta no es suficiente para realizar esta inversión.\n" + "Entendido":
                    validaElemento(txtModal, "Saldo insuficiente", 2, false);
                    break;

            }
            //LOGGER.info(txtModal.getText());
            compareTextWithReport(txtModal, arg0, false);
            PdfBciReports.addWebReportImage("Despliegue de modal ", "Se encuentra el modal " + arg0 + "", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }

    }

    public void multipass(String multipass) {
        try {
            esperar(2);
            DriverContextWeb.getDriverWeb().switchTo().defaultContent();
            Actions builder = new Actions(DriverContextWeb.getDriverWeb());
            Action seriesOfActions = builder
                    .moveToElement(inputClaveMultipass)
                    .click()
                    .sendKeys(multipass)
                    .keyUp(inputClaveMultipass, Keys.SHIFT)
                    .build();
            seriesOfActions.perform();
            esperar(3);
            PdfBciReports.addReport("Ingreso de Multipass", "Se ingresa con el multipass " + multipass + " ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }

    }

    public void presionoCheck() {
        try {
            esperar(7);
            WebElement texto = existeElemento("//p[contains(text(),'Por medio de la presente, declaro expresamente haber sido informado cabal y oportunamente por el Banco Crédito e Inversiones o sus empresas filiales, según corresponda, respecto del resultado obtenido en la encuesta Perfil de Inversionista, siendo por tanto adecuados a mi perfil de inversionista, sólo aquellos productos que forman parte de ese perfil de riesgo o de otros perfiles de menor riesgo, respecto de los cuales he sido informado y que declaro conocer y aceptar. No obstante lo anterior, y aunque he sido expresamente informado por el Banco Crédito e Inversiones o sus empresas filiales, según corresponda, a que invierta en aquellos productos que se ajustan de mejor manera a mi perfil de riesgo y que cualquier otro producto que presente un riesgo mayor al que he obtenido en la encuesta Perfil de Inversionista no resulta adecuado a mi persona, estoy consciente y manifiesto en forma libre y espontánea mi intención de invertir en productos que presentan un grado de riesgo mayor al que se me ha recomendado asumir.')]", 3);
            PdfBciReports.addWebReportImage("texto discleimer acepta invertir a un riesgo mayor", "Se despliega el texto : " + texto.getText(), EstadoPrueba.PASSED, false);
            if (visualizarObjetoScroll(check, 3)) {
                UtilsWeb.enmarcarObjeto(check);
                PdfBciReports.addWebReportImage("Presiono check", "Se presiona check ", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(check);
                check.click();
            }
            if (visualizarObjetoScroll(checkk, 3)) {
                UtilsWeb.enmarcarObjeto(checkk);
                PdfBciReports.addWebReportImage("Presiono check", "Se presiona check ", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(checkk);
                JavascriptExecutor ejecutador = (JavascriptExecutor) DriverContextWeb.getDriverWeb();
                ejecutador.executeScript("arguments[0].click();", checkk);

            } else {
                visualizarObjetoScroll(checkkk, 3);
                UtilsWeb.enmarcarObjeto(checkkk);
                PdfBciReports.addWebReportImage("Presiono check", "Se presiona check ", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(checkkk);
                checkkk.click();
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }

    }

    public void presionoCheckk(String arg0) {
        try {
            esperar(2);
            if (visualizarObjetoScroll(check, 3)) {
                UtilsWeb.enmarcarObjeto(check);
                PdfBciReports.addWebReportImage("Presiono check", "Se presiona check de " + arg0, EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(check);
                check.click();
            } else {
                visualizarObjetoScroll(checkk, 3);
                UtilsWeb.enmarcarObjeto(checkk);
                PdfBciReports.addWebReportImage("Presiono check", "Se presiona check ", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(checkk);
                checkk.click();
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }

    }

    public void ingresadatosinvFFMMCLPvitrina(String arg0) {
        try {
            esperar(12);
            String monto = "5000";
            inputMontoInvertirCLP.clear();
            inputMontoInvertirCLP.sendKeys(monto);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoCorreo(String arg0) {
        try {
            esperar(5);
            if (visualizarObjetoScroll(alertafuerahorario, 3)) {
                PdfBciReports.addWebReportImage("alerta de inversión fuera de horario", "Se alerta sobre inversión fuera de horario", EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport("inversión dentro de horario", "La inversión se realiza dentro de horario", EstadoPrueba.PASSED, false);
            }
            esperar(2);
            if (visualizarObjetoScroll(inputCorre, 3)) {
                inputCorre.clear();
                inputCorre.sendKeys(arg0);
            } else {
                WebElement inputCorreo = existeElemento("//input[@formcontrolname='email']", 3);
                validaElemento(inputCorreo, "input de correo", 3, false);
                inputCorreo.clear();
                inputCorreo.sendKeys(arg0);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void visualizoLaAdvertenciaFueraDeHorario() {
        try {
            //String advertencia = "Tu inversión se hará efectiva a partir del siguiente día hábil, ya que la estás solicitando fuera de horario.";
            WebElement alerta = existeElemento("// p[@class='ng-star-inserted'] ", 3);
            validaElemento(alerta, "alerta de inversión fuera de horario", 3, false);
            //compareTextWithReport(alerta, advertencia, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoInvRealizada(String arg0) {
        try {
            pausa(10);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeMedallia);
            WebElement marco = existeElemento("//div[@class='modal-live-form ng-scope']", 3);
            UtilsWeb.enmarcarObjeto(marco);
            scrollAlElementoConJavascript(closeEncuestaMedallia);
            PdfBciReports.addWebReportImage("Encuesta Medallia", "Se visualiza la encuesta Medallia", EstadoPrueba.PASSED, false);
            visualizarObjeto(enviarEncuesta, 3);
            visualizarObjeto(cincoestrellas, 3);
            visualizarObjeto(cerrarEncuestaMedallia, 3);
            visualizarObjeto(preguntaInicialMedallia, 3);
            esperar(1);
            UtilsWeb.desenmarcarObjeto(marco);
            PdfBciReports.addWebReportImage("Cierre encuesta Medallia", "Se cierra la encuesta Medallia", EstadoPrueba.PASSED, false);
            esperar(1);
            cerrarEncuestaMedallia.click();
            esperar(1);
            DriverContextWeb.getDriverWeb().switchTo().parentFrame();
            LOGGER.info("Tu solicitud fue realizada con éxito");
            visualizarObjetoScroll(exito, 2);
            validaElemento(exito, "Tu solicitud de inversión ha ingresado con éxito", 2, false);
            PdfBciReports.addWebReportImage("Despliegue de inversión realizada ", "Se despliega el mensaje " + arg0 + "", EstadoPrueba.PASSED, false);
            esperar(3);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoDosCheck() {
        try {
            checkBox_2.click();
            checkBox_3.click();
            esperar(1);
            PdfBciReports.addWebReportImage("Presiono check", "Se presionan dos check para comparar", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void graficocomparaFFMM(String arg0) {
        try {
            WebElement graficontenedor = existeElemento("//div[@class='bci-wk-modal-container']", 5);
            validaElemento(graficontenedor, "Gráfico comparativo ", 5, true);
            WebElement titulografico = existeElemento("//p[@class='bci-wk-h400']", 5);
            validaElemento(titulografico, "Gráfico comparativo de rentabilidades nominales acumuladas de 36 meses", 5, false);
            PdfBciReports.addWebReportImage("Grafico comparador Fondos Mutuos", "Se visualiza " + arg0, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonEnLaPantalla(String arg0, String arg1) {
        try {
            if (visualizarObjetoScroll(botonInvertirAntiguo, 3)) {
                PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + " dentro del comparador", EstadoPrueba.PASSED, false);
                botonInvertirAntiguo.click();
                esperar(2);
            }
            if (visualizarObjetoScroll(btnInvertirVitrina, 3)) {
                PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + " en la vitrina", EstadoPrueba.PASSED, false);
                btnInvertirVitrina.click();
                esperar(2);
            }
            if (visualizarObjetoScroll(botonInvertirComparado, 3)) {
                PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + " dentro del comparador", EstadoPrueba.PASSED, false);
                botonInvertirComparado.click();
                esperar(2);
            } else {
                PdfBciReports.addWebReportImage("Click a " + arg0 + "", "No se encuentra el botón " + arg0 + " dentro de la pantalla", EstadoPrueba.PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void verseriesFFMM(String arg0) {
        try {
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
            switch (arg0) {
                case "Asia":
                    visualizarObjeto(vermas1, 3);
                    UtilsWeb.enmarcarObjeto(vermas1);
                    UtilsWeb.desenmarcarObjeto(vermas1);
                    vermas1.click();
                    break;
                case "Estados Unidos":
                    visualizarObjeto(vermas2, 3);
                    UtilsWeb.enmarcarObjeto(vermas2);
                    UtilsWeb.desenmarcarObjeto(vermas2);
                    vermas2.click();
                    break;
            }
            PdfBciReports.addWebReportImage("Click a invertir en fondo mutuo " + arg0 + "", "Se da click a invertir en fondo mutuo " + arg0 + "", EstadoPrueba.PASSED, false);
            esperar(11);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoDeSerieBprivada(String arg0) {
        try {
            WebElement saberserieBprivada = existeElemento("(//button[contains (text(),'SABER M')])[3]", 3);
            saberserieBprivada.click();
            esperar(7);
            PdfBciReports.addWebReportImage("Presiono SABER MÁS en serie Bprivada del fondo Asia", "Se presiona saber más en  " + arg0, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoLaOpcionDeEnElFondoMutuoDeGlobalTitan(String arg0) {
        try {
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
            sabermas1.click();
            esperar(5);
            PdfBciReports.addWebReportImage("Presiono la opción en el fondo mutuo Global Titán", "Se presiona la opción en el fondo mutuo  " + arg0, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElDetalleDelFondoMutuoSeleccionado(String arg0) {
        try {
            validaElemento("//div[@class='dynamic-wallet-description--header__type bci-wk-h600 bci-wk-h300']", 5);
            validaElemento("//p[@class='dynamic-wallet-description--content__name bci-wk-h450']", 3);
            validaElemento("//p[normalize-space()='Mensual']", 3);
            PdfBciReports.addWebReportImage("Visualizo el detalle en " + arg0, "Se presiona la opción en el fondo mutuo Global Titán ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonSABERMASEnElFondoMutuoDeAsia() {
        try {
            esperar(7);
            WebElement invertir = existeElemento("//span[contains (text(),'Asia')]//ancestor::bci-card//descendant::button[contains(text(),'SABER MÁS')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón SABER MÁS fondo mutuo", "Se selecciona boton de saber más en el fondo Asia", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(invertir);
            invertir.click();
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoLosDatosEnElCalculaLaRentabilidadHistoricaDelFondoMutuo() {
        try {
            WebElement inputmonto = existeElemento("//input[@placeholder='Ingresa un monto']", 5);
            inputmonto.clear();
            inputmonto.sendKeys("1000000");
            WebElement inputdiashace = existeElemento("//bci-wk-input-text[@formcontrolname=\"days\"]//input", 5);
            inputdiashace.clear();
            inputdiashace.sendKeys("365");
            PdfBciReports.addWebReportImage("ingreso los datos en la calculadora la rentabilidad historica del Fondo Mutuo", "Se ingresan los datos en la calculadora la rentabilidad historica del Fondo Mutuo", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoLoQueLoQueHoyTendriaSiHubieseInvertidoHaceMesesODias() {
        try {
            esperar(3);
            String dias = "365";
            WebElement resultadohoytendrias = existeElemento("//p[@class='returns-calculator__result__money wk-text-grey-500 bci-wk-h800']", 5);
            resultadohoytendrias.getText();
            esperar(2);
            PdfBciReports.addWebReportImage("Visualizo que tendría si hubiese invertido hace meses o dias", "Se Visualiza lo que hoy tendría " + resultadohoytendrias.getText() + " si hubiese invertido hace " + dias + " dias", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoPantallaDeEncuesta(String arg0) {
        try {
            esperar(20);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeMedallia);
            visualizarObjetoScroll(cerrarEncuestaMedallia, 3);
            visualizarObjetoScroll(enviarEncuesta, 5);
            PdfBciReports.addWebReportImage("Encuesta Medallia", "Se visualiza la encuesta Medallia " + arg0 , EstadoPrueba.PASSED, false);
            cerrarEncuestaMedallia.click();
            PdfBciReports.addReport("Cierre encuesta Medallia", "Se cierra la encuesta Medallia", EstadoPrueba.PASSED, false);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoLaOpcion(String arg0) {
        try {
            esperar(1);
            switch (arg0) {
                case "Entre 1 y 2 años":
                    WebElement selecthorizonte = existeElemento("//bci-wk-select[@id='filterSelect']//select", 5);
                    selecthorizonte.click();
                    WebElement opc = existeElemento("//*[@id='filterSelect']/select/option[4]", 5);
                    opc.click();
                    break;
                case "De menor a mayor":
                    WebElement selectrentab = existeElemento("//bci-wk-select[@id='orderSelect']//select", 5);
                    selectrentab.click();
                    WebElement opci = existeElemento("//*[@id=\"orderSelect\"]/select/option[2]", 5);
                    opci.click();
                    break;
            }
            PdfBciReports.addWebReportImage("Selecciono la opción " + arg0 + "", "Se da click a " + arg0 + "", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueSeHayaOrdenadoDeFormaCorrectaPorHorizonteDeInversionSugerido(String arg0) {
        try {
            esperar(1);
            validaElemento("//span[@class='vitrina-asset--header-ffmm-bold bci-wk-h400']", 5);
            validaElemento("//div[normalize-space()='Rentabilidad mensual pasada*']", 5);
            validaElemento("//div[normalize-space()='Rentabilidad anual pasada*']", 5);

            PdfBciReports.addWebReportImage("Visualizo que se haya ordenado de forma correcta por horizonte de inversión sugerido", "Se visualiza que se haya ordenado de forma correcta por horizonte de inversión sugerido", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueSeHayaOrdenadoPorRentabilidadAnualPasada(String arg0) {
        try {
            esperar(1);
            validaElemento("//span[normalize-space()='America Latina']", 5);
            validaElemento("(//div[normalize-space()='Rentabilidad mensual pasada*'])[1]", 5);
            validaElemento("(//div[normalize-space()='Rentabilidad anual pasada*'])[1]", 5);
            validaElemento("//span[normalize-space()='Acciones Chilenas']", 5);
            validaElemento("//span[normalize-space()='BCI USA']", 5);
            PdfBciReports.addWebReportImage("Visualizo que se haya ordenado de forma correcta por rentabilidad anual pasada", "Se visualiza que se haya ordenado de forma correcta por por rentabilidad anual pasada", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoPantallaDeFondosMutuos(String arg0) {
        try {
            esperar(5);
            validaElemento("//p[@class='showcase--title-title wk-text-grey-500 bci-wk-h800']", 5);
            validaElemento("//p[@class='showcase--title-subtitle bci-wk-h400']", 5);
            validaElemento("//p[@class='back-profiling body']", 5);
            validaElemento("//label[@for='filterControl']", 5);
            esperar(1);
            PdfBciReports.addWebReportImage("Visualizo que se muestra correctamente la vista de la vitrina de fondos mutuos", "Se visualiza  correctamente la vista de la vitrina de fondos mutuo", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoLosDatosCorrespondienteALaPantallaDeTusDatosDeCliente() {
        try {
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
            validaElemento("//p[@class='enrolamiento-header wk-text-grey-500 bci-wk-h800']", 3);
            validaElemento("//p[@class='enrolamiento-information--title wk-text-grey-500 ng-star-inserted']", 3);
            validaElemento("//span[normalize-space()='Revisa y/o actualiza tus datos de cliente.']", 3);
            validaElemento("//span[contains(text(),'Ingresa la información sobre el origen de tus ingr')]", 3);
            validaElemento("//span[normalize-space()='Firmar tus contratos de inversionista en línea.']", 3);
            validaElemento("//p[normalize-space()='Tus datos de cliente']", 3);

            PdfBciReports.addWebReportImage("Ingreso los datos correspondientes en la pantalla tus datos de cliente", "Ingreso los datos correspondientes en la pantalla tus datos de cliente", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoTelefonoEnElCampo(String arg0) {
        try {
            WebElement inputTelefono = existeElemento("//input[@attr.data-phonenumber='phonenumber']", 3);
            inputTelefono.clear();
            inputTelefono.sendKeys(arg0);
            PdfBciReports.addWebReportImage("Ingreso número de teléfono en el campo", "Se ingresa número de teléfono en el campo", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoEn(String arg0, String arg1) {
        try {
            WebElement SelecActividad = existeElemento("//span[@class='mat-select-placeholder ng-tns-c11-1 ng-star-inserted']", 3);
            validaElemento(SelecActividad, "selector de actividad", 3, false);
            SelecActividad.click();
            switch (arg0) {
                case "Empleado(a)":
                    WebElement opcActividad = existeElemento("//span[normalize-space()='Empleado(a)']", 3);
                    opcActividad.click();
                    break;
                case "Jubilado(a)":
                    WebElement opcActivida = existeElemento("//span[normalize-space()='Jubilado(a)']", 3);
                    opcActivida.click();
                    break;
                case "Otro":
                    WebElement opcotro = existeElemento("//span[@class='mat-option-text'][normalize-space()='Otro']", 3);
                    opcotro.click();
                    break;
            }
            PdfBciReports.addReport("ingreso actividad", "Se ingresa actividad  " + arg0 + " en la pantalla " + arg1 + "", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoLosCamposQueSeDespliegan() {
        try {
            WebElement inputRutEmpresa = existeElemento("//input[@formcontrolname='companyRut']", 3);
            validaElemento(inputRutEmpresa, "selector de actividad", 3, false);
            inputRutEmpresa.clear();
            inputRutEmpresa.sendKeys("97.006.000-6");
            WebElement opcActividad = existeElemento("//input[@formcontrolname='companyName']", 3);
            opcActividad.clear();
            opcActividad.sendKeys("BCI");
            PdfBciReports.addReport("ingreso los campos que se despliegan", "Se ingresa los campos que se despliegan  ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElCheckboxDelRecuadroDeDeclaroQueSoloDeboPagarImpuestosEnChile() {
        try {
            WebElement checkbox = existeElemento("//label[@for='mat-checkbox-2-input']//div[@class='mat-checkbox-inner-container']", 3);
            checkbox.click();
            PdfBciReports.addReport("Selecciono el checkbox en que declaro que solo debo pagar impuestos en Chile", "Se selecciona el checkbox en que declaro que solo debo pagar impuestos en Chile ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoLaOpcionParaLosFondosAInvertirFueronProvistosPorUSPersonEntidadesOPersonas() {
        try {
            WebElement opc8 = existeElemento("//label[@for='app-bci-chip-radio8']", 3);
            opc8.click();
            PdfBciReports.addReport("Selecciono la opción para los fondos a invertir fueron provistos por US person entidades o personas ", " Se selecciona la opción para los fondos a invertir fueron provistos por US person entidades o personas", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void seleccionoEnLaOpcionDeDondeProvienenLosFondos(String arg0) {
        try {
            WebElement opc14 = existeElemento("//label[@for='app-bci-chip-radio14']", 3);
            opc14.click();
            PdfBciReports.addReport(" ", " ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElCheckboxDeAutorizoABciAssetManagement() {
        try {
            WebElement checkBAM = existeElemento("//label[@for='mat-checkbox-1-input']//div[@class='mat-checkbox-inner-container']", 3);
            checkBAM.click();
            PdfBciReports.addReport("Selecciono el checkbox de autorizo a Bci Asset Management ", "Se selecciona el el checkbox de autorizo a Bci Asset Management ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoClienteUSPerson(String arg0) {
        try {
            //DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
            WebElement modalUSPerson = existeElemento("//div[@class='feedback-message__content']", 3);
            validaElemento(modalUSPerson, "Modal US Person ", 3, true);
            esperar(3);
            PdfBciReports.addReport("Visualizo Cliente US Person ", "Se visualiza el mensaje " + arg0, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoLaOpcionParaEresNacidoCiudadanoOResidenteDeEstadosUnidosDeAmerica() {
        try {
            WebElement opc6 = existeElemento("//label[@for='app-bci-chip-radio6']", 3);
            opc6.click();
            PdfBciReports.addReport(" ", " ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoLosCamposQueSeDesplieganY(String arg0, String arg1) {
        try {
            WebElement inputRutEmpresa = existeElemento("//input[@formcontrolname='companyRut']", 3);
            validaElemento(inputRutEmpresa, "Campo Empresa", 3, false);
            inputRutEmpresa.clear();
            inputRutEmpresa.sendKeys(arg0);

            WebElement opcActividad = existeElemento("//input[@formcontrolname='companyName']", 3);
            opcActividad.clear();
            opcActividad.sendKeys(arg1);
            PdfBciReports.addReport("ingreso los campos que se despliegan", "Se ingresa los campos que se despliegan  ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoLaOpcionParaEresOTienesVinculosConPersonasEnCargosPublicosPEP() {
        try {
            WebElement opc10 = existeElemento("//label[@for='app-bci-chip-radio10']", 3);
            opc10.click();
            PdfBciReports.addReport(" ", " ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElSiguienteMensaje(String arg0) {
        try {
            WebElement modalPEP = existeElemento("//p[@class='body']", 3);
            validaElemento(modalPEP, "Modal PEP", 3, true);
            WebElement monologo = existeElemento("//div[@class='monologo-search']", 3);
            validaElemento(monologo, "mono amarillo icono", 3, true);
            esperar(3);
            PdfBciReports.addReport("Visualizo Cliente PEP ", "Se visualiza el mensaje " + arg0, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoLaInformacionDeLosIndicadores(String arg0) {
        try {
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
            WebElement indicadores = existeElemento("//p[@class='indicatores-title--text bci-wk-h500']", 3);
            validaElemento(indicadores, "Título Indicadores económicos", 3, true);
            WebElement uf = existeElemento("//span[normalize-space()='UF']", 3);
            visualizarObjetoScroll(uf, 3);
            esperar(3);
            PdfBciReports.addReport("Visualizo Indicadores económicos", "Se visualizan " + arg0, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }

    }

    public void visualizoLaPaginaDeIndicadoresEconomicos(String arg0) {
        try {
            //DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
            DriverContextWeb.getDriverWeb().navigate().to("https://www.bci.cl/inversiones/mercadosglobales");
            WebElement mercados = existeElemento("//h1[normalize-space()='Mercados Globales']", 3);
            validaElemento(mercados, "Mercados Globales", 3, true);

            esperar(3);
            PdfBciReports.addReport("Visualizo Cliente PEP ", "Se visualiza el mensaje " + arg0, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seMuestraPantallaDeHabilitarseParaInvertirEnFondosMutuos() {
        try {
            validaElemento("//h3[@class='wk-text-grey-500 bci-wk-h800']", 3);
            validaElemento("//p[@class='wk-text-grey-500 spaced bci-wk-h400 ng-star-inserted']", 3);
            visualizarObjetoScroll(yahascompletadotusdatos, 3);
            PdfBciReports.addReport("Pantalla de habilitarse para invertir en Fondos Mutuos ", " Se muestra Pantalla de habilitarse para invertir en Fondos Mutuos", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seMuestraLaListaDeContratos() {
        try {
            validaElemento("//span[normalize-space()='Declaración de Clasificación y Consentimiento']", 3);
            validaElemento("//span[normalize-space()='Carta de Representación de Inversionista']", 3);
            validaElemento("//span[contains(text(),'Contrato General de Fondos Bci Asset Management Ad')]", 3);
            validaElemento("//span[normalize-space()='Ficha Cliente Inversionista Personas Naturales']", 3);
            PdfBciReports.addReport("Lista de contratos ", "Se muestra la lista de documentos de contrato de inversiones ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElLinkDESCARGARTODOS() {
        try {
            String nombreArchivo = "Documentos legales registro fondos mutuos";
            String extension = ".zip";
            WebElement linkDescarga = existeElemento("//button[@class='green lighten-5 bci-button']", 3);
            linkDescarga.click();
            Properties prop = Acciones.loadProp("offshore");
            String rutaDescarga = prop.getProperty("rutaDescarga");
            File user = new File(System.getProperty("user.home"));
            File office = new File(System.getProperty("os.name"));
            rutaDescarga = Acciones.rutaDescarga(office, rutaDescarga);
            String url = user + rutaDescarga + nombreArchivo + extension;
            LOGGER.info("Se valida la descarga " + url);
            pausa(2);
            validarDescarga(url, "SI");
            LOGGER.info("fin metodo presionoElLinkDESCARGARTODOS" + user);
            PdfBciReports.addWebReportImage("Se valida la descarga " + url, "Se valida la descarga del archivo con la ruta" + url, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElCheckDeDeclaracionDeLecturaDeDocumentos() {
        try {
            WebElement check = existeElemento("//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']", 3);
            check.click();
            PdfBciReports.addReport(" Check declaración lectura de documentos", "Se selecciona el check declaración de lectura de documentos ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoClaveMultipassValida() {
        try {
            String multipass = "123456";
            WebElement inputMultipass = existeElemento("//input[@placeholder='Clave Multipass']", 3);
            inputMultipass.clear();
            inputMultipass.sendKeys(multipass);
            PdfBciReports.addReport("Clave multipas válida", "Se ingresa multipass válida ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seMuestraPantallaDeFelicidadesYaEstasListoParaInvertirEnFondosMutuos() {
        try {
            esperar(20);
            validaElemento("//h3[@class='bci-wk-h900']", 3);
            validaElemento("//p[@class='ready bci-wk-h500']", 3);
            validaElemento("//p[@class='sent-email bci-wk-h200']", 3);
            validaElemento("//p[@class='wk-text-grey-500 bci-wk-h400']", 3);
            PdfBciReports.addReport("Pantalla Felicidades Ya estás listo para invertir", " Se muestra la pantalla de felicidades ya estás listo para invertir en fondos mutuos", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void visualizoElTituloDeLaVitrina(String arg0) {
        try {
            esperar(3);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
            switch (arg0) {
                case "Invierte en Carteras Dinámicas":
                    WebElement tituloCarteDinam = existeElemento("//span[contains (text (), 'Invierte en Carteras Dinámicas')]", 3);
                    validaElemento(tituloCarteDinam, "Título Invierte en Carteras Dinámicas", 3, true);
                    break;
                case "Invierte en Carteras Patrimoniales ":
                    WebElement tiutloCartPatrim = existeElemento("//span[contains (text (), 'Invierte en Carteras Patrimoniales')]", 3);
                    validaElemento(tiutloCartPatrim, "Título Invierte en Carteras Patrimoniales", 3, true);
                    break;

            }
            PdfBciReports.addReport("Se visualiza Título", "Se visualiza título " + arg0, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoLaOpcionDeVerMasSeriesDeAlgunaCartera() {
        try {
            vermas1.click();
            PdfBciReports.addReport("Opción Ver más series ", "Se presiona la opción de ver más series de alguna cartera ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueSeMuestraLaInformacionDeSerieMontoMinimoDeInversionCostoDeRescateYRentabilidadDeCadaSerie() {
        try {
            validaElemento("(//span[contains (text(),'Serie')])[3]", 3);
            validaElemento("(//div[contains (text(),'Monto')])[1]", 3);
            validaElemento("(//div[contains (text(),'Costo')])[1]", 3);
            validaElemento("(//div[contains (text(),'Rentabilidad')])[1]", 3);
            PdfBciReports.addReport("Información de la serie ", "Se visualiza que se muestra la información de la serie, monto mínimo de inversión, costo de rescate y rentabilidad de la serie ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueExisteUnBotonSABERMASParaCadaSerie() {
        try {
            validaElemento("(//button[contains (text(),'SABER M')])[2]", 3);

            PdfBciReports.addReport(" Botón SABER MÁS", "Visualizo que existe un botón Saber Más para cada serie ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonSABERMASDeUnaCartera() {
        try {
            WebElement btnsabermas = existeElemento("(//button[contains (text(),'SABER M')])[2]", 3);
            btnsabermas.click();
            esperar(20);
            PdfBciReports.addReport("Presiono botón saber más de una Cartera ", "Se presiona botón saber más de una cartera", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElDetalleDeLaCartera() {
        try {
            validaElemento("//div[@class='header--subtitle ng-star-inserted']", 3);
            validaElemento("//p[@class='dynamic-wallet-description--content__name bci-wk-h450']", 3);
            if (visualizarObjetoScroll(titleDinamica, 3)) {
                PdfBciReports.addReport("Título Cartera Dinámica ", "Se visualiza el titulo de Cartera Dinámica ", EstadoPrueba.PASSED, false);
            } else {
                visualizarObjetoScroll(titlePatrimonial, 3);
                PdfBciReports.addWebReportImage("Título Cartera Patrimonial ", "Se visualiza el titulo de Cartera Patrimonial ", EstadoPrueba.PASSED, false);
            }

            esperar(3);

            PdfBciReports.addReport("Detalle de Cartera ", "Se visualiza el detalle de la cartera seleccionada ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public String ingresoConElRutClienteConsumibleYLaClave(String rutCliente, String clave) {
        try {
            esperar(4);
            Properties prop = Acciones.loadProp("offshore");
            DriverContextWeb.getDriverWeb().switchTo().frame(iframe);
            String rut;
            switch (rutCliente) {
                case "rutConsumible1":
                    rut = prop.getProperty("rutConsumible1");
                    Actions builder = new Actions(DriverContextWeb.getDriverWeb());
                    Action seriesOfActions = builder.moveToElement(campoRut).click().sendKeys(campoRut, rut).keyUp(campoRut, Keys.SHIFT).build();
                    seriesOfActions.perform();

                    break;
                case "rutConsumible2":
                    rut = prop.getProperty("rutConsumible2");
                    Actions builders = new Actions(DriverContextWeb.getDriverWeb());
                    Action seriesOfActionss = builders.moveToElement(campoRut).click().sendKeys(campoRut, rut).keyUp(campoRut, Keys.SHIFT).build();
                    seriesOfActionss.perform();
                    break;
            }
            campoClave.click();
            campoClave.sendKeys(clave);
            PdfBciReports.addWebReportImage("Ingreso de Credenciales", "Se ingresa con el Rut " + rutCliente + " y clave " + clave + "", EstadoPrueba.PASSED, false);
            btnIngresar.click();
            esperar(3);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }

        return rutCliente;
    }

    public void validoQueSeVisualiceLaCarteraDe(String arg0) {
        try {
            switch (arg0) {
                case "Global Titán":
                case "Estados Unidos":
                case "Asia":
                case "Estrategia pesos largo plazo":
                case "Estrategia uf hasta 1 año":
                case "Estrategia UF hasta 5 años":
                case "Estrategia uf hasta 3 años":
                case "Estrategia pesos hasta 2 años":
                case "Estrategia pesos hasta 1 año":
                case "Competitivo":
                case "Estrategia uf > 5 años":
                case "Europa":
                case "Emergente Global":
                case "Acciones Chilenas":
                case "America Latina":
                case "Express":
                case "Estructurado UF Más II":
                case "BCI USA":
                case "Dinámica Chile":
                    WebElement cartera = existeElemento("//span[normalize-space()='" + arg0 + "']", 3);
                    visualizarObjetoScroll(cartera, 2);
                    //validaElemento(cartera,"Cartera " + arg0 ,3,true);
                    break;
                case "algo":
                    break;
            }

            PdfBciReports.addWebReportImage("Visualización de cartera", "Se visualiza la Cartera " + arg0, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void despliegoLosFondosMutuos() {
        try {

            WebElement close = existeElemento("//button[contains(text(),' Conocer después ')]", 3);
            clickElemento(close, "Click a cerrar el modal emergente", "Se da click para cerrar el modal emergente");
            esperar(10);
            WebElement arrow = existeElemento("(//bci-accordion-title[normalize-space()='Mis Fondos Mutuos']//following::div[@class='arrow'])[1]", 3);
            arrow.click();
            PdfBciReports.addWebReportImage("Despliego los fondos mutuos ", "Se despliegan los fondos mutuos", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoSobreElFondoMutuoQueDeseoTraspasar() {
        try {
            WebElement card = existeElemento("//div[@id='card_1_G_FFMM']", 3);
            card.click();
            PdfBciReports.addWebReportImage("Fondo Mutuo a traspasar ", "Presiono el fondo mutuo que deseo traspasar", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonTraspasar() {
        try {
            WebElement btn = existeElemento("(//button[contains (text(),'Traspasar')])[1]", 3);
            visualizarObjetoScroll(btn, 3);
            btn.click();
            PdfBciReports.addWebReportImage("Boton Traspasar ", "Se visualiza el boton de traspasar", EstadoPrueba.PASSED, false);
            esperar(25);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElBotonDeCarterasDinamicas() {
        try {
            WebElement dinamicas = existeElemento("//label[contains(text(),'Carteras Dinámicas ')]", 3);
            visualizarObjetoScroll(dinamicas, 3);
            dinamicas.click();
            PdfBciReports.addWebReportImage("Botón Carteras Dinámicas ", "Se selcecciona el botón Carteras Dinámicas", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoUnaCarteraParaRealizarElTraspaso() {
        try {
            WebElement carteraTraspaso = existeElemento("//bci-wk-select[@id='destinationFundsSelect']//select", 3);
            carteraTraspaso.click();
            WebElement carteraAhorro = existeElemento("//*[@id=\"destinationFundsSelect\"]/select/option[contains(text(),'Ahorro')]", 3);
            visualizarObjetoScroll(carteraAhorro, 3);
            carteraAhorro.click();
            PdfBciReports.addWebReportImage("Cartera para realizar traspaso", "Se selecciona la cartera  para realizar el traspaso", EstadoPrueba.PASSED, false);
            esperar(20);
            //DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void aceptoElModalDePerfilMayor() {
        try {
            WebElement check = existeElemento("//div[@class='mat-checkbox-inner-container']", 5);
            check.click();
            WebElement acepto = existeElemento("(//button[contains (text(),'Acepto')])[2]", 3);
            visualizarObjetoScroll(acepto, 3);
            PdfBciReports.addWebReportImage("Modal de perfil mayor ", "Acepto el modal de perfil mayor", EstadoPrueba.PASSED, false);
            acepto.click();
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElTipoDeTraspasoParcial() {
        try {
            esperar(5);
            WebElement mutuos = existeElemento("(//label[contains(text(),'Traspaso parcial')])[1]", 3);
            visualizarObjetoScroll(mutuos, 3);
            mutuos.click();
            PdfBciReports.addWebReportImage("Traspaso parcial ", "Selecciono el label de traspaso parcial", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoElMontoATraspasar() {
        try {
            String monto = "5000";
            inputMontoInvertir.sendKeys(monto);
            PdfBciReports.addWebReportImage("Monto a traspasar ", "Se ingresa el monto de " + monto + " a traspasar", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElCheckDeDeclaracion() {
        try {
            esperar(3);
            WebElement mutuos = existeElemento("//label[@for='bci-wk-checkbox0']", 3);
            visualizarObjetoScroll(mutuos, 3);
            mutuos.click();
            PdfBciReports.addWebReportImage("Check de declaración traspaso ", "Presiono el check de declaración de traspaso", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonConfirmarTraspaso() {
        try {
            WebElement btnConfirmar = existeElemento("//button[contains(text(),'Confirmar Traspaso')]", 3);
            visualizarObjetoScroll(btnConfirmar, 3);
            btnConfirmar.click();
            PdfBciReports.addWebReportImage("Boton confirmar traspaso ", "Se presiona el botón confirmar traspaso", EstadoPrueba.PASSED, false);
            esperar(20);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueSeMuestreElComprobanteDelTraspaso() {
        try {
            WebElement solicitud = existeElemento("//div[@class='title']", 3);
            validaElemento("//div[contains(text(),'Nº de Folio')]", 3);
            validaElemento("//div[contains(text(),'Fecha de solicitud')]", 3);
            validaElemento("//div[contains(text(),'Hora de solicitud')]", 3);
            validaElemento("//div[contains(text(),'Fecha de liquidación*')]", 3);
            validaElemento("//div[contains(text(),'Fecha de pago**')]", 3);
            validaElemento("//div[contains(text(),'Origen de traspaso')]", 3);
            validaElemento("//div[contains(text(),'Monto referencial***')]", 3);
            validaElemento("//div[contains(text(),'Tipo de traspaso')]", 3);
            validaElemento("//div[contains(text(),'Fondo Mutuo')]", 3);
            validaElemento("//div[contains(text(),'Serie')]", 3);
            validaElemento("//div[contains(text(),'Cuenta')]", 3);
            validaElemento("//div[contains(text(),'Nº de cuotas')]", 3);
            validaElemento("//div[contains(text(),'Destino de traspaso')]", 3);
            //validaElemento("//div[contains(text(),'Cartera Dinámica')]",3);
            validaElemento("//div[contains(text(),'Serie')]", 3);
            validaElemento("//div[contains(text(),'Cuenta')]", 3);
            visualizarObjetoScroll(solicitud, 2);
            PdfBciReports.addWebReportImage("Solicitud Traspaso", "Se visualiza el comprobante de la solicitud de traspaso", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void descargoElPDFDelComprobante() {
        try {
            String nombreArchivo = "comprobanteTraspaso";
            String extension = ".pdf";
            WebElement linkDescarga = existeElemento("//button[contains(text(),'Descargar pdf')]", 3);
            linkDescarga.click();
            Properties prop = Acciones.loadProp("offshore");
            String rutaDescarga = prop.getProperty("rutaDescarga");
            File user = new File(System.getProperty("user.home"));
            File office = new File(System.getProperty("os.name"));
            rutaDescarga = Acciones.rutaDescarga(office, rutaDescarga);
            String url = user + rutaDescarga + nombreArchivo + extension;
            LOGGER.info("Se valida la descarga " + url);
            pausa(2);
            validarDescarga(url, "SI");
            LOGGER.info("fin metodo descargoElPDFDelComprobante" + user);
            PdfBciReports.addWebReportImage("Descarga del comprobante con la ruta" + url, "Se valida la descarga del comprobante con la ruta " + url, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElBotonDeFondosMutuos() {
        try {
            WebElement mutuos = existeElemento("//label[contains(text(),'Fondos Mutuos')]", 3);
            visualizarObjetoScroll(mutuos, 3);
            mutuos.click();
            PdfBciReports.addWebReportImage(" ", "", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoUnFondoParaRealizarElTraspaso() {
        try {
            WebElement fmTraspaso = existeElemento("//bci-wk-select[@id='destinationFundsSelect']//select", 3);
            visualizarObjetoScroll(fmTraspaso, 3);
            fmTraspaso.click();
            WebElement accionesChilenas = existeElemento("//*[@id=\"destinationFundsSelect\"]/select/option[contains(text(),'Acciones Chilenas')]", 3);
            accionesChilenas.click();
            PdfBciReports.addWebReportImage("Fondo a traspasar ", "Se selecciona el fondo de Acciones Chilenas para traspaso", EstadoPrueba.PASSED, false);
            esperar(20);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoNoAccederAlBeneficioTributarioMLT() {
        try {
            WebElement beneficio = existeElemento("//label[@for='bci-wk-radio1']", 3);
            beneficio.click();
            PdfBciReports.addWebReportImage("Beneficio tributario MLT ", "Selecciono que no deseo acceder al beneficio tributario MLT", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoSegundoCheckDeDeclaracion() {
        try {
            WebElement mutuos = existeElemento("//label[@for='bci-wk-checkbox1']", 3);
            mutuos.click();
            PdfBciReports.addWebReportImage("Segundo check de declaración traspaso ", "Presiono el segundo check de declaración de traspaso", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoSobreFondoMutuoQueDeseoTraspasar() {
        try {
            WebElement card = existeElemento("//div[@id='card_2_G_FFMM']", 3);
            visualizarObjetoScroll(card, 3);
            card.click();
            PdfBciReports.addWebReportImage("Fondo Mutuo a traspasar ", "Presiono el fondo mutuo que deseo traspasar", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElSiguienteMensajeDeFueraDeHorario(String arg0) {
        try {

            if (visualizarObjetoScroll(alertafuerahorario, 3)) {
                PdfBciReports.addWebReportImage("alerta de inversión fuera de horario", "Se despliega la alerta: " + arg0, EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addReport("inversión dentro de horario", "La inversión se realiza dentro de horario", EstadoPrueba.PASSED, false);
            }

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElTipoDeTraspasoTotal() {
        try {
            esperar(5);
            WebElement total = existeElemento("(//label[contains(text(),'Traspaso total')])[1]", 3);
            visualizarObjetoScroll(total, 3);
            total.click();
            PdfBciReports.addWebReportImage("Traspaso totalal ", "Selecciono el label de traspaso total", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoLaVentanaFlotanteConLasCarterasAComparar() {
        try {
            validaElemento("//bci-card[@class='floating-component']", 3);
            WebElement titulo = existeElemento("//p[contains(text(),'Selecciona un máximo de')]", 2);
            //UtilsWeb.scrollVertical(String.valueOf(2),iframeContenido);
            visualizarObjetoScroll(titulo, 3);
            esperar(1);
            PdfBciReports.addWebReportImage("Carro flotante de comparar carteras", "Se visualiza el carro flotante de comparar carteras", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElComparadorDeCarteras() {
        try {
            esperar(1);
            validaElemento("//div[@class='bci-wk-modal-container']", 3);
            WebElement titulo = existeElemento("//bci-wk-modal-title", 2);
            visualizarObjetoScroll(titulo, 3);
            esperar(1);
            PdfBciReports.addWebReportImage("Comparador de carteras", "Se visualiza el comparador de carteras", EstadoPrueba.PASSED, false);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoElMontoAInvertir() {
        try {
            esperar(30);
            String monto = "5000";
            inputMontoInvertir.clear();
            inputMontoInvertir.sendKeys(monto);
            visualizarObjetoScroll(inputMontoInvertir, 3);
            PdfBciReports.addWebReportImage("Monto a invertir", "Ingreso el monto " + monto + " a invertir ", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoUnaCuentaDeCargo() {
        try {
            WebElement selector_cuenta = existeElemento("//div[@class='mat-select-value']", 3);
            validaElemento(selector_cuenta, "selector de cuenta FFMM", 3, false);
            selector_cuenta.click();
            WebElement cuenta0 = existeElemento("//span[@class='mat-option-text'][normalize-space()='Cuenta 0']", 3);
            validaElemento(cuenta0, "cuenta 0", 3, false);
            visualizarObjetoScroll(cuenta0, 3);
            cuenta0.click();
            PdfBciReports.addWebReportImage("Cuenta de cargo", "Selecciono una cuenta de cargo para la inversión", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoLaEncuestaDeSatisfaccionYLaCierro() {
        try {

            esperar(30);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeMedallia);

            if (visualizarObjetoScroll(cerrarEncuestaMedallia, 3)) {
                visualizarObjetoScroll(enviarEncuesta, 5);
                PdfBciReports.addWebReportImage("Encuesta Medallia", "Se visualiza la encuesta Medallia", EstadoPrueba.PASSED, false);
                cerrarEncuestaMedallia.click();
                PdfBciReports.addReport("Cierre encuesta Medallia", "Se cierra la encuesta Medallia", EstadoPrueba.PASSED, false);
                DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
            } else {
                PdfBciReports.addReport("Encuesta medallia", "No se encontró encuesta medallia", EstadoPrueba.PASSED, false);
            }

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElComprobanteDeLaInversion() {
        try {
            WebElement total = existeElemento("//div[@class='container-header']", 3);
            visualizarObjetoScroll(total, 3);
            PdfBciReports.addWebReportImage("Comprobante de inversión", "Se visualiza el comprobante de inversión", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void descargoElPDFDelComprobanteInversion() {
        try {
            String nombreArchivo = "comprobanteInversion";
            String extension = ".pdf";
            WebElement linkDescarga = existeElemento("//a[contains(text(),' Descargar comprobante ')]", 3);
            linkDescarga.click();
            Properties prop = Acciones.loadProp("offshore");
            String rutaDescarga = prop.getProperty("rutaDescarga");
            File user = new File(System.getProperty("user.home"));
            File office = new File(System.getProperty("os.name"));
            rutaDescarga = Acciones.rutaDescarga(office, rutaDescarga);
            String url = user + rutaDescarga + nombreArchivo + extension;
            LOGGER.info("Se valida la descarga " + url);
            pausa(2);
            validarDescarga(url, "SI");
            LOGGER.info("fin metodo descargoElPDFDelComprobanteInversion" + user);
            PdfBciReports.addWebReportImage("Descarga del comprobante de inversión con la ruta" + url, "Se valida la descarga del comprobante de inversión con la ruta " + url, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElSiguienteMensajeFueraDeHorarioEnElComprobante(String arg0) {
        try {
            WebElement total = existeElemento("//p[contains(text(),'Tu solicitud de inversión ingresó fuera de horario, por lo cual será cargada a tu cuenta ')]", 3);
            visualizarObjetoScroll(total, 3);
            PdfBciReports.addWebReportImage("Mensaje fuera de horario de la inversión", "Se visualiza el mensaje " + arg0, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoDeFormaCorrecta(String arg0, String arg1) {
        try {
            WebUtils.embeberUrlEnIframeContenido(URL_SALDO_EVOLUTIVO);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
            esperar(1);
            WebElement total = existeElemento("//div[contains(text(),'Rendimiento del mes')]", 3);
            validaElemento("//div[contains(text(),'Rendimiento acumulado')]", 3);
            validaElemento("//div[contains(text(),'Variación total del mes')]", 3);
            visualizarObjetoScroll(total, 3);
            PdfBciReports.addWebReportImage("Evolución del saldo", "Se visualiza  " + arg0 + " con los siguientes items " + arg1, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoBotonInvertir(String arg0) {
        try {
            WebUtils.embeberUrlEnIframeContenido(URL_SALDO_EVOLUTIVO);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
            esperar(1);
            WebElement total = existeElemento("//div[contains(text(),'Rendimiento del mes')]", 3);
            validaElemento("//div[contains(text(),'Rendimiento acumulado')]", 3);
            validaElemento("//div[contains(text(),'Variación total del mes')]", 3);
            visualizarObjetoScroll(total, 3);
            PdfBciReports.addWebReportImage("Evolución del saldo", "Se visualiza  " + arg0, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElTabDeEnFondosMutuos(String arg0) {
        try {
            esperar(1);
            WebElement tab = existeElemento("//span[contains(text(),'" + arg0 + "')]", 1);
            validaElemento("//span[contains(text(),'" + arg0 + "')]", 1);
            visualizarObjetoScroll(tab, 1);
            PdfBciReports.addWebReportImage("Tab Fondos Mutuos Dólar", "Se visualiza  " + arg0, EstadoPrueba.PASSED, false);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoDeFormaCorrectaElModalDe(String arg0) {
        try {
            esperar(3);
            WebElement total = existeElemento("//bci-card[@class='container-modal grey-text']", 3);
            visualizarObjetoScroll(total, 3);
            PdfBciReports.addWebReportImage("Modal de no tiene CTA USD", "Se visualiza  correctamente el Modal " + arg0, EstadoPrueba.PASSED, false);
            WebElement aceptar = existeElemento("//button[contains(text(),'Aceptar')]", 3);
            aceptar.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }



    public void presionoEnDetalleDeMisInversiones(String arg0) {
        try {
            WebElement close = existeElemento("//button[contains(text(),' Conocer después ')]", 3);
            visualizarObjetoScroll(close, 3);
            PdfBciReports.addWebReportImage("Modal emergente", "Se despliega elemento emergente", EstadoPrueba.PASSED, false);
            clickElemento(close, "Click a cerrar el modal emergente", "Se da click para cerrar el modal emergente");
            esperar(10);
            WebElement pestania = existeElemento("//bci-accordion-title[contains(text(),' " + arg0 + " ')]", 3);
            visualizarObjetoScroll(pestania, 3);
            PdfBciReports.addWebReportImage("Presiono " + arg0, "Se visualiza " + arg0 + "en el detalle de mis inversiones  ", EstadoPrueba.PASSED, false);
            pestania.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validoLosFondosSeleccionados() {
        try {
            WebElement fmTraspaso = existeElemento("//bci-wk-select[@id='destinationFundsSelect']//select", 3);
            visualizarObjetoScroll(fmTraspaso, 3);
            fmTraspaso.click();
            PdfBciReports.addWebReportImage("Fondo a traspasar ", "Se selecciona el fondo  para traspaso", EstadoPrueba.PASSED, false);
            esperar(3);

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoEnComboboxSeleccionaUnaCarteraDinamica(String arg0) {
        try {
            WebElement cartera = existeElemento("//*[@id=\"destinationFundsSelect\"]/select/option[contains(text(),'" + arg0 + "')]", 3);
            visualizarObjetoScroll(cartera, 3);
            PdfBciReports.addWebReportImage("Cartera para realizar traspaso", "Se visualiza  la cartera " + arg0 + " para realizar el traspaso", EstadoPrueba.PASSED, false);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoEnComboboxSeleccionaUnFondoMutuo(String arg0) {
        try {
            WebElement carteraAhorro = existeElemento("//*[@id=\"destinationFundsSelect\"]/select/option[contains(text(),'" + arg0 + "')]", 3);
            visualizarObjetoScroll(carteraAhorro, 3);
            PdfBciReports.addWebReportImage("Fondo mutuo para realizar traspaso", "Se visualiza el fondo mutuo " + arg0 + " en el combobox para realizar el traspaso", EstadoPrueba.PASSED, false);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoLaEnDetalleDeMisInversiones(String arg0) {
        try {
            WebElement pestania = existeElemento("//div[@id='card_1_C_CD']//div[@class='name'][normalize-space()='Cartera Dinámica Corto Plazo Serie Clásica']", 3);
            visualizarObjetoScroll(pestania, 3);
            PdfBciReports.addWebReportImage("Presiono " + arg0, "Se visualiza " + arg0 + "en el detalle de mis inversiones  ", EstadoPrueba.PASSED, false);
            pestania.click();
            esperar(2);

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoLasCarterasSeleccionados() {
        try {
            WebElement carteraTraspaso = existeElemento("//bci-wk-select[@id='destinationFundsSelect']//select", 3);
            carteraTraspaso.click();
            PdfBciReports.addWebReportImage("Cartera para realizar traspaso", "Se selecciona la cartera  para realizar el traspaso", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void noSeDespliegaNingunFondoEnDolar(String arg0) {
        try {
            validaElementoNoExiste(dolarCash, "Fondo mutuo Dólar Cash no existe en combobox", 3, true);
            validaElementoNoExiste(retornoDolarIG, "Fondo mutuo Retorno Dólar IG no existe en combobox", 3, true);
            validaElementoNoExiste(BciUsa, "Fondo mutuo Bci Usa no existe en combobox ", 3, true);
            PdfBciReports.addWebReportImage("Valida Fondos Dólar no están presentes en el combobox", "Se valida que en el combobox no se despliega ninguno de los siguientes fondos mutuos en dólares\n" + arg0, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void presionoElTabDe(String arg0) {
        try {
            esperar(5);
            WebElement tabDolar = existeElemento("//span[normalize-space()='" + arg0 + "']", 3);
            tabDolar.click();
            PdfBciReports.addWebReportImage("Tab Inversión en Dólares", "Se selecciona Tab de Inversión en Dólares", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElBotonDeSeEncuentraDeshabilitadoParaInvertirEnLosFondos(String arg0) {
        try {
            esperar(2);
            WebElement btnInhabil = existeElemento("//*[@id=\"content\"]/app-root/app-store/div/div[1]/div/app-mutual-funds-card/div/div[1]/bci-card/div[2]/div[6]/button", 3);
            visualizarObjetoScroll(btnInhabil, 2);
            PdfBciReports.addWebReportImage("Botón de invertir deshabilitado", "El botón de invertir se encuentra deshabilitado en el  Tab de Inversión en Dólares", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validoElMensajeEnElTexto(String arg0) {
        try {
            WebElement mnsje = existeElemento("//p[contains(text(),'Recuerda que el horario para invertir en dólares es de 9:00 a 14:00 horas en días hábiles. Si deseas, puedes invertir en Fondos Mutuos en pesos.')]", 3);
            visualizarObjetoScroll(mnsje, 3);
            PdfBciReports.addWebReportImage("Mensaje horario", "Se visualiza mensaje horario de Inversión en Dólares", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void seleccionoElBotonDeEn(String arg0, String arg1) {
        try {
            esperar(6);
            WebElement invertir = existeElemento("//span[contains (text(),'" + arg1 + "')]//ancestor::bci-card//descendant::button[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón invertir fondo mutuo", "Se selecciona boton de " + arg0 + " en el fondo  " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(invertir);
            invertir.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoElEnPantallaDatosDeTuInversion(String arg0) {
        try {
            esperar(24);
            inputMontoInvertir.clear();
            inputMontoInvertir.sendKeys(arg0);
            WebElement cuadroinput = existeElemento("//label[contains(text(),'Monto en')]", 2);
            validaElemento(cuadroinput, "cuadro de input con el monto", 2, false);
            PdfBciReports.addWebReportImage("Pantalla datos de tu inversión", "Se ingresa el monto en la pantalla datos de tu inversión", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElCampoTengaData(String arg0) {
        esperar(5);
        try {
            if (visualizarObjetoScroll(unaCuenta, 3)) {
                PdfBciReports.addWebReportImage("Campo cuenta de cargo", "Se valida que el campo cuenta de cargo está y contiene una sola cuenta la siguiente data " + unaCuenta.getText(), EstadoPrueba.PASSED, false);
            } else {
                visualizarObjetoScroll(variasCuentas, 3);
                PdfBciReports.addWebReportImage("Campo cuenta de cargo", "Se valida que el campo cuenta de cargo está y contienen dos o más cuentas  con la siguiente data a la vista " + variasCuentas.getText(), EstadoPrueba.PASSED, false);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validoQueElCampoContengaElCampoConUnCorreo(String arg0) {
        try {
            esperar(15);
            WebElement inputCorreo = existeElemento("//input[@type='email']", 3);
            validaElemento(inputCorreo, "input de correo", 3, false);
            inputCorreo.getText();
            PdfBciReports.addWebReportImage("Input de Correo", "Se valida que el input de correo contiene el siguiente correo ingresado " + inputCorreo.getText(), EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElCheckDe(String arg0) {
        try {
            esperar(2);
            WebElement elemento = existeElemento("//label[@for='bci-wk-checkbox0']", 3);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Check de " + arg0, "Se presiona el check de Acepto con el siguiente discleimer : \n " + elemento.getText(), EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            elemento.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonDeEnLaPantalla(String arg0, String arg1) {
        try {
            if (visualizarObjetoScroll(botonInvertirComparado, 3)) {
                PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + " dentro del comparador", EstadoPrueba.PASSED, false);
                botonInvertirComparado.click();
            } else {
                visualizarObjetoScroll(btnInvertirVitrina, 3);
                PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + " en la pantalla " + arg1, EstadoPrueba.PASSED, false);
                btnInvertirVitrina.click();
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoDeFormaCorrectaElModalDeInversion(String arg0) {
        try {
            esperar(24);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeMedallia);
            scrollAlElementoConJavascript(iframeMedallia);
            WebElement marco = existeElemento("//div[@class='modal-live-form ng-scope']", 3);
            UtilsWeb.enmarcarObjeto(marco);
            PdfBciReports.addWebReportImage("Encuesta Medallia", "Se visualiza la encuesta Medallia", EstadoPrueba.PASSED, false);
            visualizarObjeto(enviarEncuesta, 3);
            visualizarObjeto(cincoestrellas, 3);
            visualizarObjeto(cerrarEncuestaMedallia, 3);
            visualizarObjeto(preguntaInicialMedallia, 3);
            esperar(1);
            UtilsWeb.desenmarcarObjeto(marco);
            PdfBciReports.addWebReportImage("Cierre encuesta Medallia", "Se cierra la encuesta Medallia", EstadoPrueba.PASSED, false);
            esperar(1);
            clickElemento(cerrarEncuestaMedallia, "cierra encuesta", "se cierra encuesta");
            esperar(4);
            DriverContextWeb.getDriverWeb().switchTo().parentFrame();
            WebElement elemento = existeElemento("//p[@class='confirmation-header_title bci-wk-h1000']", 3);
            visualizarObjetoScroll(elemento, 2);
            validaElemento(elemento, "modal de inversión", 2, true);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElCampoEnElComprobante(String arg0) {
        try {
            switch (arg0) {
                case "Monto invertido":
                case "Monto Invertido":
                    WebElement elemento = existeElemento("//p[contains(text(),'Monto invertido')]", 2);
                    elemento.getText();
                    visualizarObjetoScroll(elemento, 2);
                    WebElement monto = existeElemento("//p[@class='wk-text-green-500 bci-wk-h600']", 3);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + monto.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Fondo":
                    WebElement Fm = existeElemento("(//p[contains(text(),'Fondo')])[2]", 2);
                    Fm.getText();
                    WebElement fondo = existeElemento("//span[normalize-space()='Dolar Cash'] ", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + fondo.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Cuenta de cargo":
                    WebElement ct = existeElemento("//p[contains(text(),'Cuenta de cargo')]", 2);
                    ct.getText();
                    visualizarObjetoScroll(ct, 2);
                    WebElement cuenta = existeElemento("//span[@id='accountClient'] ", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + cuenta.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Cuenta de fondo":
                case "Cuenta de Fondo Mutuo":
                    WebElement cf = existeElemento("//p[contains(text(),'Cuenta de Fondo Mutuo')]", 2);
                    cf.getText();
                    WebElement cuentaFondo = existeElemento("//span[@id='investmentObjective']", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + cuentaFondo.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Fecha de solicitud":
                    WebElement sol = existeElemento("//p[contains(text(),'Fecha de solicitud')]", 2);
                    sol.getText();
                    WebElement solicitud = existeElemento("///span[@id='dateTime'] ", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + solicitud.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "N° de folio":
                    WebElement fol = existeElemento("//p[contains(text(),' Nº de folio ')]", 2);
                    fol.getText();
                    WebElement folio = existeElemento("//span[@id='folio']", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + folio.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Descargar PDF":
                    WebElement descargar = existeElemento("//span[normalize-space()='Descargar PDF']", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + descargar.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Monto a invertir":
                    WebElement montoInvertir = existeElemento("//p[contains(text(),'Monto a invertir')]", 2);
                    montoInvertir.getText();
                    WebElement montov = existeElemento("//p[@class='wk-text-green-500 bci-wk-h600']", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + montov, EstadoPrueba.PASSED, false);
                    break;
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElCampoDeEnElComprobante(String arg0) {
        try {
            switch (arg0) {
                case "Monto invertido":
                    WebElement elemento = existeElemento("//p[contains(text(),'Monto invertido')]", 2);
                    elemento.getText();
                    visualizarObjetoScroll(elemento, 2);
                    WebElement monto = existeElemento("//p[@class='wk-text-green-500 bci-wk-h600']", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + monto.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Fondo":
                case "Fondo Mutuo":
                    WebElement Fm = existeElemento("//p[contains(text(),'Fondo Mutuo')]", 2);
                    Fm.getText();
                    visualizarObjetoScroll(Fm, 2);
                    WebElement fondo = existeElemento("(//span[@class='normal grey-lighten-text'])[1]", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + fondo.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Cuenta de cargo":
                    WebElement ct = existeElemento("//p[contains(text(),'Monto invertido')]", 2);
                    ct.getText();
                    WebElement cuenta = existeElemento("//span[@id='accountClient'] ", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + cuenta.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Cuenta de fondo":
                case "Cuenta de Fondo Mutuo":
                    WebElement cf = existeElemento("(//p[contains(text(),'Cuenta de ')])[2]", 2);
                    cf.getText();
                    WebElement cuentaFondo = existeElemento("//span[@id='investmentObjective']", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + cuentaFondo.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Fecha de solicitud":
                    WebElement sol = existeElemento("//p[contains(text(),'Fecha de solicitud')]", 3);
                    sol.getText();
                    WebElement solicitud = existeElemento("//span[@id='dateTime'] ", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + solicitud.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "N° de folio":
                    WebElement fol = existeElemento("//p[contains(text(),' Nº de folio ')]", 2);
                    fol.getText();
                    WebElement folio = existeElemento("//span[@id='folio']", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + folio.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Descargar PDF":
                    WebElement descargar = existeElemento("//span[normalize-space()='Descargar PDF']", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + descargar.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Monto a invertir":
                    WebElement montoInvertir = existeElemento("//p[contains(text(),'Monto invertido')]", 2);
                    montoInvertir.getText();
                    WebElement montov = existeElemento("//p[@class='wk-text-green-500 bci-wk-h600']", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + montov.getText(), EstadoPrueba.PASSED, false);
                    break;
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElBotonEnElComprobante(String arg0) {
        try {
            switch (arg0) {
                case "Descargar PDF":
                case "Descargar comprobante":
                    WebElement descargar = existeElemento("//span[normalize-space()='" + arg0 + "']", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + descargar.getText(), EstadoPrueba.PASSED, false);
                    break;
                case "Monto a invertir":
                    WebElement montoInvertir = existeElemento("//p[contains(text(),'Monto a invertir')]", 2);
                    montoInvertir.getText();
                    WebElement montov = existeElemento("//p[@class='wk-text-green-500 bci-wk-h600']", 2);
                    PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + montov, EstadoPrueba.PASSED, false);
                    break;
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoBotonEnElComprobante(String arg0) {
        try {
            WebElement btnVolver = existeElemento("//button[@class='bci-wk-btn bci-wk-btn--primary']", 3);
            scrollAlElementoConJavascript(btnVolver);
            PdfBciReports.addWebReportImage("Botón Volver a fondos Mutuos", "Se valida el botón de " + arg0 + " en el comprobante", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoBotonEnElComprobante(String arg0) {
        try {
            WebElement btnVolver = existeElemento("//button[@class='bci-wk-btn bci-wk-btn--primary']", 2);
            UtilsWeb.enmarcarObjeto(btnVolver);
            PdfBciReports.addWebReportImage("Botón volver", "Se presiona " + arg0 + " en vista de comprobante", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(btnVolver);
            btnVolver.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoVitrinaDe(String arg0) {
        try {
            switch (arg0) {
                case "Fondos en moneda Nacional":
                    WebElement elemento = existeElemento("//*[normalize-space()='Inversión en pesos']", 1);
                    visualizarObjetoScroll(elemento, 1);
                    esperar(4);
                    validaElemento(elemento, "vista Inversión", 1, true);
                    PdfBciReports.addWebReportImage("Vista vitrina ", "Se visualiza la vitrina de fondos mutuos en pesos", EstadoPrueba.PASSED, false);
                    esperar(1);
                    break;
                case "Carteras Dólar":
                case "Inversión en pesos":
                case "Inversión en dólares":
                    WebElement element = existeElemento("//*[normalize-space()='" + arg0 + "']", 1);
                    visualizarObjetoScroll(element, 1);
                    esperar(4);
                    validaElemento(element, "vista Inversión", 1, true);
                    PdfBciReports.addWebReportImage("Vista vitrina ", "Se visualiza la vitrina de fondos mutuos en pesos", EstadoPrueba.PASSED, false);
                    esperar(1);
                    break;
                case "Fondos en moneda USA":
                    WebElement elemen = existeElemento("//*[normalize-space()='Inversión en dólares']", 1);
                    visualizarObjetoScroll(elemen, 1);
                    esperar(4);
                    validaElemento(elemen, "vista Inversión", 1, true);
                    PdfBciReports.addWebReportImage("Vista vitrina ", "Se visualiza la vitrina de fondos mutuos en pesos", EstadoPrueba.PASSED, false);
                    esperar(1);
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoMensajeDeError(String arg0) {
        try {
            esperar(2);
            WebElement elemento = existeElemento("//span[contains (text(),'" + arg0 + "')]", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Mensaje error input monto", "Se visualiza el siguiente mensaje de error bajo el input de monto : " + arg0, EstadoPrueba.PASSED, false);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validoQueElCampoContengaSoloCuentasEnDolar(String arg0) {
        try {
            esperar(5);
            //DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
            WebElement elemento = existeElemento("//bci-wk-select[@class='width-element investment-element-charge default ng-untouched ng-pristine ng-valid']//select", 3);
            elemento.click();
            PdfBciReports.addWebReportImage("Campo cuentas de cargo", "Se valida que el selector de cuentas de cargo solo contiene cuentas Dólar", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoCuentaEnUSD(String arg0) {
        try {
            WebElement elemento = existeElemento("//option[contains(text(),'" + arg0 + "')]", 3);
            validaElemento(elemento, "cuenta de cargo USD ", 2, true);
            PdfBciReports.addWebReportImage("Campo cuenta de cargo USD", "Se valida que existe la cuenta de USD " + arg0, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElTituloDelFondo(String arg0, String arg1, String arg2) {
        try {
            esperar(5);
            WebElement elemento = existeElemento("//span[normalize-space()='" + arg0 + "']", 3);
            visualizarObjetoScroll(elemento, 2);
            esperar(2);
            WebElement invierte = existeElemento("//span[contains (text(),'" + arg0 + "')]//ancestor::bci-card//descendant::span[contains(text(),'" + arg1 + "')]", 2);
            visualizarObjetoScroll(invierte, 2);
            esperar(2);
            WebElement how = existeElemento("//span[contains (text(),'" + arg0 + "')]//ancestor::bci-card//descendant::span[contains(text(),'" + arg2 + "')]", 2);
            visualizarObjetoScroll(how, 2);
            PdfBciReports.addWebReportImage("Vitrina de fondo dolar", "Se visualizan el nombre del fondo " + arg0 + " el " + arg1 + " y el monto " + arg2, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueNoExistaElFiltroCuandoHaySoloUnFFMMM() {
        try {
            noExiste("//button[@name='filterControl']");
            PdfBciReports.addWebReportImage("Elemento Filtro de fondos", "Se valida que no se ha encontrado el filtro ", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueSoloSeVisualiceEnLaVitrina(String arg0) {
        try {
            WebElement elemento = existeElemento("//span[normalize-space()='" + arg0 + "']", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Nombre vitrina", "Se visualiza el nombre de la vitrina de fondos mutuos", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueExistaElFiltroCuandoHayVariosFondosMutuos() {
        try {
            WebElement elemento = existeElemento("//button[@name='filterControl']", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Filtro fondos", "Se visualiza el filtro de fondos", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElFiltro(String arg0) {
        try {
            WebElement elemento = existeElemento("//button[@name='filterControl']", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Filtro fondos", "Se presiona el filtro de fondos", EstadoPrueba.PASSED, false);
            elemento.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoEnLaOpcionDeFiltraPorPerfilDeRiesgo(String arg0) {
        try {
            WebElement elemento = existeElemento("//label[contains (text(),'" + arg0 + "')]", 3);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Opción filtro por Perfil de riesgo", "Se selecciona el label del perfil de riesgo  " + arg0, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            elemento.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoLaCarteraDeEnINVERSIONENDOLARES(String arg0) {
        try {
            WebElement elemento = existeElemento("//span[normalize-space()='" + arg0 + "']", 3);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Nombre fondo", "Se visualiza el nombre de la vitrina de fondos mutuos", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoEnLaPaginaTexto(String arg0) {
        try {
            WebElement elemento = existeElemento("//p[@class='subtitle-noperfilado']", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Cliente no perfilado", "Se visualiza texto superior de cliente no perfilado", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoBoton(String arg0) {
        try {
            WebElement elemento = existeElemento("//p[@class='back-profiling bci-wk-h400']", 3);
            visualizarObjetoScroll(elemento, 1);
            PdfBciReports.addWebReportImage("Icono perfilarse", "Se visualiza el icono de perfilarse", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoModalDeClienteSinPerfil(String arg0, String arg1) {
        try {
            WebElement elemento = existeElemento("//div[@class='modal-buttons']", 3);
            validaElemento(elemento, "Modal de cliente sin perfil", 2, false);
            WebElement close = existeElemento("//em[@class='material-icons']", 1);
            visualizarObjetoScroll(close, 2);
            PdfBciReports.addWebReportImage("Modal cliente sin perfil", "Se visualiza modal de cliente sin perfilamiento " + arg0 + " y menciona lo siguiente : \n " + arg1, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueDentroDelModalExistaBoton(String arg0) {
        try {
            WebElement elemento = existeElemento("//button[contains (text(),'" + arg0 + "')]", 3);
            validaElemento(elemento, "botón dentro de modal", 2, false);
            PdfBciReports.addWebReportImage("Botón dentro de modal", "Se visualiza el botón " + arg0 + "dentro del modal", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoCampoCuantoQuieresInvertirDebeIndicar(String arg0) {
        try {
            esperar(5);
            WebElement elemento = existeElemento("//label[contains (text(),'¿Cuánto quieres invertir?')]", 3);
            visualizarObjetoScroll(elemento, 2);
            WebElement usd = existeElemento("//input[@type='text']", 2);
            visualizarObjetoScroll(usd, 2);
            WebElement span = existeElemento("//span[@class='divisa-2']", 2);
            UtilsWeb.enmarcarObjeto(span);
            PdfBciReports.addWebReportImage("Campo cuanto quieres invertir", "Valido que el campo ¿Cuánto quieres invertir? indica " + arg0 + " el input devuelve " + span.getText(), EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(span);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoMontoAInvertir(String arg0) {
        try {
            WebElement elemento = existeElemento("//span[@class='title grey-text']", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Monto a invertir en pantalla confirma tu inversión  en " + arg0, "Se visualiza que el monto en pantalla indica " + elemento.getText(), EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElCampoMontoInvertidoEnElComprobanteDebeIndicarEn(String arg0) {
        try {
            WebElement elemento = existeElemento("//p[contains(text(),'Monto invertido')]", 2);
            elemento.getText();
            visualizarObjetoScroll(elemento, 2);
            WebElement monto = existeElemento("//span[@id='amountInvested'] ", 2);
            PdfBciReports.addWebReportImage("Item del comprobante", "Se valida el Item " + arg0 + " con el valor  " + monto.getText(), EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoModalFueraDeHorarioAM() {
        try {
            WebElement elemento = existeElemento("//p[contains(text(),'El horario para invertir en dólares es de 9:00 a 14:00 horas en días hábiles. No será posible hacerlo fuera de este horario.')]", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Modal fuera de horario AM", "Se visualiza el modal fuera de horario por AM", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoModalFueraDeHorarioPM() {
        try {
            WebElement elemento = existeElemento("//p[contains(text(),'El horario para invertir en dólares es de 9:00 a 14:00 horas en días hábiles. No será posible hacerlo fuera de este horario.')]", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Modal fuera de horario PM", "Se visualiza el modal fuera de horario por AM", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoModalFueraDeHorarioFestivos() {
        try {
            WebElement elemento = existeElemento("//p[contains(text(),'El día de hoy no es posible invertir en dólares debido a que es feriado en Estados Unidos. Si deseas, puedes invertir en Fondos Mutuos en pesos.')]", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Modal fuera de horario festivos", "Se visualiza el modal fuera de horario por Festivo en EEUU", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoModalRiesgoPerfilMayorACliente() {
        try {
            esperar(3);
            WebElement check = existeElemento("//div[@class='wk-padding-all-24']", 5);
            visualizarObjetoScroll(check, 2);
            UtilsWeb.enmarcarObjeto(check);
            PdfBciReports.addWebReportImage("Modal Riesgo de perfil mayor", "Se visualiza modal de perfil mayor riesgo al del cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(check);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoTitulo(String arg0, String arg1) {
        try {
            esperar(3);
            WebElement elemento = existeElemento("//h2[@class='modal-title']", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Modal de invertir en perfil superior a mi perfil de riesgo", "Se visualiza Modal con el titulo : " + arg0 + " \n " + arg1, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoFlujoEnUSD() {
        try {
            esperar(50);
            WebElement elemento = existeElemento("//p[@class='text-thinner bci-wk-h300']", 3);
            validaElemento(elemento, "Estás invirtiendo en: ", 2, false);
            WebElement subtitulo = existeElemento("//p[@class='wk-margin-bottom-24 text-darker bci-wk-h700']", 2);
            validaElemento(subtitulo, "Nombre del fondo", 2, false);
            WebElement mensaje = existeElemento("//div[@class='wk--text-grey-400 wk-margin-top-24 bci-wk-h400']", 2);
            validaElemento(mensaje, "Mensaje Para invertir en Fondos Mutuos con cargo a tu cuenta corriente en dólares, completa tus datos en el formulario.", 2, false);
            PdfBciReports.addWebReportImage("Flujo USD", "Se visualizan los elementos de la vista flujo USD Pantalla Datos de tu inversión", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoTituloDebeIndicar(String arg0) {
        try {
            WebElement elemento = existeElemento("//p[contains (text(),'" + arg0 + "')]", 3);
            validaElemento(elemento, "nombre fondo en titulo", 2, false);
            PdfBciReports.addWebReportImage("nombre Fondo", "Se visualiza el nombre del Fondo " + arg0, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueElPrimerFondoMutuoSeaDePerfil(String arg0) {
        try {
            WebElement perfil = existeElemento("(//div[normalize-space()='" + arg0 + "'])[1]", 3);
            scrollAlElementoConJavascript(perfil);
            PdfBciReports.addWebReportImage("Perfil de la primera cartera", "Se valida que el perfil de la  primera Cartera es " + arg0, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoNombreDeLaCartera(String arg0) {
        try {
            WebElement elemento = existeElemento("//span[normalize-space()='" + arg0 + "']", 3);
            scrollAlElementoConJavascript(elemento);
            PdfBciReports.addWebReportImage("Nombre de la Cartera", "Se valida el nombre de la Cartera " + arg0, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoBotonInvertirInhabilitado(String arg0) {
        try {
            esperar(2);
            WebElement btnInhabil = existeElemento("//*[@id=\"content\"]/app-root/app-store/div/div[1]/div/app-mutual-funds-card/div/div[1]/bci-card/div[2]/div[6]/button", 3);
            visualizarObjetoScroll(btnInhabil, 2);
            PdfBciReports.addWebReportImage("Botón de invertir deshabilitado", "El botón de invertir se encuentra deshabilitado en el  Tab de Inversión en Dólares", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueElPrimerFondoMutuoSeaPerfil(String arg0) {
        try {
            WebElement elemento = existeElemento("//span[normalize-space()='" + arg0 + "']", 3);
            scrollAlElementoConJavascript(elemento);

            PdfBciReports.addWebReportImage("Perfil de la primera cartera", "Se valida que el perfil de la  primera Cartera es " + arg0, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoInvertirEnFondoMutuo(String arg0) {
        try {
            esperar(4);
            WebElement invertir = existeElemento("//span[contains (text(),'" + arg0 + "')]//ancestor::bci-card//descendant::button[contains(text(),'Invertir')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón invertir fondo mutuo", "Se selecciona boton de invertir en el fondo  " + arg0, EstadoPrueba.PASSED, false);
            invertir.click();
            UtilsWeb.desenmarcarObjeto(invertir);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoBotonDeEnPantallaDeComparacionEnElFondo(String arg0, String arg1) {
        try {
            esperar(7);
            WebElement invertir = existeElemento("//div[contains (text(),'" + arg1 + "')]//ancestor::app-mutual-fund-comparator-card-comparator//descendant::button[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón invertir fondo mutuo", "Se selecciona boton de " + arg0 + " en el fondo  " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(invertir);
            invertir.click();
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoPantallaDe(String arg0) {
        try {
            esperar(15);
            WebElement elemento = existeElemento("//h5[normalize-space()='" + arg0 + "']", 3);
            visualizarObjetoScroll(elemento, 2);
            validaElemento("//p[contains (text(),'Revisa los indicadores de cada')]", 2);
            validaElemento("//div[normalize-space()='Gráfico comparativo de rentabilidades nominales acumuladas de 36 meses.']", 2);
            PdfBciReports.addWebReportImage("Pantalla de comparador de fondos", "Se visualiza el  " + arg0, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElBotonEnElCarritoDeshabilitado(String arg0) {
        try {
            WebElement elemento = existeElemento("//button[@class='compare bci-wk-btn bci-wk-btn--primary'][@disabled]", 3);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Botón comparar del carrito comparador de fondos", "Se visualiza el botón " + arg0 + " deshabilitado", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe("Se presenta una EXCEPCION:" + e);
            reporteConYSinImagen(true, "Se presenta una EXCEPCION en:  visualizoPantallaDe " + arg0, "Se presenta una EXCEPCION:" + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueElBotonDeInvertirEnElFondoSeEncuentreDeshabilitado(String arg0) {
        try {
            switch (arg0) {
                case "Retorno Dólar IG":
                case "Retorno Dolar IG":
                    visualizarObjetoScroll(INVcomparaUsddesa1, 3);
                    UtilsWeb.enmarcarObjeto(INVcomparaUsddesa1);
                    PdfBciReports.addWebReportImage("Botón invertir desde comparar", "Botón invertir desde fondo " + arg0 + " deshabilitado", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(INVcomparaUsddesa1);
                    break;
                case "USA":
                    visualizarObjetoScroll(INVcomparaUsddesa2, 3);
                    UtilsWeb.enmarcarObjeto(INVcomparaUsddesa2);
                    PdfBciReports.addWebReportImage("Botón invertir desde comparar", "Botón invertir desde fondo " + arg0 + " deshabilitado", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(INVcomparaUsddesa2);
                    INVcomparaUsddesa2.click();
                    break;
                case "Dólar Cash":
                case "Dolar Cash":
                    visualizarObjetoScroll(INVcomparaUsddesa3, 3);
                    UtilsWeb.enmarcarObjeto(INVcomparaUsddesa3);
                    PdfBciReports.addWebReportImage("Botón invertir desde comparar", "Botón invertir desde fondo " + arg0 + " deshabilitado", EstadoPrueba.PASSED, false);
                    UtilsWeb.desenmarcarObjeto(INVcomparaUsddesa3);
                    INVcomparaUsddesa3.click();
                    break;
            }
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElModalCorrespondienteAlCliente(String arg0) {
        try {
            esperar(20);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoPrimeraPantalla(String arg0) {
        try {
            esperar(20);
            WebElement cuadroinput = existeElemento("//label[normalize-space()='¿Cuánto quieres invertir?']", 2);
            validaElemento(cuadroinput, "cuadro de input con la frase : ¿Cuánto quieres invertir?", 2, false);
            PdfBciReports.addWebReportImage("Pantalla datos de tu inversión", "Se ingresa a la pantalla  " + arg0, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void borroElCampoConElMontoAsignado() {
        try {
            inputMontoInvertir.clear();
            PdfBciReports.addWebReportImage("Pantalla datos de tu inversión", "Se borra el monto en la pantalla datos de tu inversión", EstadoPrueba.PASSED, false);
            if (visualizarObjetoScroll(btnContinu, 2)) {
                PdfBciReports.addWebReportImage("Click a continuar", "Se da click a continuar", EstadoPrueba.PASSED, false);
                btnContinu.click();
            } else {
                visualizarObjetoScroll(btnContinuar, 2);
                PdfBciReports.addWebReportImage("Click a continuar", "Se da click a continuar", EstadoPrueba.PASSED, false);
                btnContinuar.click();
            }
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoModalDe(String arg0) {
        try {
            esperar(3);
            WebElement elemento = existeElemento("//p[@class='sam-title']", 3);
            visualizarObjetoScroll(elemento, 2);
            WebElement subtitle = existeElemento("//p[@class='sam-description']", 2);
            PdfBciReports.addWebReportImage("Modal " + arg0, "Se visualiza el modal  " + arg0 + " y contiene el mensaje  \n " + elemento.getText() + "\n " + subtitle.getText(), EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizo(String arg0, String arg1) {
        try {
            esperar(5);
            WebElement elemento = existeElemento("//p[@class='alert__text']", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Modal " + arg0 + " de  " + arg1, "Se visualiza el modal  " + arg0 + " y contiene el mensaje  \n " + elemento.getText(), EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElCheckDeEn(String arg0, String arg1) {
        try {
            esperar(10);
            WebElement compara = existeElemento("//span[contains (text(),'" + arg1 + "')]//ancestor::bci-card//descendant::span[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']", 2);
            visualizarObjetoScroll(compara, 2);
            UtilsWeb.enmarcarObjeto(compara);
            PdfBciReports.addWebReportImage("Check compara fondo dólar", "Se selecciona check de " + arg0 + "  en el fondo " + arg1, EstadoPrueba.PASSED, false);
            compara.click();
            UtilsWeb.desenmarcarObjeto(compara);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void resumenDeInversiones(String arg0) {
        try {
            switch (arg0) {
                case "Conocer después":
                    visualizarObjetoScroll(btnConocerDespues, 2);
                    PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + "", EstadoPrueba.PASSED, false);
                    btnConocerDespues.click();
                    break;
                case "Mis Carteras Dinámicas y Patrimoniales":
                    visualizarObjetoScroll(btnCarteraDesplegable, 2);
                    PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + "", EstadoPrueba.PASSED, false);
                    btnCarteraDesplegable.click();
                    break;
                case "Cartera Dinámica Corto Plazo Serie Clásica":
                    visualizarObjetoScroll(btnCtaCero, 2);
                    PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + "", EstadoPrueba.PASSED, false);
                    btnCtaCero.click();
                    break;
                case "RESCATAR":
                    visualizarObjetoScroll(btnRescatarResumen, 2);
                    PdfBciReports.addWebReportImage("Botón " + arg0 + " habilitado", "Botón " + arg0 + " se encuentra habilitado", EstadoPrueba.PASSED, false);
                    btnRescatarResumen.isEnabled();
                    break;
                case "TRASPASAR":
                    GenericValidations.validarElemento(btnTraspasarResumen, 3, false, "boton rescatar en resumen");
                    PdfBciReports.addWebReportImage("Botón " + arg0 + " habilitado", "Botón " + arg0 + " se encuentra habilitado", EstadoPrueba.PASSED, false);
                    btnTraspasarResumen.isEnabled();
                    break;
                case "INVERTIR MÁS":
                    visualizarObjetoScroll(btnInvertirMas, 2);
                    PdfBciReports.addWebReportImage("Botón " + arg0 + " habilitado", "Botón " + arg0 + " se encuentra habilitado", EstadoPrueba.PASSED, false);
                    btnInvertirMas.isEnabled();
                    break;
                case "Mis Fondos Mutuos":
                    GenericValidations.validarElemento(btnDesplegableFFMM, 3, false, "boton rescatar en resumen");
                    PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + "", EstadoPrueba.PASSED, false);
                    btnDesplegableFFMM.click();
                    break;
                case "Fm Bci Retorno Dolar Ig Serie Clásica":
                    GenericValidations.validarElemento(btnCtaCero, 3, false, "boton de bci retorno dolar ig");
                    PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + "", EstadoPrueba.PASSED, false);
                    btnCtaCero.click();
                    break;
                case "Invertir en otros fondos":
                    GenericValidations.validarElemento(btnInvertirEnOtrosFondosCartera, 3, false, "boton invertir en otros fondos");
                    PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + "", EstadoPrueba.PASSED, false);
                    btnInvertirEnOtrosFondosCartera.isEnabled();
                    break;
            }
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void esperando() {
        try {
            esperar(120);
        } catch (Exception e) {
            LOGGER.severe("Se presenta una EXCEPCION:" + e);
            reporteConYSinImagen(true, "Se presenta una EXCEPCION en: esperando ", "Se presenta una EXCEPCION:" + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElModalEnLaVitrina(String arg0, String arg1) {
        try {
            esperar(5);
            WebElement elemento = existeElemento("//p[contains(text(),'" + arg1 + "')]", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Modal " + arg0, "Se visualiza el modal  " + arg0 + " y contiene el mensaje  \n " + arg1, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElBotonSeEncuentreHabilitadoDentroDelModal(String arg0) {
        try {
            esperar(7);
            WebElement elemento = existeElemento("//button[contains(text(),'" + arg0 + "')]", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Modal " + arg0, "Se visualiza el modal  " + arg0 + " y contiene el mensaje  \n " + arg0, EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonQueSeEncuentraDentroDelModal(String arg0) {
        try {
            esperar(5);
            WebElement elemento = existeElemento("//button[contains(text(),'" + arg0 + "')]", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Botón " + arg0, "Se visualiza el botón  " + arg0 + " y contiene el mensaje  \n " + arg0, EstadoPrueba.PASSED, false);
            elemento.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoTitulo(String arg0) {
        try {
            switch (arg0) {
                case "Cartera Dinámica Corto Plazo Serie Clásica":
                    visualizarObjetoScroll(btnCtaCero, 2);
                    PdfBciReports.addWebReportImage("Titulo " + arg0 + " habilitado", "Titulo " + arg0 + " se encuentra habilitado", EstadoPrueba.PASSED, false);
                    esperar(3);
                    break;
                case "Fm Bci Retorno Dolar Ig Serie Clásica":
                    visualizarObjetoScroll(btnCtaCero, 2);
                    PdfBciReports.addWebReportImage("Titulo " + arg0 + " habilitado", "Titulo " + arg0 + " se encuentra habilitado", EstadoPrueba.PASSED, false);
                    esperar(2);
                    break;
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonCheckboxDeDeclaro() {
        try {
            esperar(2);
            if (visualizarObjetoScroll(check, 3)) {
                UtilsWeb.enmarcarObjeto(check);
                PdfBciReports.addWebReportImage("Presiono check", "Se presiona check  ", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(check);
                check.click();
            } else {
                visualizarObjetoScroll(checkk, 3);
                UtilsWeb.enmarcarObjeto(checkk);
                PdfBciReports.addWebReportImage("Presiono check", "Se presiona check ", EstadoPrueba.PASSED, false);
                UtilsWeb.desenmarcarObjeto(checkk);
                checkk.click();
            }
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonDeDentroDelSaberMas(String arg0) {
        try {
            esperar(3);
            WebElement elemento = existeElemento("(//button[contains(text(),'" + arg0 + "')])[1]", 3);
            visualizarObjetoScroll(elemento, 2);
            PdfBciReports.addWebReportImage("Botón " + arg0, "Se visualiza el botón  " + arg0 + " que contiene el saber más ", EstadoPrueba.PASSED, false);
            elemento.click();
            esperar(4);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoQueLosBotonesDeInvertirSeEncuentrenDeshabilitado() {
        try {
            esperar(4);
            existeElemento("(//button[@class='bci-wk-btn bci-wk-btn--primary'][normalize-space()='Invertir'])[1]", 3);
            existeElemento("(//button[@class='bci-wk-btn bci-wk-btn--primary'][normalize-space()='Invertir'])[2]", 3);
            PdfBciReports.addWebReportImage("Botón de invertir deshabilitado", "El botón de invertir se encuentra deshabilitado en el  Tab de Inversión en Dólares", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElComprobanteDeFormaCorrecta() {
        try {
            WebElement total = existeElemento("//p[@class='confirmation-header_title bci-wk-h1000']", 3);
            visualizarObjetoScroll(total, 3);
            PdfBciReports.addWebReportImage("Comprobante de inversión", "Se visualiza el comprobante de inversión", EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validoDocumentoAdjunto(String arg0) {
        try {
            WebElement documento = existeElemento("//span[normalize-space()='Contrato General de Fondos']", 3);
            visualizarObjetoScroll(documento, 3);
            PdfBciReports.addWebReportImage("Confirma tu inversión " + arg0, "Se visualiza el titulo en la pantalla de confirma  tu inversión : " + documento.getText(), EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoTituloEnPantallaConfirmaTuInversion(String arg0) {
        try {
            WebElement titulo = existeElemento("//p[@class='medium grey-text bci-wk-h450']", 3);
            visualizarObjetoScroll(titulo, 3);
            WebElement subtitulo = existeElemento("//p[contains(text(),'Revisa la documentación legal e informativa de tu inversión a continuación:')]", 3);
            visualizarObjetoScroll(subtitulo, 3);
            PdfBciReports.addWebReportImage("Confirma tu inversión", "Se visualiza el titulo en la pantalla de confirma  tu inversión : " + arg0, EstadoPrueba.PASSED, false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoCheckboxDeContratoGeneralDeFondos(String arg0) {
        try {
            esperar(2);
            WebElement elemento = existeElemento("//label[@for='bci-wk-checkbox0']", 3);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Check de : \n" + arg0, "Se valida el check de Acepto con el siguiente discleimer : \n " + elemento.getText(), EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoBotonInvertirEnFondoMutuoPerfilConservador(String arg0) {
        try {
            esperar(10);
            WebElement invertir = existeElemento("//span[contains (text(),'" + arg0 + "')]//ancestor::bci-card//descendant::button[contains(text(),'Invertir')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón invertir fondo mutuo", "Se selecciona boton de invertir en el fondo  " + arg0, EstadoPrueba.PASSED, false);
            invertir.click();
            UtilsWeb.desenmarcarObjeto(invertir);
            esperar(1);

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoBotonInvertirEnFondoMutuoPerfilMuyAgresivo(String arg0) {
        try {
            esperar(10);
            WebElement invertir = existeElemento("//span[contains (text(),'" + arg0 + "')]//ancestor::bci-card//descendant::button[contains(text(),'Invertir')]", 2);
            visualizarObjetoScroll(invertir, 2);
            UtilsWeb.enmarcarObjeto(invertir);
            PdfBciReports.addWebReportImage("Botón invertir fondo mutuo", "Se selecciona boton de invertir en el fondo  " + arg0, EstadoPrueba.PASSED, false);
            invertir.click();
            UtilsWeb.desenmarcarObjeto(invertir);
            esperar(1);

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonDeDesdeComparar(String arg0) {
        try {
            visualizarObjetoScroll(botonInvertirComparado, 3);
            PdfBciReports.addWebReportImage("Click a " + arg0 + "", "Se da click a " + arg0 + " dentro del comparador", EstadoPrueba.PASSED, false);
            botonInvertirComparado.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }

    }

    public void visualizoElMensajeDeAlertaCorrespondienteAlClienteSinCuentaUsd(String arg0) {
        try {
            esperar(10);
            WebElement elemento = existeElemento("//p[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoDeFormaCorrectaElBotonSeEncuentreDeshabilitado(String arg0) {
        try {
            esperar(2);
            WebElement btnInhabil = existeElemento("//*[@id=\"content\"]/app-root/app-store/div/div[1]/div/app-mutual-funds-card/div/div[1]/bci-card/div[2]/div[6]/button", 3);
            visualizarObjetoScroll(btnInhabil, 2);
            PdfBciReports.addWebReportImage("Botón de invertir deshabilitado", "El botón de invertir se encuentra deshabilitado en el  Tab de Inversión en Dólares", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElMensajeDeAlertaCorrespondienteAlCliente(String arg0) {
        try {
            esperar(10);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElModalNoDisponibleCorrespondiente(String arg0, String arg1) {
        try {
            esperar(10);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + " a cliente  " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void visualizoElModalCorrespondienteAlClienteEnVitrina(String arg0) {
        try {
            esperar(12);
            WebElement elemento = existeElemento("//*[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Modal", "Se visualiza el modal " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validoBotonDentroDeLaPantallaDeConfirmacion(String arg0) {
        try {
            WebElement btnVolver = existeElemento("//button[@class='bci-wk-btn bci-wk-btn--primary']", 3);
            scrollAlElementoConJavascript(btnVolver);
            PdfBciReports.addWebReportImage("Botón Volver a fondos Mutuos", "Se valida el botón de " + arg0 + " en el comprobante", EstadoPrueba.PASSED, false);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElCampoEnRangoValidoFFMMUSD(String arg0) {
        esperar(15);
        try {
            WebElement select = existeElemento("//bci-wk-select[@class='width-element default ng-untouched ng-pristine ng-valid']//select", 3);
            select.click();
            String cuenta;
            String total = "";
            for (int i = 0; i < 97; i++) {
                cuenta = capturarTexto("//option[@value='" + i + "']").trim();
                String[] arrayCuentas = cuenta.split("Cuenta ", 97);
                total = Arrays.toString(arrayCuentas);
                PdfBciReports.addReport("Validar cuenta FFMM", "Se valida la   : " + cuenta, EstadoPrueba.PASSED, false);
            }
            for (int i = 200; i < 300; i++) {
                cuenta = capturarTexto("//option[@value='" + i + "']").trim();
                String[] arrayCuentas = cuenta.split("Cuenta ", 100);
                total = Arrays.toString(arrayCuentas);
                PdfBciReports.addReport("Validar cuenta FFMM", "Se valida la   : " + cuenta, EstadoPrueba.PASSED, false);
            }
            for (int i = 400; i < 500; i++) {
                cuenta = capturarTexto("//option[@value='" + i + "']").trim();
                String[] arrayCuentas = cuenta.split("Cuenta ", 100);
                total = Arrays.toString(arrayCuentas);
                PdfBciReports.addReport("Validar cuenta FFMM", "Se valida la   : " + cuenta, EstadoPrueba.PASSED, false);
            }
            for (int i = 501; i < 600; i++) {
                cuenta = capturarTexto("//option[@value='" + i + "']").trim();
                String[] arrayCuentas = cuenta.split("Cuenta ", 199);
                total = Arrays.toString(arrayCuentas);
                PdfBciReports.addReport("Validar cuenta FFMM", "Se valida la   : " + cuenta, EstadoPrueba.PASSED, false);
            }
            for (int i = 700; i < 1000; i++) {
                cuenta = capturarTexto("//option[@value='" + i + "']").trim();
                String[] arrayCuentas = cuenta.split("Cuenta", 300);
                total = Arrays.toString(arrayCuentas);
                PdfBciReports.addReport("Validar cuentas FFMM", "Se valida la   : " + arg0 + " " + cuenta, EstadoPrueba.PASSED, false);
            }
            PdfBciReports.addReport("Validar cuentas FFMM", "Se valida la   : " + total, EstadoPrueba.PASSED, false);

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElCampoEnRangoValidoCarterasUSD(String arg0) {
        esperar(15);
        try {
            WebElement select = existeElemento("//bci-wk-select[@class='width-element default ng-untouched ng-pristine ng-valid']//select", 3);
            select.click();
            String cuenta;
            String total = "";
            for (int i = 600; i < 700; i++) {
                cuenta = capturarTexto("//option[@value='" + i + "']").trim();
                String[] arrayCuentas = cuenta.split("Cuenta ", 100);
                total = Arrays.toString(arrayCuentas);
                PdfBciReports.addReport("Validar cuentas Carteras", "Se valida la   : " + cuenta, EstadoPrueba.PASSED, false);
            }
            PdfBciReports.addReport("Validar cuentas Carteras", "Se valida la   : " + total, EstadoPrueba.PASSED, false);

        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void encuestaMedallia() {
        try {
            esperar(40);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeMedallia);
            WebElement marco = existeElemento("//div[@class='modal-live-form ng-scope']", 3);
            UtilsWeb.enmarcarObjeto(marco);
            scrollAlElementoConJavascript(closeEncuestaMedallia);
            PdfBciReports.addWebReportImage("Encuesta Medallia", "Se visualiza la encuesta Medallia", EstadoPrueba.PASSED, false);
            visualizarObjeto(enviarEncuesta, 3);
            visualizarObjeto(cincoestrellas, 3);
            visualizarObjeto(cerrarEncuestaMedallia, 3);
            visualizarObjeto(preguntaInicialMedallia, 3);
            esperar(1);
            UtilsWeb.desenmarcarObjeto(marco);
            cincoestrellas.click();
            textoEncuesta.sendKeys("Prueba QA");
            PdfBciReports.addWebReportImage("Cierre encuesta Medallia", "Se cierra la encuesta Medallia", EstadoPrueba.PASSED, false);
            enviarEncuesta.click();
            esperar(1);
            cerrarEncuestaMedallia.click();
            esperar(1);
            DriverContextWeb.getDriverWeb().switchTo().frame(iframeContenido);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoLosDatosEnLaPrimeraPantallaDolar(String arg0) {
        try {
            esperar(35);
            String monto = "50";
            inputMontoInvertir.clear();
            inputMontoInvertir.sendKeys(monto);
            PdfBciReports.addWebReportImage("Ingreso monto","Se ingresa monto en pantalla dolar : " + arg0 ,EstadoPrueba.PASSED,false);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoAlCorreoBcicert() {
        try {
            loginCorreo.loginCorreo("jpaineq", "jpaineq");
            MetodosGenericos.esperar(3);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoAsuntoCorreoFFMM() {
        try {
            String campo = "Comprobante de Solicitud de Inversion en Fondos Mutuos";
            MetodosGenericos.esperar(15);
            bandejaCorreo.asuntoCorreo(campo);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }


    public void validoEtiqueta(String arg0) {
        try {
            esperar(10);
            WebElement elemento = existeElemento("//div[contains (text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Texto", "Se visualiza el texto " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void ingresoUnSegundo(String arg0) {
        try {
            esperar(1);
            inputMontoInvertir.clear();
            inputMontoInvertir.sendKeys(arg0);
            WebElement cuadroinput = existeElemento("//label[normalize-space()='¿Cuánto quieres invertir?']", 2);
            validaElemento(cuadroinput, "cuadro de input con la frase : ¿Cuánto quieres invertir?", 2, false);
            PdfBciReports.addWebReportImage("Pantalla datos de tu inversión", "Se ingresa el monto en la pantalla datos de tu inversión", EstadoPrueba.PASSED, false);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElBotonDeSeEncuentreHabilitado(String arg0) {
        try {
            esperar(1);
            WebElement elemento = existeElemento("//button[@class='bci-wk-btn bci-wk-btn--primary']", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Boton Continuar habilitado", "Se visualiza el boton continuar habilitado " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoQueElBotonDeSeEncuentreDeshabilitado(String arg0) {
        try {
            esperar(1);
            WebElement elemento = existeElemento("//button[@class='bci-wk-btn bci-wk-btn--primary'][@disabled]", 2);
            visualizarObjetoScroll(elemento, 2);
            UtilsWeb.enmarcarObjeto(elemento);
            PdfBciReports.addWebReportImage("Boton Continuar deshabilitado", "Se visualiza el modal " + arg0 + " a cliente", EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(elemento);
            esperar(1);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void seleccionoElBotonDeVerMasEn(String arg0, String arg1) {
        try {
            esperar(2);
            WebElement vermas = existeElemento("//span[contains (text(),'" + arg1 + "')]//ancestor::bci-card//descendant::span[contains(text(),'" + arg0 + "')]", 2);
            visualizarObjetoScroll(vermas, 2);
            UtilsWeb.enmarcarObjeto(vermas);
            PdfBciReports.addWebReportImage("Botón invertir fondo mutuo", "Se selecciona boton de " + arg0 + " en el fondo  " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(vermas);
            vermas.click();
            esperar(2);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonDeEnSerie(String arg0, String arg1) {
        try {
            esperar(3);
            WebElement vermas = existeElemento("(//span[contains (text(),'" + arg1 + "')]//ancestor::bci-accordion-body/app-otras-series//descendant::button[contains(text(),'" + arg0 + "')])[2]", 2);
            visualizarObjetoScroll(vermas, 2);
            UtilsWeb.enmarcarObjeto(vermas);
            PdfBciReports.addWebReportImage("Botón invertir fondo mutuo", "Se selecciona boton de " + arg0 + " en el fondo  " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(vermas);
            vermas.click();
            esperar(3);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonDeEnSerieAp(String arg0, String arg1) {
        try {
            esperar(3);
            WebElement vermas = existeElemento("(//span[contains (text(),'" + arg1 + "')]//ancestor::bci-accordion-body/app-otras-series//descendant::button[contains(text(),'" + arg0 + "')])[2]", 2);
            visualizarObjetoScroll(vermas, 2);
            UtilsWeb.enmarcarObjeto(vermas);
            PdfBciReports.addWebReportImage("Botón invertir fondo mutuo", "Se selecciona boton de " + arg0 + " en el fondo  " + arg1, EstadoPrueba.PASSED, false);
            UtilsWeb.desenmarcarObjeto(vermas);
            vermas.click();
            esperar(3);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void validoElTituloDelFondoInvierteDesde(String arg0, String arg1) {
        try {
            esperar(3);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }

    public void presionoElBotonDeEnLaPantallaConfirmaTuInversion(String arg0) {
        try {
            esperar(3);
        } catch (Exception e) {
            LOGGER.severe(EXCEPCION + e);
            reporteConYSinImagen(true, EXCEPCION,  EXCEPCION + e, EstadoPrueba.FAILED, true);
        }
    }
}