package constants;

import utils.MetodosGenericos;

import java.util.logging.Logger;

import static utils.MetodosGenericos.setNavegador;


public abstract class Constants {
    private Constants() {
        throw new IllegalStateException("Constantes");
    }
    public static final Logger LOGGER = Logger.getLogger("Constants");
    public static String VER_FFMM = "-re-v1-17";
    public static String VER_CART = "-re-v1-17";
    public static String VER_RESUM = "-re-v5-11";
    public static String VER_HOME = "-re-v4-24";
    public static String VER_DASH = "-re-v1-6";
    public static String VER_INF = "-re-v1-1";
    public static String RUT_CLIENTE = "";
    public static String CLAVE = "";
    public static final String AMBIENTE_URL_INVERSIONES = "http://bcicert.bci.cl/personas";
    public static final String SVC_REST = "/svcRest/infraestructura/seguridad/servlet/TokenAutorizacion?url=";
    public static final String FE_FFMM_WEB = "http://front-crt01.bci.cl/nuevaWeb/fe-fondosmutuos-webpersonas";
    public static final String FE_FFMM_WEB_PER = "http://front-crt01.bci.cl/nuevaWeb/fe-inversionesfondosmutuoswebpersonas";
    public static final String FE_INV_DASH = "http://front-crt01.bci.cl/nuevaWeb/fe-inversionesdashboard-webpersonas";
    public static final String FE_INF_PATR = "http://front-crt01.bci.cl/nuevaWeb/fe-informepatrimonial-webpersonas";
    public static final String URL_CARTERAS_DESTACADAS_INVERSIONES = SVC_REST + FE_FFMM_WEB + VER_CART + "/fondos-mutuos/destacados/";
    public static final String URL_VITRINA_INVERSIONES = SVC_REST + FE_FFMM_WEB + VER_FFMM + "/fondos-mutuos/vitrina";
    public static final String URL_RESUMEN_INVERSIONES = SVC_REST + FE_FFMM_WEB_PER + VER_RESUM + "/resumen/";
    public static final String URL_HOME_INVERSIONES = SVC_REST + FE_INV_DASH  + VER_DASH + "/dashboard/";
    public static final String URL_SALDO_EVOLUTIVO = SVC_REST + FE_FFMM_WEB_PER + VER_HOME + "/home/vitrina/";
    public static final String URL_INFORME_PATRIMONIAL = SVC_REST + FE_INF_PATR + VER_INF + "/informe-patrimonial";


    /**
     * TIPO SUITE ms o web
     */
    public static final String TIPO_SUITE = "web_bdd";
    /**
     * CELULA a mencionar en el PDF REPORT
     */
    public static String CELULA = "Banca Privada y OffShore";
    /**
     * SmokeTest
     * true -> El flujo es con SmokeTest no se ejecuta el backend
     * false -> El flujo es sin SmokeTest se ejecuta el backend
     */
    public static boolean SMOKE_TEST;
    public static char[] TOKEN;

    static {
        SMOKE_TEST = MetodosGenericos.setSmokeTest(false);
    }
    /**
     * Virtualizacion_Test
     * true -> Se ejecutaran los casos con data asociada a los servicios virtualizados
     * false -> Se ejecutaran los casos con data real para certificación
     */
    public static boolean VIRTUALIZADA = MetodosGenericos.setDataVirtualizada(false);
    //public static boolean VIRTUALIZADA=false;
    public static boolean Overnight = false;
    /**
     * ACTUALIZAR_EVIDENCIA_ALM
     * true -> Ejecutar el método 'actualizarALM(testSetID, almProperties)' genera un nuevo test run al ejecutarse
     * false -> Ejecutar el método 'actualizarALMsinGenerarRunsHistorico(testSetID, almProperties)' NO genera un nuevo
     * test run al ejecutarse sino que actualiza el último test run historico
     */
    public static boolean ACTUALIZAR_EVIDENCIA_ALM = MetodosGenericos.setActualizarEvidenciaALM(false);
    /**
     * TIPO_AMBIENTE
     * Tipo de ambiente a ejecutar: QA, INT, DEV, DEVbdQA
     */
    public static String AMBIENTE = "QA";
    /**
     * Navegador
     * Firefox, Chrome, Explorer, Edge, Safari, ChromeRemote, FirefoxRemote, IExplorerRemote, ChromeGherkins
     */
    public static Navegador BROWSER = setNavegador(Navegador.Chrome);

    public static final String EXCEPCION = "Se presenta una excepción : ";
    public static final String MODAL = "Modal ";
    public static final String MODAL_A = "Se visualiza Modal : ";
    public static final String NO_MODAL_A = "No se visualiza Modal : ";
    public static final String BOTON = "Botón ";
    public static final String CLICK = "Click ";
    public static final String CLICK_BOTON = "Click al Botón ";
    public static final String CLICK_A = "Se da click a : ";
    public static final String NO_CLICK_A = "No se encuentra el click a : ";
    public static final String CHECK = "Check ";
    public static final String CHECK_A = "Se da check a : ";
    public static final String DISCLEIMER = "Discleimer ";
    public static final String DISCLEIMER_A = "Se observa el siguiente discleimer : ";
    public static final String NO_DISCLEIMER_A = "Se observa el siguiente discleimer : ";
    public static final String CLICK_MENU = "Click al menu";
    public static final String CLICK_MENU_A = "Se da click al menu :";
    public static final String ALERTA = "Modal de alerta ";
    public static final String ALERTA_A = "Se visualiza el siguiente modal de alerta al cliente : ";

}