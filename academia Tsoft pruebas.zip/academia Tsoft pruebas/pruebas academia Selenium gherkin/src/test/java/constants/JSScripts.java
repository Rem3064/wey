package constants;

/**
 * Clase de constantes de scripts Javascript
 */
public abstract class JSScripts {

    private JSScripts() {

    }

    /**
     * Script para embeber un url (src) en un elemento
     * ejemplo de uso:
     *      getJavascriptExecutor().executeScript(String.format(JSScripts.EMBEBER_URL_ELEMENTO, "iframeContenido", "url"));
     */
    public static final String EMBEBER_URL_ELEMENTO = "document.getElementById('%s').setAttribute('src','%s');";

}
