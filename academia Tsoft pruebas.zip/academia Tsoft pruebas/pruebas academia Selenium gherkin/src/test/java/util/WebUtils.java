package util;

import constants.Constants;
import constants.JSScripts;
import driverWeb.DriverContextWeb;
import lombok.experimental.UtilityClass;
import net.sourceforge.htmlunit.corejs.javascript.JavaScriptException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.html5.LocalStorage;
import org.openqa.selenium.html5.SessionStorage;
import org.openqa.selenium.html5.WebStorage;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@UtilityClass
public class WebUtils {
    public static final Logger LOGGER = Logger.getLogger("WebUtils");
    /**
     * Realiza clic en un WebElement
     *
     * @param webElement target
     * @return resultdo del clic
     */
    public static boolean clickElement(WebElement webElement) {
        String extraTag = "";
        try{
            if (getWebDriver() instanceof SafariDriver) {
                extraTag = " [WithJS]";
                clickElementWithJs(webElement);
            }else {
                webElement.click();
            }
            LOGGER.info("[clickElement]"+ extraTag +" [success] " + webElement.toString());
            return true;
        }catch (Exception e) {
            System.err.println("[clickElement]"+ extraTag +" ["+e.getClass()+"] " + webElement.toString());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Realiza clic en un WebElement mediante JavaScript
     *
     * @param webElement target
     */
    public static void clickElementWithJs(WebElement webElement) {
        getJavascriptExecutor().executeScript("arguments[0].click();", webElement);
    }

    /**
     * Valida si un WebElement esta desplegado
     *
     * @param webElement target
     * @return resultado
     */
    public static boolean isDisplayed(WebElement webElement) {
        try {
            boolean result = Objects.nonNull(webElement) && webElement.isDisplayed();
            LOGGER.info("[isDisplayed] [" + (result ? "success" : "fail") + "]" + webElement.toString());
            return result;
        }catch (Exception e) {
            System.err.println("[isDisplayed] [" + e.getClass() + "] " + webElement.toString());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Valida si un xpath esta visible
     *
     * @param xpath target
     * @return resultado
     */
    public static boolean isDisplayed(String xpath) {
        try {
            WebElement webElement = getWebDriver().findElement(By.xpath(xpath));
            boolean result = Objects.nonNull(webElement) && webElement.isDisplayed();
            LOGGER.info("[isDisplayed] [" + (result ? "success" : "fail") + "] " + xpath);
            return result;
        } catch (NoSuchElementException e) {
            System.err.println("[isDisplayed] [NoSuchElementException]" + xpath);
            e.printStackTrace();
            return false;
        }
    }

    public static boolean sendKeys(WebElement webElement, CharSequence... string) {
        try {
            webElement.sendKeys(string);
            LOGGER.info("[sendKeys] [success] " + webElement);
            return true;
        }catch (Exception e) {
            System.err.println("[sendKeys] ["+ e.getClass() +" - " + e.getMessage() + "] " + webElement.toString());
            e.printStackTrace();
            return false;
        }
    }

    public static boolean sendKeys(WebElement webElement, boolean clear, CharSequence... string) {
        try {
            clearInput(webElement);
            webElement.sendKeys(string);
            LOGGER.info("[sendKeys] [success] " + webElement);
            return true;
        }catch (Exception e) {
            System.err.println("[sendKeys] ["+ e.getClass() +" - " + e.getMessage() + "] " + webElement.toString());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Valida si un WebElement no esta visible
     *
     * @param webElement target
     * @return resultado
     */
    public static boolean isNotDisplayed(WebElement webElement) {
        return !isDisplayed(webElement);
    }

    /**
     * Valida si un xpath esta visible
     *
     * @param xpath target
     * @return resultado
     */
    public static boolean isNotDisplayed(String xpath) {
        return !isDisplayed(xpath);
    }

    /**
     * Realiza scroll en la pagina
     *
     * @param pixelsToScrollHorizontally <- negativo (izquierda) - (derecha) positivo ->
     * @param pixelsToScrollVertically ^ negativo (arriba) - (abajo) positivo v
     */
    public static boolean executeScrollBy(int pixelsToScrollHorizontally, int pixelsToScrollVertically){
        getJavascriptExecutor().executeScript("window.scrollBy(" + pixelsToScrollHorizontally + ", " + pixelsToScrollVertically + ")", "");
        LOGGER.info("[executeScrollBy] [success] [horizontally = " + pixelsToScrollHorizontally + "] [vertically = " + pixelsToScrollVertically +"]");
        return true;
    }

    public static boolean executeScrollTo(int pixelsToScrollHorizontally, int pixelsToScrollVertically){
        getJavascriptExecutor().executeScript("window.scrollTo(" + pixelsToScrollHorizontally + ", " + pixelsToScrollVertically + ")", "");
        LOGGER.info("[executeScrollTo] [horizontally = " + pixelsToScrollHorizontally + "] [vertically = " + pixelsToScrollVertically +"]");
        return true;
    }

    public static boolean executeScrollTo(int pixelsToScrollHorizontally, int pixelsToScrollVertically, boolean focusIframe){
        resetFocusToDefault();
        getJavascriptExecutor().executeScript("window.scrollTo(" + pixelsToScrollHorizontally + ", " + pixelsToScrollVertically + ")", "");
        LOGGER.info("[executeScrollTo] [horizontally = " + pixelsToScrollHorizontally + "] [vertically = " + pixelsToScrollVertically +"]");
        focusToIframeContenido();
        return true;
    }

    public static boolean scrollTo(WebElement webElement) {
        getJavascriptExecutor().executeScript("arguments[0].scrollIntoView(true);", webElement);
        return true;
    }

    public static boolean scrollToBottom() {
        getJavascriptExecutor().executeScript("window.scrollTo(0, document.body.scrollHeight);");
        return true;
    }

    public static boolean scrollDownXpixels(int pixels) {
        String script = String.format("scrollTo(0, document.documentElement.scrollTop+%s)", pixels);
        getJavascriptExecutor().executeScript(script);
        return true;
    }

    public static boolean validateText(WebElement webElement, String expectedText) {
        if (isDisplayed(webElement)) {
            boolean result = expectedText.equals(webElement.getText().trim().replace("\n", " "));
            LOGGER.info("[validateText] [" + (result ? "success" : "fail") +"] {" + expectedText + "} == {" + webElement.getText().trim().replace("\n", " ") + "}");
        }

        System.err.println("[validateText] [false]" + webElement.getText().trim().replace("\n", " " + " != " + expectedText));
        return false;
    }

    /**
     * Mueve el foco a un webElement
     *
     * @param webElement target
     */
    public static boolean moveFocusTo(WebElement webElement) {
        try {
            getWebDriver().switchTo().frame(webElement);
            return true;
        }catch (NoSuchElementException e){
            System.err.println("[moveFocusTo] [NoSuchElementException]" + webElement.getText());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Resetea el foco al contenido defecto
     */
    public static boolean resetFocusToDefault() {
        getWebDriver().switchTo().defaultContent();
        return true;
    }

    /**
     * Mueve el foco al iframe contenido
     */
    public static boolean focusToIframeContenido() {
        try {
            resetFocusToDefault();
            WebElement iframeContenido = getWebDriver().findElement(By.id("iframeContenido"));
            getWebDriver().switchTo().frame(iframeContenido);
            return true;
        }catch (Exception e){
            System.err.println("[focusToIframeContenido] ["+e+"]" + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Obtiene el texto de un WebElement
     *
     * @param webElement target
     * @return Texto del objeto o nulo si no es encontrado
     */
    public static String getTextWebElement(WebElement webElement, boolean replaceBackslashN) {
        try {
            String result = webElement.getText().trim();
            result = replaceBackslashN ? result.replace("\n", " ") : result;
            LOGGER.info("[getTextWebElement] ["+result+"] ["+ webElement +"]");
            return result;
        }catch (Exception e){
            System.err.println("[getTextWebElement] ["+e+"] " + webElement.getText());
            return "null";
        }
    }

    public static String getTextWebElement(WebElement webElement) {
        return getTextWebElement(webElement, true);
    }

    public static String getTextInputElement(WebElement webElement) {
        return getAttribute(webElement, "value");
    }

    /**
     * Obtiene el WebDriver selenium
     *
     * @return WebDriver del contexto
     */
    public static WebDriver getWebDriver() {
        return DriverContextWeb.getDriverWeb();
    }

    /**
     * Obtiene el executor de Javascript
     *
     * @return JavaScriptExecutor
     */
    public static JavascriptExecutor getJavascriptExecutor() {
        return ((JavascriptExecutor) DriverContextWeb.getDriverWeb());
    }

    /**
     * Actions
     * @return
     */
    public static Actions getActions() {
        return new Actions(getWebDriver());
    }

    /**
     * Obtiene el LocalStorage del sitio web
     *
     * @return LocalStorage
     */
    public static LocalStorage getLocalStorage() {
        return ((WebStorage) DriverContextWeb.getDriverWeb()).getLocalStorage();
    }

    /**
     * Otiene el SessionStorage del sitio web
     *
     * @return SessionStorage
     */
    public static SessionStorage getSessionStorage() {
        return  ((WebStorage) DriverContextWeb.getDriverWeb()).getSessionStorage();
    }

    /**
     * Agrega valores al SessionStorage
     *
     * @param name nombre
     * @param value valor
     */
    public static void addSessionStorage(String name, String value) {
        addSessionStorage(new HashMap<String, String>(){{ put(name, value); }});
        LOGGER.info("[addSessionStorage] " + name + " = " + value);
    }

    /**
     * Agrega valores al sessionStorage del sitio web
     *
     * @param sessionStorageValues Mapa de valores, nombre y valor
     */
    public static void addSessionStorage(Map<String, String> sessionStorageValues) {
        sessionStorageValues.forEach((key, value) -> getLocalStorage().setItem(key, value));
    }

    /**
     * Agrega una cookie al sitio web
     *
     * @param name nombre
     * @param value valor
     */
    public static void addCookie(String name, String value) {
        addCookie(new HashMap<String, String>(){{ put(name, value); }});
        LOGGER.info("[addCookie] " + name + " = " + value);
    }

    /**
     * Agrega cookies al sitio web
     *
     * @param cookies Mapa de valores, nombre y valor
     */
    public static void addCookie(Map<String, String> cookies) {
        cookies.entrySet().stream()
                .map((c) -> new Cookie(c.getKey(), c.getValue()))
                .forEach(DriverContextWeb.getDriverWeb().manage()::addCookie);
    }

    /**
     * Embebe un url en el iframe "iframeContenido" de monolito
     *
     * @param url Url a inyectar
     */
    public static void embeberUrlEnIframeContenido(String url) {
        LOGGER.info("*** [INI] EMBEBIENDO URL en iframe contenido ***");
        try {
            resetFocusToDefault();
            Utils.waitSeconds(3);
            String svcRestAddToken = "/svcRest/infraestructura/seguridad/servlet/TokenAutorizacion?url=";
            String newUrl = url.contains("TokenAutorizacion") ? url : svcRestAddToken + url;
            LOGGER.info("URL: " + newUrl);
            getJavascriptExecutor().executeScript(String.format(JSScripts.EMBEBER_URL_ELEMENTO, "iframeContenido", newUrl));
            Utils.waitSeconds(12);
        }catch (JavaScriptException e) {
            System.err.println("[WebUtils] [embeberUrlEnIframeContenido] Error al ejecutar script js " + e.getMessage());
            e.printStackTrace();
        }
        LOGGER.info("*** [FIN] EMBEBIDO ***");
    }


    /**
     * Embebe un url en el iframe
     *
     * @param url Url a inyectar
     */
    public static void embeberUrlEnIframe(String url) {
        LOGGER.info("*** [INI] EMBEBIENDO URL en iframe ***");
        try {
            String rutCliente = Constants.RUT_CLIENTE;
            String clave = Constants.CLAVE;
            String tok = String.valueOf(Constants.TOKEN);
            resetFocusToDefault();
            getLocalStorage().setItem("bci-session-token",tok);
            Utils.waitSeconds(5);
            String svcRestAddToken = "/svcRest/infraestructura/seguridad/servlet/TokenAutorizacion?url=";
            String newUrl = url.contains("TokenAutorizacion") ? url : svcRestAddToken + url;
            //newUrl = newUrl.replace(svcRestAddToken, "")+"?token="+new AccionesBackend(FirmarContratoCanalInternetSteps.rut, "111222").login().getToken();
            getJavascriptExecutor().executeScript(String.format(JSScripts.EMBEBER_URL_ELEMENTO, "iframeContenido", newUrl));
            //String svcRest = "https://front-crt01.bci.cl/nuevaWeb/fe-fondosmutuos-webpersonas-re-v1-0/fondos-mutuos/vitrina";
            //getJavascriptExecutor().executeScript(String.format(JSScripts.EMBEBER_URL,"bci-session-token",token));
            //newUrl = newUrl.replace(svcRestAddToken, "")
            LOGGER.info("URL: ***" + newUrl);
            LOGGER.info("token : ***" + tok);
            Utils.waitSeconds(60);

        }catch (JavaScriptException e) {
            System.err.println("[WebUtils] [embeberUrlEnIframeContenido] Error al ejecutar script js " + e.getMessage());
            e.printStackTrace();
        }
        LOGGER.info("*** [FIN] EMBEBIDO ***");
    }
    /**
     * Obtiene un atributo de un WebElement
     *
     * @param webElement target
     * @param attribute atributo a obtener
     * @return Atributo o "null"
     */
    public static String getAttribute(WebElement webElement, String attribute) {
        if (isDisplayed(webElement)) {
            String attributeGetted = webElement.getAttribute(attribute);
            LOGGER.info("[getAttribute] [success] {"+webElement+"} {"+attribute+" = "+attributeGetted+"}");
            return attributeGetted;
        }else {
            System.err.println("[getAttribute] [error] {"+attribute+" = "+null+"}");
            return "null";
        }
    }

    public static String getCssValue(WebElement webElement, String propertyName) {
        if (isDisplayed(webElement)) {
            return webElement.getCssValue(propertyName);
        }else {
            return "null";
        }
    }

    public static boolean clearInput(WebElement webElement) {
        try {
            webElement.clear();
            return true;
        }catch (Exception e) {
            return false;
        }
    }

    /**
     * Elimina el texto de input letra por letra
     *
     * @param webElement target
     */
    public static boolean clearInputKeyByKey(WebElement webElement) {
        LOGGER.info("*** [INI] clearInput ***");
        try {
            do {
                String actualText = getAttribute(webElement, "value");
                LOGGER.info("* ActualText: \"" + actualText + "\"");
                if (actualText.equals("null") || actualText.isEmpty()) {
                    break;
                }
                webElement.sendKeys(Keys.BACK_SPACE);
            } while (true);
            LOGGER.info("*** [FIN] clearInput ***");
            return true;
        }catch (Exception e) {
            e.printStackTrace();
            LOGGER.info("*** [FIN] clearInput ***");
            return false;
        }
    }

    public static boolean waitForElementVisible(WebElement webElement, int seconds) {
        LOGGER.info("[waitForElementVisible] " + seconds + "s - " + webElement.toString());
        try {
            new WebDriverWait(getWebDriver(), seconds)
                    .until(ExpectedConditions.visibilityOf(webElement));

            LOGGER.info("[waitForElementVisible] [success] Elemento encontrado: " + webElement);
            return true;
        }catch (Exception e) {
            System.err.println("[waitForElementVisible] [" + e.getClass() +"] Elemento no encontrado: " + webElement);
            return false;
        }
    }


    public static boolean waitForElementVisible(String xpath, int seconds) {
        LOGGER.info("[waitForElementVisible] " + xpath);
        try {
            new WebDriverWait(getWebDriver(), seconds)
                    .until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
            return true;
        }catch (Exception e) {
            System.err.println("[waitForElementVisible] [" + e.getClass() +"] Elemento no encontrado: " + xpath);
            e.printStackTrace();
        }

        return false;
    }

    public static boolean waitForElementNotVisible(WebElement webElement, int seconds) {
        LOGGER.info("[waitForElementNotVisible] " + seconds + "s - " + webElement.toString());
        try {
            new WebDriverWait(getWebDriver(), seconds)
                    .until(ExpectedConditions.invisibilityOf(webElement));

            LOGGER.info("[waitForElementNotVisible] [success] Elemento no encontrado: " + webElement);
            return true;
        }catch (TimeoutException e) {
            System.err.println("[waitForElementNotVisible] [" + e.getClass() +"] Elemento encontrado: " + webElement);
            e.printStackTrace();
            return false;
        }
    }

    public static boolean waitForElementNotVisible(String xpath, int seconds) {
        LOGGER.info("[waitForElementNotVisible] " + seconds + "s - " + xpath);
        try {
            new WebDriverWait(getWebDriver(), seconds)
                    .until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpath)));
            LOGGER.info("[waitForElementNotVisible] [success] Elemento no encontrado: " + xpath);
            return true;
        }catch (Exception e) {
            System.err.println("[waitForElementNotVisible] [" + e.getClass() +"] Elemento encontrado: " + xpath);
            e.printStackTrace();
        }

        return false;
    }

    public static boolean waitForElementClickable(WebElement webElement, int seconds) {
        LOGGER.info("[waitForElementClickable] " + seconds + "s - " + webElement.toString());
        try {
            new WebDriverWait(getWebDriver(), seconds)
                    .until(ExpectedConditions.elementToBeClickable(webElement));

            LOGGER.info("[waitForElementClickable] [success] Elemento clickeable: " + webElement);
            return true;
        }catch (TimeoutException e) {
            System.err.println("[waitForElementClickable] [" + e.getClass() +"] Elemento no clickeable: " + webElement);
            e.printStackTrace();
            return false;
        }
    }

    public static boolean moveToElement(WebElement webElement, boolean doClick) {
        try {
            Actions actions = getActions();
            actions.moveToElement(webElement);
            if (doClick) {
                actions.click();
            }
            actions.perform();
            System.err.println("[moveToElement] [success] " + webElement);
            return true;
        }catch (Exception e) {
            System.err.println("Error en moveToElement" + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public static boolean selectByVisibleText(WebElement webElement, String text) {
        try {
            clickElement(webElement);
            List<WebElement> options = webElement.findElements(By.xpath("//div[@role='listbox']//mat-option"));
            Optional<WebElement> optionOpt = options.stream().filter(option -> getTextWebElement(option.findElement(By.tagName("span"))).contains(text)).findFirst();
            if (optionOpt.isPresent()) {
                return clickElement(optionOpt.get()) && Utils.waitSeconds(1);
            }
        }catch (Exception e) {
            System.err.println("Error al ejecutar select: " + e.getMessage());
            e.printStackTrace();
        }

        return false;
    }

    public static boolean selectFechaCalendario(WebElement webElement, String dia, String mes, String anho) {
        try {
            clickElement(webElement);
            String[] actualRangeStr = webElement.findElement(By.xpath("//button[contains(@class, 'mat-calendar-period-button')]//span//span")).getText().split(" ");
            List<Integer> yearsRange = IntStream.range(Integer.parseInt(actualRangeStr[0].trim()), Integer.parseInt(actualRangeStr[2].trim())).boxed().collect(Collectors.toList());

            while (!yearsRange.contains(Integer.parseInt(anho))) {
                String xpathPrevBtn = "//button[contains(@class, 'mat-calendar-previous-button')]";
                String xpathNextBtn = "//button[contains(@class, 'mat-calendar-next-button')]";
                clickElement(webElement.findElement(By.xpath((yearsRange.get(0) > Integer.parseInt(anho)) ? xpathPrevBtn : xpathNextBtn)));
                actualRangeStr = webElement.findElement(By.xpath("//button[contains(@class, 'mat-calendar-period-button')]//span//span")).getText().split(" ");
                yearsRange = IntStream.range(Integer.parseInt(actualRangeStr[0].trim()), Integer.parseInt(actualRangeStr[2].trim())).boxed().collect(Collectors.toList());
            }

            List<WebElement> anhos = webElement.findElements(By.xpath("//tbody//td"));
            anhos
                    .stream()
                    .filter(actual -> getTextWebElement(actual).contains(anho))
                    .findFirst()
                    .map(WebUtils::clickElement);

            Map<String, List<String>> monthsList = new HashMap<>();
            monthsList.put("01", Arrays.asList("JAN", "ENE"));
            monthsList.put("02", Arrays.asList("FEB", "FEB"));
            monthsList.put("03", Arrays.asList("MAR", "MAR"));
            monthsList.put("04", Arrays.asList("APR", "ABR"));
            monthsList.put("05", Arrays.asList("MAY", "MAY"));
            monthsList.put("06", Arrays.asList("JUN", "JUN"));
            monthsList.put("07", Arrays.asList("JUL", "JUL"));
            monthsList.put("08", Arrays.asList("AUG", "AGO"));
            monthsList.put("09", Arrays.asList("SEP", "SEP"));
            monthsList.put("10", Arrays.asList("OCT", "OCT"));
            monthsList.put("11", Arrays.asList("NOV", "NOV"));
            monthsList.put("12", Arrays.asList("DEC", "DIC"));


            List<WebElement> months = webElement.findElements(By.xpath("//tbody//td"));
            months
                    .stream()
                    .filter(actual -> monthsList.get(mes).contains(getTextWebElement(actual).trim()))
                    .findFirst()
                    .map(WebUtils::clickElement);

            List<WebElement> days = webElement.findElements(By.xpath("//tbody//td"));
            days
                    .stream()
                    .filter(actual -> getTextWebElement(actual).trim().contains(String.valueOf(Integer.parseInt(dia))))
                    .findFirst()
                    .map(WebUtils::clickElement);

            return true;

        }catch (Exception e) {
            System.err.println("Error al seleccionar fecha: " + e.getMessage());
            e.printStackTrace();
        }

        return false;
    }

    public static boolean waitForReadyState() {
        try {
            new WebDriverWait(getWebDriver(), 30).until((ExpectedCondition<Boolean>) wd ->
                    ((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));
            return true;
        }catch (Exception e) {
            return false;
        }
    }

    public static boolean isEnable(WebElement target) {
        try {
            return target.isEnabled();
        }catch (Exception e) {
            return false;
        }
    }

    public static String getUrlIframeContenido() {
        WebElement iframeContenido = getWebDriver().findElement(By.id("iframeContenido"));
        if (isDisplayed(iframeContenido)) {
            return getAttribute(iframeContenido, "src");
        }else {
            return "null";
        }
    }

    public static Optional<WebElement> findElement(By locator) {
        try {
            WebElement el = getWebDriver().findElement(locator);
            LOGGER.info("[findElementByXpath] [success] " + el.toString());
            return Optional.of(el);
        }catch (Exception e) {
            System.err.println("[findElementByXpath] [error] ["+e+"]");
            return Optional.empty();
        }
    }

    public static Optional<WebElement> findElement(WebElement webElement, By locator) {
        try {
            WebElement el = webElement.findElement(locator);
            LOGGER.info("[findElementByXpath] [success] " + el.toString());
            return Optional.of(el);
        }catch (Exception e) {
            System.err.println("[findElementByXpath] [error] ["+e+"]");
            return Optional.empty();
        }
    }


}
