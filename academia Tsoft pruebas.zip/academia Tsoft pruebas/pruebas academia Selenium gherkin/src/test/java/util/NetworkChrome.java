package util;

import driverWeb.DriverContextWeb;
import org.json.JSONObject;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.services.Utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class NetworkChrome extends Acciones {

    public static void capturaRequest() throws IOException, InterruptedException {

        Properties prop = Acciones.loadProp("almCuentas");
        File archivoSalida = new File("tmp/Salidas_MicroFront.txt");
        try (FileWriter escribir = new FileWriter(archivoSalida, true)) {
            try {
                if (prop.getProperty("microFront").equals("true")) {
                    List<LogEntry> logs = DriverContextWeb.getDriverWeb().manage().logs().get(LogType.PERFORMANCE).getAll();
                    String microF = null;
                    boolean encontrado = false;

                    //ciclo para iterar por todos los modulos que devuelve el Json
                    for (Iterator<LogEntry> it = logs.iterator(); it.hasNext(); ) {
                        LogEntry entry = it.next();
                        JSONObject json = new JSONObject(entry.getMessage());

                        //condicion para confirmar que la respuesta contenga la version de microfront
                        if (json.toString().contains("module\\")) {
                            String version = json.toString();
                            //instruccion que devuelve la ubicacion de la la version en el Json transformado en String
                            int index = version.indexOf("module\\");
                            microF = microF + "\n" + version.substring(index, index + 56).replace("module\\", "").replace("\\", "").replace("}", "").replace(":", "").replace("", "").trim().replace("null", "");
                            microF = microF.replace("https/", "").replace("urlh", "").replace("url", "").replace("/ap", "");
                            microF = microF.replace("https", "").replace("http", "").replace("/a", "");
                            microF = microF.replace("htt", "").replace("ur", "");
                            encontrado = true;
                        }
                    }
                    if (encontrado) {
                        boolean nombreCaso = false;
                        String testName = Utils.getTestName();
                        List<String> lines = Files.readAllLines(Paths.get(String.valueOf(archivoSalida)), StandardCharsets.UTF_8);
                        //valida si ya esta el nombre del caso
                        for (String str : lines) {
                            if (testName.equals(str)) {
                                nombreCaso = true;
                                break;
                            }
                        }
                        //si no se encuentra nombre del caso se escribe
                        if (!nombreCaso) {
                            escribir.write("\n--------------------------------------------------------\n");
                            escribir.write("NOMBRE DEL CASO: " + testName);
                        }
                        String descripcion = "\nLa URL: " + DriverContextWeb.getDriverWeb().getCurrentUrl() + "\nContiene las versiones de Microfront: " + microF.replace("null", "").replace(",", "").replaceAll("\"", "") + "\n\n";
                        reporteConYSinImagen(false, "Se encuentra version Microfront ", descripcion, EstadoPrueba.PASSED, false);
                        escribir.write(descripcion);

                    } else {
                        reporteConYSinImagen(false, "No se detecta la version de Microfront ", "Version no encontrada", EstadoPrueba.WARNING, false);
                        String sinVersion = "\nLa URL: " + DriverContextWeb.getDriverWeb().getCurrentUrl() + "\nNO se detecta version de Microfront, esto puede ser que la URL fue validada en el paso anterior " + "\n\n";
                        escribir.write(sinVersion);
                    }
                    escribir.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}