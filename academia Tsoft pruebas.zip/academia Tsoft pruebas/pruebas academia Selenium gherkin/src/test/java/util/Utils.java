package util;

import lombok.experimental.UtilityClass;
import org.openqa.selenium.WebElement;
import reporter.PdfBciReports;
import utils.FeatureControlled;
import utils.MetodosGenericos;

import java.io.File;
import java.util.logging.Logger;

@UtilityClass
public class Utils {
    public static final Logger LOGGER = Logger.getLogger("Utils");
    public static void setStepAndPrint(String stepName) {
        FeatureControlled.step = stepName;
        LOGGER.info("================= Step: '" + FeatureControlled.step + "'.");
    }

    public static boolean waitSeconds(int seconds) {
        try {
            MetodosGenericos.esperar(seconds);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.info(e.getMessage());
        }
        return false;
    }

    public static String quitarCaracteres(String originalStr, String... targets) {
        if (originalStr==null) {
            return "null";
        }

        String newStr = originalStr;
        for (String c: targets) {
            newStr = newStr.replace(c, "");
        }

        return newStr;
    }

    public static String leftTrim(String s) {
        int i = 0;
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
            i++;
        }
        return s.substring(i);
    }

    public static String rightTrim(String s) {
        int i = s.length()-1;
        while (i > 0 && Character.isWhitespace(s.charAt(i))) {
            i--;
        }
        return s.substring(0,i+1);
    }

    public static int countLines(String str){
        String[] lines = str.split("\r\n|\r|\n");
        return  lines.length;
    }

    /**
     * Agrega un reporte de validacion de texto
     *
     * @param expected Texto esperado
     * @param actual WebElement a extraer texto actual
     * @param isFatal es fatal
     */
    public static void textValidation(String nombrePaso,String expected, WebElement actual, boolean isFatal, String... strReplacement) {
        String replaced = WebUtils.getTextWebElement(actual);

        for (String target : strReplacement) {
            replaced = replaced.replace(target, "");
        }
        PdfBciReports.addTextValidate(nombrePaso, expected, replaced, isFatal);
    }

    public String rutaDescarga(File office, String rutaDescarga) {
        String sistemeOperativo = office.toString();
        if ("Mac OS X".equals(sistemeOperativo)) {
            rutaDescarga = rutaDescarga.replace("\\Downloads\\", "/Downloads/");
        }
        return rutaDescarga;
    }
}
