package util;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.logging.Logger;

import static utils.MetodosGenericos.esperar;

public class WaitWebDriver {
	public static final Logger LOGGER = Logger.getLogger("WaitWebDriver");
	public WaitWebDriver() {
		super();
	}

	public static void waitVisibility(WebDriver driver, WebElement element, int time) {
		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public static void waitClickable(WebDriver driver, WebElement element, int time) {
		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	public static void waitSelected(WebDriver driver, WebElement element, int time) {
		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.elementToBeSelected(element));
	}

	public static void waitAlert(WebDriver driver, int time) {
		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.alertIsPresent());
	}

	public static void waitInvisibility(WebDriver driver, WebElement element, int time) {
		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.invisibilityOf(element));
	}

	public static void waitLoadingWrapper(WebDriver driver) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement elementX = driver.findElement(By.xpath(
					"//*[@id='ext-element-5'] | //*[@id='loadmask-1529-msgTextEl'] | //*[@id='loadmask-4358-msgTextEl'] | //*[@class='x-component  wt-splash x-component-default'] | //*[@id='loadmask-1097'] | //*[@id='loadmask-1086'] | //div[@id='loadmask-1109']"));
			WaitWebDriver.waitVisibility(driver, elementX, 4);
			wait.until(ExpectedConditions.invisibilityOf(elementX));
		} catch (Exception e) {
			//LOGGER.info("Loading wrapper timeout");
		}
	}

	public static void waitSeconds(int seconds) {
		try {
			esperar(1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void elementosInvisibles(WebDriver driver, String element, int time) {
		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(element)));
	}

	public static void notTextToBePresentInElement(WebDriver driver, String mensaje, WebElement elemento, int time) {
		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.not(ExpectedConditions.textToBePresentInElement(elemento, mensaje)));
	}

}
