package util;

import driverWeb.DriverContextWeb;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.web.ControlledActionsWeb;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.logging.Logger;

import static utils.MetodosGenericos.esperar;

/**
 * The Class Acciones.
 */
public class Acciones  {
    /**
     * The logger.
     */
    public static final Logger LOGGER = Logger.getLogger("util.Acciones.class");
    /**
     * The spinner.
     */
    @FindBy(xpath = "//bci-spinner") // Spinner
    protected WebElement spinner;


    /**
     * Metodo que oprime la tecla seleccionada
     * <p>
     * Fecha de Creacion: 05-09-2019
     * <p>
     * .
     *
     * @param tecla Tecla a oprimir de la enumeracion "Keys" [Ej: Keys.ESCAPE ]
     * @author Herbert Jara
     */
    public static void oprimirTecla(Keys tecla) {
        Actions accion = new Actions(DriverContextWeb.getDriverWeb());
        accion.sendKeys(tecla).perform();
    }

    /**
     * Metodo que oprimer primero la tecla1 y luego la tecla2 sin soltar la tecla1
     * <p>
     * Fecha de Creacion: 05-09-2019
     * <p>
     * .
     *
     * @param tecla1 Tecla a oprimir primero [Ej: Keys.ALT ]
     * @param tecla2 Tecla a oprimir mientras se oprime la primera [Ej: Keys.F4 ]
     * @author Herbert Jara
     */
    public static void oprmirTecla(Keys tecla1, Keys tecla2) {
        Actions accion = new Actions(DriverContextWeb.getDriverWeb());
        accion.keyDown(tecla1).perform();
        accion.sendKeys(tecla2).perform();
        accion.keyUp(tecla1).perform();
    }


    /**
     * Metodo que hace scroll al elemento usando Javascript
     * <p>
     * Fecha de Creacion: 06-09-2019
     * <p>
     * .
     *
     * @param elemento Elemento objetivo
     * @author Herbert Jara
     */
    public static void scrollAlElementoConJavascript(WebElement elemento) {
        try {
            esperar(1);
            ((JavascriptExecutor) DriverContextWeb.getDriverWeb()).executeScript("arguments[0].scrollIntoView(true);", elemento);
        } catch (Exception e) {
            System.err.println("Esperando elemento " + e + " segundo.");
        }
    }

    /**
     * Metodo que hace click en el elemento usando Javascript
     * <p>
     * Fecha de Creacion: 06-09-2019
     * <p>
     * .
     *
     * @param elemento the elemento
     * @author Herbert Jara
     */
    public static void clickAlElementoConJavascript(WebElement elemento) {
        try {
            JavascriptExecutor ejecutador = (JavascriptExecutor) DriverContextWeb.getDriverWeb();
            ejecutador.executeScript("arguments[0].click();", elemento);
            //LogErrorInChrome.GetJSErrorLog("clickAlElementoConJavascript elemento " + elemento);
        } catch (Exception e) {
            PdfBciReports.addWebReportImage("No es posible dar clic al elemento: " + elemento,
                    "No es posible dar clic al elemento: " + elemento, EstadoPrueba.FAILED, true);

        }

    }

    /**
     * Metodo que espera a que el elemento desaparesca
     * <p>
     * Fecha de Creacion: 09-09-2019
     * <p>
     * .
     *
     * @param elemento Elemento que debe desaparecer
     * @param segundos Tiempo a esperar
     * @return true, if successful
     * @author Herbert Jara
     */
    public static boolean esperarAQueDesaparesca(WebElement elemento, int segundos) {
        WebDriverWait esperar = new WebDriverWait(DriverContextWeb.getDriverWeb(), segundos);
        esperar.until(ExpectedConditions.invisibilityOf(elemento));
        try {
            WebDriverWait wait = new WebDriverWait(DriverContextWeb.getDriverWeb(), 2);
            wait.until(ExpectedConditions.visibilityOf(elemento));
            LOGGER.info("sigue el spinner");
            return false;
        } catch (Exception var4) {
            return true;
        }
    }

    /**
     * Metodo para verificar si el elemento existe en la pagina
     * <p>
     * Fecha de Creacion: 09-09-2019
     * <p>
     * .
     *
     * @param identificador Selector del elemento a buscar
     * @return Booleano si existe o no
     * @author Herbert Jara
     */
    public static boolean existe(By identificador) {
        return DriverContextWeb.getDriverWeb().findElements(identificador).size() != 0;
    }

    /**
     * Loading.
     *
     * @param xpath   the xpath
     * @param timeOut the time out
     */
    public static void loading(String xpath, int timeOut) {
        WebElement result = null;
        int countTimeOut = 0;
        do {
            try {
                esperar(1);
                result = DriverContextWeb.getDriverWeb().findElement(By.xpath(xpath));
            } catch (Exception e) {
                System.err.println("Esperando spinner " + countTimeOut + " segundo.");
            }
            countTimeOut++;
        } while (result == null || countTimeOut < timeOut);
    }

    /**
     * Existe elemento.
     *
     * @param xpath   the xpath
     * @param timeOut the time out
     * @return the web element
     */

    public static WebElement existeElemento(String xpath, int timeOut) {
        WebElement result = null;
        int countTimeOut = 0;
        do {
            try {
                esperar(2);
                result = DriverContextWeb.getDriverWeb().findElement(By.xpath(xpath));
                PdfBciReports.addReport("El elemento con el xpath: " + xpath + " ha sido encontrado", "El elemento con el xpath: " + xpath + " ha sido encontrado", EstadoPrueba.PASSED, false);
            } catch (Exception e) {
                PdfBciReports.addReport("El elemento con el xpath: " + xpath + " no ha sido encontrado", "El elemento con el xpath: " + xpath + " no ha sido encontrado", EstadoPrueba.FAILED, true);
                System.err.println("Espero " + countTimeOut + "segundos");
            }
            countTimeOut++;
        } while (result == null && countTimeOut < timeOut);
        return result;

    }

    /**
     * Click elemento.
     *
     * @param elemento    the elemento
     * @param nombrePaso  the nombre paso
     * @param descripcion the descripcion
     */
    public static void clickElemento(WebElement elemento, String nombrePaso, String descripcion) {

        int limite = 3;
        int tiempo = 0;

        // Valida que el elemento este desplegado
        if (validaExist(elemento)) {

            while (tiempo != limite) {

                if (clicException(elemento)) {
                    tiempo = limite - 1;
                }

                // Si aun existe error al hacer click y se cumple el limite de tiempo
                if (tiempo == limite) {
                    capEvidencia("Error al realizar Click sobre el elemento",
                            "se visualiza un ElementClickInterceptedException al realizar click sobre el elemento",
                            false);
                    // throw new Exception("El Loading supero 1 minuto de espera");
                }

                tiempo++;

            }

        } else {

            // Recorre mientras el elemento no esta desplegado
            while (!validaExist(elemento)) {


                tiempo++;

                // Si supera limite de tiempo falla y relanza una EXCEPCION
                if (tiempo == limite) {
                    capEvidencia("Validacion de Spinner", "Se supero el tiempo esperado", false);
                    // throw new Exception("El Loading supero 1 minuto de espera");
                }

            }

            // Click en el elemento
            elemento.click();
            LogErrorInChrome.GetJSErrorLog("click al elemento "+ elemento);
        }

    }

    /**
     * Click elemento.
     *
     * @param xpath       the xpath
     * @param nombrePaso  the nombre paso
     * @param descripcion the descripcion
     */
    public static void clickElemento(String xpath, String nombrePaso, String descripcion) {

        int limite = 10;
        int tiempo = 0;
        // Valida que el elemento este desplegado
        if (validaExist(xpath)) {

            while (tiempo != limite) {

                if (clicException(DriverContextWeb.getDriverWeb().findElement(By.xpath(xpath)))) {
                    tiempo = limite - 1;
                }

                // Si aun existe error al hacer click y se cumple el limite de tiempo
                if (tiempo == limite) {
                    capEvidencia("Error al realizar Click sobre el elemento",
                            "se visualiza un ElementClickInterceptedException al realizar click sobre el elemento",
                            false);
                    // throw new Exception("El Loading supero 1 minuto de espera");
                }

                tiempo++;

            }

        } else {

            // Recorre mientras el elemento no esta desplegado
            while (!validaExist(xpath)) {


                tiempo++;

                // Si supera limite de tiempo falla y relanza una EXCEPCION
                if (tiempo == limite) {
                    capEvidencia("Validacion de Spinner", "Se supero el tiempo esperado", false);
                    // throw new Exception("El Loading supero 1 minuto de espera");
                }

            }

            // Click en el elemento
            DriverContextWeb.getDriverWeb().findElement(By.xpath(xpath)).click();
            LogErrorInChrome.GetJSErrorLog("click al elemento "+ xpath);
        }

    }

    /**
     * Flashear.
     *
     * @param elemento the elemento
     * @throws InterruptedException the interrupted exception
     */
    public static void flashear(WebElement elemento) throws InterruptedException {
        String estilo_origial = elemento.getAttribute("style");
        JavascriptExecutor ejecutador = (JavascriptExecutor) DriverContextWeb.getDriverWeb();
        int cont = 0;
        do {
            ejecutador.executeScript("arguments[0].setAttribute(arguments[1],arguments[2])", elemento, "style",
                    "border: 2px solid red; border-style: dashed;");
            cont++;
            esperar(1);
            ejecutador.executeScript("arguments[0].setAttribute(arguments[1],arguments[2])", elemento, "style",
                    estilo_origial);
            esperar(1);
        } while (cont < 4);
    }

    /**
     * Metodo para cargar la Data de un archivo de Propiedades Fecha de Creacion:
     * 17-02-2020.
     *
     * @param archivo se ingresa el archivo de propiedades que sera cargado
     * @return prop devuelve el archivo de propiedades con todas sus variables
     * @throws InterruptedException the interrupted exception
     * @author Rodrigo Sanchez
     */
    public static Properties loadProp(String archivo) throws InterruptedException {

        Properties prop = new Properties();
        try {
            try( InputStream is = Files.newInputStream(Paths.get("src/test/resources/" + archivo + ".properties"))){
                prop.load(is);
            }
        } catch (IOException e) {
            LOGGER.info(e.toString());
        }
        return prop;
    }

    /**
     * Metodo insertar texto en input Fecha de Creacion: 18-02-2020.
     *
     * @param elemento   the elemento
     * @param nombrePaso the nombre paso
     * @param txt        the txt
     * @throws InterruptedException the interrupted exception
     * @author Carlos Fuentes
     */

    public static void sendKey(WebElement elemento, String nombrePaso, String txt)  {
        validaElemento(elemento, nombrePaso, 5, false);
        try {
            if (elemento.isEnabled()) {
                elemento.clear();
                elemento.sendKeys(txt);
                PdfBciReports.addWebReportImage(nombrePaso, "Se encontro elemento", EstadoPrueba.PASSED, false);
            }
        } catch (Exception e) {
            PdfBciReports.addWebReportImage("No es posible insertar texto en elemento: " + elemento,
                    "No es posible insertar texto en elemento: " + elemento, EstadoPrueba.FAILED, true);

        }

    }

    /**
     * Fecha de Creacion: 20-02-2020.
     *
     * @param fecha the fecha
     * @param dias  the dias
     * @return the date
     * @author Carlos Fuentes
     */
    public Date sumarRestarDIAS(Date fecha, int dias) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fecha);
        calendar.add(Calendar.DAY_OF_YEAR, dias);
        return calendar.getTime();

    }

    /**
     * Espera Spinner desaparezca Fecha de Creacion: 18-02-2020.
     *
     * @throws Exception the exception
     * @author Sebastian Almuna
     * @modificado Rodrigo Sanchez
     */
    public void spinner() throws Exception {
        int limite = 5000;
        int tiempo = 0;

        // Se valida que el Spinner esta presente
        if (validaExist("//bci-spinner")) {

            // Recorre mientras el spinner esta presente y tiempo no llega al limite
            while (validaExist("//bci-spinner")) {

                tiempo++;

                // Si supera limite de tiempo falla y relanza una EXCEPCION
                if (tiempo == limite) {
                    PdfBciReports.addReport("Spinner tarda mas del tiempo limite", "falla al cargar la pagina, se terminará la ejecucion", EstadoPrueba.FAILED, true);
                    throw new Exception("El Loading supero 1 minuto de espera");
                }

            }

        }

    }

    /**
     * Captura de Evidencia Fecha de Creacion: 19-02-2020.
     *
     * @param titulo      the titulo
     * @param descripcion the descripcion
     * @param estado      the estado
     * @author Rodrigo Sanchez
     */
    public static void capEvidencia(String titulo, String descripcion, boolean estado) {

        // Se decide si es PASSED o FAILED
        if (estado) {

            // Reporte validacion exitosa no se visualizo Spinner
            PdfBciReports.addWebReportImage(titulo, descripcion, EstadoPrueba.PASSED, false);

        } else {

            // Reporte validacion exitosa no se visualizo Spinner
            PdfBciReports.addWebReportImage(titulo, descripcion, EstadoPrueba.FAILED, false);

        }

        // tiempo necesario para

    }

    /**
     * Valida elemento y genera reporte en PDF Fecha de Creacion: 18-02-2020.
     * <p>
     * //* @param objeto         the objeto
     *
     * @param nombreElemento the nombre elemento
     * @param imageReport    the image report
     * @return true, if successful
     * @author GenericValidations
     */
//(WebElement element, int tiempo, String descripcion, String tipoElemento)
    public static boolean validaElementoReporte(WebElement elemento, String nombreElemento, boolean imageReport) {
        if (ControlledActionsWeb.visualizarObjeto(elemento, 30)) {
            reporteConYSinImagen(false, nombreElemento, "El elemento se muestra correctamente en la pagina.",
                    EstadoPrueba.PASSED, false);

            return true;
        } else {

            reporteConYSinImagen(imageReport, nombreElemento, "El elemento no es visible en la pagina.",
                    EstadoPrueba.FAILED, false);
            return false;
        }
    }

    /**
     * Genera reporte con o sin imagen Fecha de Creacion: 18-02-2020.
     *
     * @param imageReport     the image report
     * @param nombrePaso      the nombre paso
     * @param descripcionPaso the descripcion paso
     * @param estadoPrueba    the estado prueba
     * @param fatal           the fatal
     * @author Merge Listo de este metodo
     */
    public static void reporteConYSinImagen(boolean imageReport, String nombrePaso, String descripcionPaso,
                                            EstadoPrueba estadoPrueba, boolean fatal) {

        if (!imageReport) {
            PdfBciReports.addReport(nombrePaso, descripcionPaso, estadoPrueba, fatal);
        } else {
            PdfBciReports.addWebReportImage(nombrePaso, descripcionPaso, estadoPrueba, fatal);
        }

    }

    /**
     * Metodo que devuelve el texto de un elemento Fecha de Creacion: 18-02-2020.
     *
     * @param elemento the elemento
     * @return the string
     * @author Matias Solis
     */
    public static String capturartexto(WebElement elemento) {

        if (ControlledActionsWeb.visualizarObjeto(elemento, 30)) {
            PdfBciReports.addWebReportImage("Obtener Texto",
                    "No se encontro elemento al que se queria obtener el texto", EstadoPrueba.FAILED, true);
        }
        return elemento.getText();
    }

    /**
     * Finaliza el test, cierra el PDF y el Driver Fecha de Creacion: 19-02-2020.
     *
     * @author Rodrigo Sanchez
     */
    public static void finalizaTest() {

        // Se cierra PDF
        PdfBciReports.closePDF();
        // Se cierra Driver
        DriverContextWeb.getDriverWeb().close();

    }

    /**
     * Metodo para validar la existencia de un elemento Fecha de Creacion:
     * 20-02-2020.
     *
     * @param xpath the xpath
     * @return true, if successful
     * @author Rodrigo Sanchez Ch.
     */
    protected static boolean validaExist(String xpath) {

        try {


            DriverContextWeb.getDriverWeb().findElement(By.xpath(xpath));

        } catch (NoSuchElementException e) {
            // Si no se encuentra el elemento devuelve FALSE
            return false;
        } catch (StaleElementReferenceException e) {
            // Si no se encuentra el elemento devuelve FALSE
            return false;
        } catch (Exception e) {
            // Si no se encuentra el elemento devuelve FALSE
            return false;
        }
        // Si se encuentra el elemento devuelve TRUE
        return true;
    }

    /**
     * Metodo para validar la existencia de un elemento Fecha de Creacion:
     * 20-02-2020.
     *
     * @param elemento the elemento
     * @return true, if successful
     * @author Rodrigo Sanchez
     */
    protected static boolean validaExist(WebElement elemento) {

        try {


            elemento.isDisplayed();

        } catch (NoSuchElementException e) {
            // Si no se encuentra el elemento devuelve FALSE
            return false;
        } catch (StaleElementReferenceException e) {
            // Si no se encuentra el elemento devuelve FALSE
            return false;
        } catch (Exception e) {
            // Si no se encuentra el elemento devuelve FALSE
            return false;
        }

        // Si se encuentra el elemento devuelve TRUE
        return true;

    }

    /**
     * Metodo para que no existan EXCEPCIONes al momento de hacer clic Fecha de
     * Creacion: 20-02-2020.
     *
     * @param elemento the elemento
     * @return true, if successful
     * @author Rodrigo Sanchez
     */
    public static boolean clicException(WebElement elemento) {

        try {


            // Click en el elemento
            elemento.click();
        } catch (ElementClickInterceptedException e) {
            // Si no se encuentra el elemento devuelve FALSE
            return false;
        } catch (NoSuchElementException e) {
            // Si no se encuentra el elemento devuelve FALSE
            return false;
        } catch (StaleElementReferenceException e) {
            // Si no se encuentra el elemento devuelve FALSE
            return false;
        } catch (Exception e) {
            // Si no se encuentra el elemento devuelve FALSE
            return false;
        }

        // Si se encuentra el elemento devuelve TRUE
        return true;
    }

    /**
     * Metodo para formatear un rut para una consulta Fecha de Creacion: 20-02-2020.
     *
     * @param rut xx.xxx.xxx-x
     * @return rut formato sin punto ni guion y digito verificador
     * @author Carlos Fuentes
     */
    public static String formatearRUTConsuta(String rut) {

        int cont = 0;
        String format;
        rut = rut.replace(".", "");
        rut = rut.replace("-", "");
        format = rut.substring(0, rut.length() );
        return format;

    }

    /**
     * Metodo para obtener fecha calendario Fecha de Creacion: 20-02-2020.
     *
     * @param dias the dias
     * @return retorna un array de tipo string con el dia, mes y anio
     * @author Carlos Fuentes
     */
    public String[] obtenerFechaCalendario(int dias) {
        SimpleDateFormat calendar = new SimpleDateFormat("dd/MM/yyyy");
        String fechaComoCadena = calendar.format(sumarRestarDIAS(new Date(), dias));
        String[] fecha = fechaComoCadena.split("/");
        String dia = fecha[0];
        String mes = "";
        String anio = fecha[2];
        switch (fecha[0]) {
            case "09":
                dia = "9";
                break;
            case "08":
                dia = "8";
                break;
            case "07":
                dia = "7";
                break;
            case "06":
                dia = "6";
                break;
            case "05":
                dia = "5";
                break;
            case "04":
                dia = "4";
                break;
            case "03":
                dia = "3";
                break;
            case "02":
                dia = "2";
                break;
            case "01":
                dia = "1";
                break;
        }

        switch (fecha[1]) {
            case "01":
                mes = "ENE.";
                break;
            case "02":
                mes = "FEB.";
                break;
            case "03":
                mes = "MAR.";
                break;
            case "04":
                mes = "ABR.";
                break;
            case "05":
                mes = "MAY.";
                break;
            case "06":
                mes = "JUN.";
                break;
            case "07":
                mes = "JUL.";
                break;
            case "08":
                mes = "AGO.";
                break;
            case "09":
                mes = "SEPT.";
                break;
            case "10":
                mes = "OCT.";
                break;
            case "11":
                mes = "NOV.";
                break;
            case "12":
                mes = "DIC.";
                break;
        }
        String[] fechaFormateada = new String[3];
        fechaFormateada[0] = dia;
        fechaFormateada[1] = mes;
        fechaFormateada[2] = anio;

        return fechaFormateada;
    }

    /**
     * Metodo para validar descarga y eliminar archivo Fecha de Creacion:
     * 20-02-2020.
     *
     * @param ruta     the ruta
     * @param eliminar the eliminar
     * @return true o false si no existe
     * @author Carlos Fuentes
     */
    public boolean validarDescarga(String ruta, String eliminar) {
        //String ejemploRuta = "c:\misficheros\fichero.txt";

        File fichero = new File(ruta);

        if (fichero.exists()) {
            if (eliminar.equalsIgnoreCase("SI")) {
                fichero.delete();
            }
            reporteConYSinImagen(true, "Descarga de documento", "Se ha validado correctamente la descarga del documento en la ruta " + ruta,
                    EstadoPrueba.PASSED, false);
            return true;
        } else {
            reporteConYSinImagen(true, "Descarga de documento",
                    "No se ha podido validar la descarga del documento en la ruta " + ruta, EstadoPrueba.FAILED, true);
            return false;

        }
    }


    /**
     * Metodo para validar cuadro de mensaje con error Fecha de Creacion:
     * 20-02-2020.
     *
     * @author Carlos Fuentes M
     */
    public void comprobarAlertaError() {

        if (validaExist("//p[@class='alert__text']")) {

            reporteConYSinImagen(true, "Ha ocurrio un error", "Se ha visualizado un mensaje: 'Ha ocurrio un error'",
                    EstadoPrueba.FAILED, true);

        } else if (validaExist("//p[contains(text(),'Ocurri\u00F3 un error')]")) {
            reporteConYSinImagen(true, "Ocurrio un error", "Se ha visualizado un mensaje: 'Ocurrio un error'",
                    EstadoPrueba.FAILED, true);
        }

    }

    /**
     * Valida elemento.
     *
     * @param element the element
     * @param timeOut the time out
     * @return true, if successful
     * @throws Exception the exception
     */
    public static boolean validaElemento(String element, int timeOut) throws Exception {

        int limite = timeOut;
        int tiempo = 0;
        Boolean flag = null;

        // Si no existe ingresa al Bucle
        if (!validaExist(element)) {

            // Recorre mientras el elemento no se encuentra presente y tiempo no llega al
            // limite
            while (!validaExist(element)) {

                tiempo++;

                // Si supera limite de tiempo falla y relanza una EXCEPCION
                if (tiempo == limite) {
                    capEvidencia("No se encuentra el elemento: " + element,
                            "No fue posible localizar el siguiente elemento: " + element, false);
                    throw new Exception("No se logro visualizar el elemento");
                }

            }

        }

        return true;
    }

    /**
     * Metodo que devuelve el texto de un elemento, recibe el xpath Fecha de
     * Creacion: 25-02-2020.
     *
     * @param xpath the xpath
     * @return the string
     * @author Rodrigo Sanchez
     */
    public static String capturarTexto(String xpath) {

        if (!validaExist(xpath)) {
            PdfBciReports.addWebReportImage("Obtener Texto",
                    "No se encontro elemento al que se queria obtener el texto", EstadoPrueba.FAILED, true);
        }

        String texto = DriverContextWeb.getDriverWeb().findElement(By.xpath(xpath)).getText();
        return texto;
    }

    /**
     * Metodo que devuelve el texto de un elemento, recibe el xpath Fecha de
     * Creacion: 25-02-2020.
     *
     * @param element        the element
     * @param nombreElemento the nombre elemento
     * @param timeOut        the time out
     * @param imagen         the imagen
     * @author Carlos Fuentes
     */
    public static void validaElemento(WebElement element, String nombreElemento, int timeOut, boolean imagen)  {
        LOGGER.info("Valida el elemento: " + nombreElemento);
        WebElement result = null;

        int countTimeOut = 0;
        do {
            try {
                element.isDisplayed();
                pausa(1);
                LOGGER.fine("Valida si esta desplegado: " + nombreElemento);
                if (element.isDisplayed()) {
                    LOGGER.info("El elemento ha sido encontrado: " + nombreElemento);
                    reporteConYSinImagen(imagen, nombreElemento, "El elemento ha sido encontrado: " + nombreElemento,
                            EstadoPrueba.PASSED, false);
                    result = element;
                }

            } catch (Exception e) {
                LOGGER.info("Espero " + countTimeOut);

            }

            countTimeOut++;
            if (result == null && countTimeOut == timeOut) {
                LOGGER.severe("El elemento no es visible en la pagina.:" + nombreElemento);
                reporteConYSinImagen(true, nombreElemento, "El elemento no es visible en la pagina.:" + nombreElemento,
                        EstadoPrueba.FAILED, true);
                break;
            }
        } while (result == null && countTimeOut < timeOut);

    }

    public static void validaElementox(WebElement element, String nombreElemento, int timeOut, boolean imagen)  {
        LOGGER.info("Valida el elemento: " + nombreElemento);
        WebElement result = null;

        int countTimeOut = 0;
        do {
            try {
                element.isDisplayed();
                pausa(2);
                LOGGER.fine("Valida si esta desplegado: " + nombreElemento);
                if (element.isDisplayed()) {
                    LOGGER.info("El elemento ha sido encontrado: " + nombreElemento);
                    reporteConYSinImagen(imagen, nombreElemento, "El elemento ha sido encontrado: " + nombreElemento,
                            EstadoPrueba.PASSED, false);
                    result = element;
                }

            } catch (Exception e) {
                LOGGER.info("Espero " + countTimeOut);

            }

            countTimeOut++;
            if (result == null && countTimeOut == timeOut) {
                LOGGER.severe("El elemento no es visible en la pagina.:" + nombreElemento);
                reporteConYSinImagen(true, nombreElemento, "El elemento no es visible en la pagina.:" + nombreElemento,
                        EstadoPrueba.FAILED, true);
                break;
            }
        } while (result == null && countTimeOut < timeOut);

    }
    public static void pausa(long segundo) {
        esperar((int) segundo);
    }

    /**
     * Metodo que devuelve el texto de un elemento, recibe el xpath Fecha de
     * Creacion: 25-02-2020.
     *
     * @param elemento     the elemento
     * @param nombrePaso   the nombre paso
     * @param tiempoLimite the tiempo limite
     * @author Carlos Fuentes
     */
    public static void clic(WebElement elemento, String nombrePaso, int tiempoLimite) {
        try {

            int tiempo = 0;

            // Valida que el elemento este desplegado
            if (validaExist(elemento)) {

                while (tiempo != tiempoLimite) {

                    if (clicException(elemento)) {
                        tiempo = tiempoLimite - 1;
                    }

                    // Si aun existe error al hacer click y se cumple el limite de tiempo
                    if (tiempo == tiempoLimite) {
                        LOGGER.severe("El elemento no ha sido encontrado o no es clickeable");
                        reporteConYSinImagen(true, nombrePaso, "El elemento no ha sido encontrado o no es clickeable",
                                EstadoPrueba.FAILED, true);
                        // throw new Exception("El Loading supero 1 minuto de espera");
                    }

                    tiempo++;

                }

            } else {

                // Recorre mientras el elemento no esta desplegado
                while (!validaExist(elemento)) {


                    tiempo++;

                    // Si supera limite de tiempo falla y relanza una EXCEPCION
                    if (tiempo == tiempoLimite) {
                        LOGGER.severe("El elemento no ha sido encontrado o no es clickeable");
                        reporteConYSinImagen(true, nombrePaso, "El elemento no ha sido encontrado o no es clickeable", EstadoPrueba.FAILED, true);
                    }

                }

                LOGGER.info("Click en el elemento" + elemento);
                elemento.click();
                LogErrorInChrome.GetJSErrorLog("click al elemento "+ elemento);
            }
        } catch (Exception e) {
            LOGGER.severe("Se presenta una EXCEPCION");
            reporteConYSinImagen(true, "Se presenta una EXCEPCION", "Se presenta una EXCEPCION:" + e,
                    EstadoPrueba.FAILED, true);
        }
    }

    /**
     * Metodo para obtener rut y dv para consulta Fecha de Creacion: 10-0-2020.
     *
     * @param rut xx.xxx.xxx-x o xxxxxxxx-x
     * @return retorna un array de tipo string con rut y dv separados
     * @author Sebastian Almuna
     */
    public String[] formatearRutDvConsulta(String rut) {
        String[] formatoRut = new String[2];
        String dv = rut.substring(rut.length() - 1);
        rut = rut.replace(".", "");
        rut = rut.replace("-", "");
        rut = rut.substring(0, rut.length() - 1);

        formatoRut[0] = rut;
        formatoRut[1] = dv;
        return formatoRut;
    }


    /**
     * Metodo que devuelve un arreglo con un rango de 6 minutos de la fecha actual,
     * normalmente usado para consultas a journal Fecha de Creacion: 05-03-2020.
     *
     * @return the string[]
     * @author Jose Quinteros
     */
    public String[] obtenerFecha() {

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        java.util.Date fechadesde = new java.util.Date();
        Calendar hora = Calendar.getInstance();
        hora.add(Calendar.MINUTE, -5);
        Date fechahasta = hora.getTime();
        String fechad = formatter.format(fechahasta);

        hora.add(Calendar.MINUTE, 8);
        fechahasta = hora.getTime();
        String fechah = formatter.format(fechahasta);

        String[] fecharango = {fechah, fechad};

        return fecharango;
    }

    /**
     * Metodo que valida que un elemento no se encuentre Fecha de Creacion:
     * 05-03-2020.
     *
     * @param element        the element
     * @param nombreElemento the nombre elemento
     * @param timeOut        the time out
     * @param imagen         the imagen
     * @author Jose Quinteros R
     */
    public static void validaElementoNoExiste(WebElement element, String nombreElemento, int timeOut, boolean imagen) {

        int countTimeOut = 0;

        do {
            try {
                esperar(1);
                if (element.isEnabled()) {
                    reporteConYSinImagen(true, nombreElemento, "El elemento es visible en la pagina.",
                            EstadoPrueba.FAILED, true);
                    //finalizaTest();
                }
            } catch (ElementClickInterceptedException e) {
                System.err.println("Espero " + countTimeOut + " segundo.");

            } catch (StaleElementReferenceException e) {
                System.err.println("Espero " + countTimeOut + " segundo.");

            } catch (Exception e) {
                System.err.println("Espero " + countTimeOut + " segundo.");
            }

            countTimeOut++;

        } while (countTimeOut < timeOut);
        reporteConYSinImagen(imagen, nombreElemento, "El elemento " + nombreElemento + " no se visualiza",
                EstadoPrueba.PASSED, false);

    }

    /**
     * Cantidad de elementos.
     *
     * @param xpath  the xpath
     * @param driver the driver
     * @return the int
     */
    public int cantidadDeElementos(String xpath, org.openqa.selenium.WebDriver driver) {

        int rowCount = driver.findElements(By.xpath("+xpath+")).size();
        return rowCount;
    }

    /**
     * Comparar elementos asc.
     *
     * @param elemento1 the elemento 1
     * @param elemento2 the elemento 2
     */
    public void compararElementosAsc(String elemento1, String elemento2) {
        if (elemento1.compareTo(elemento2) <= 0) {
            //LOGGER.info("el elemento: " + elemento1 + " es menor o igual al elemento: " + elemento2);
            reporteConYSinImagen(false, "orden no ascendente",
                    "El elemento " + elemento1 + " es mayor al elemento " + elemento2, EstadoPrueba.PASSED, false);

        } else {
            reporteConYSinImagen(true, "orden no ascendente",
                    "El elemento " + elemento1 + " es mayor al elemento " + elemento2, EstadoPrueba.FAILED, true);
        }
    }

    /**
     * Metodo que devuelve un rut generado de manera aleatorea (entre 1m y 5m) Fecha
     * de Creacion: 05-03-2020.
     *
     * @return the string
     * @author Jose Quinteros
     */
    public String GenerarRut() {

        int rut = (int) (Math.random() * 50000000 + 10000000);
        rut = rut + 10000000;
        String DV;
        int multiplicador = 2;
        int numeroTemporal;
        String rutCompleto = String.valueOf(rut);
        int total = 0;
        int divisor = 10;

        for (int i = 0; i < rutCompleto.length(); i++) {
            numeroTemporal = rut % divisor;
            total = total + (numeroTemporal * multiplicador);
            multiplicador++;
            if (multiplicador == 8) {
                multiplicador = 2;
            }
            rut = rut / 10;
        }
        total = total % 11;
        total = 11 - total;
        DV = String.valueOf(total);

        if (DV.equals("10")) {
            DV = "k";
        } else if (DV.equals("11")) {
            DV = "0";
        }
        rutCompleto = rutCompleto + "-" + DV;
        return rutCompleto;
    }

    /**
     * Metodo para validar query Fecha de Creacion: 07-03-2020.
     *
     * @param valorQuery    the valor query
     * @param valorEsperado the valor esperado
     * @param Query         the query
     * @author Jose Quinteros R
     */
    public void validarQuery(String valorQuery, String valorEsperado, String Query) {
        if (valorQuery != null) {

            PdfBciReports.addReport("validacion de que la query trae datos",
                    "la query trae datos, Query usada: " + Query, EstadoPrueba.PASSED, false);
            if (valorQuery.equalsIgnoreCase(valorEsperado)) {
                PdfBciReports.addWebReportImage(
                        "Resultado consistente", "el valor traido de base de datos es: " + valorQuery
                                + " y el valor esperado es: " + valorEsperado + ". La query usada es : " + Query,
                        EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addWebReportImage(
                        "Resultado inconsistente", "el valor traido de base de datos es: " + valorQuery
                                + " y el valor esperado es: " + valorEsperado + ". La query usada es : " + Query,
                        EstadoPrueba.FAILED, true);
            }
        } else {
            PdfBciReports.addWebReportImage("Query vacia", "la query no tiene trae datos, Query usada: " + Query,
                    EstadoPrueba.FAILED, true);
        }
    }

    /**
     * Metodo para validar estado elemento con msje Fecha de Creacion: 11-03-2020.
     *
     * @param elemento       the elemento
     * @param nombreElemento the nombre elemento
     * @author Sebastian Almuna P
     */
    public void comprobarCampoHabilitado(WebElement elemento, String nombreElemento) {

        if (elemento.isEnabled()) {
            PdfBciReports.addWebReportImage(nombreElemento, "Elemento " + nombreElemento + " habilitado",
                    EstadoPrueba.PASSED, false);
        } else {
            PdfBciReports.addWebReportImage(nombreElemento, "Elemento " + nombreElemento + " no habilitado",
                    EstadoPrueba.FAILED, true);
        }
    }

    /**
     * Numeros random.
     *
     * @param primero the primero
     * @param ultimo  the ultimo
     * @return the string
     */
    public static String NumerosRandom(int primero, int ultimo) {
        int valorEntero = (int) Math.floor(Math.random() * (ultimo - primero + 1) + primero);
        String resultado = Integer.toString(valorEntero);
        return resultado;
    }

    /**
     * * Metodo que borra un campo de texto Fecha Creacion: 02-04-2020.
     *
     * @param elemento the elemento
     * @author Nicolas Guzman
     */

    public static void borrarCampoInput(WebElement elemento) {
        String resultado = elemento.getAttribute("value");
        while (!resultado.isEmpty()) {
            elemento.sendKeys(Keys.BACK_SPACE);
            resultado = elemento.getAttribute("value");
        }
    }

    /**
     * Metodo que valida la cantidad de registros en el front y BBDD Fecha Creacion:
     * 02-04-2020.
     *
     * @param valorQuery    the valor query
     * @param valorEsperado the valor esperado
     * @author Patricia Vera
     */

    public void validarQueryRegistro(String valorQuery, String valorEsperado) {
        if (valorQuery != null) {
            PdfBciReports.addReport("Los registros de la query coinciden con el front",
                    "Los registros de la query coinciden con el front", EstadoPrueba.PASSED, false);
            if (valorQuery.equalsIgnoreCase(valorEsperado)) {

                PdfBciReports.addWebReportImage(
                        "Resultado consistente", "el valor traido de base de datos es: " + valorQuery
                                + " y el valor esperado es: " + valorEsperado + "Los registros coinciden ",
                        EstadoPrueba.PASSED, false);

            } else {
                PdfBciReports.addWebReportImage(
                        "Resultado inconsistente", "el valor traido de base de datos es: " + valorQuery
                                + " y el valor esperado es: " + valorEsperado + "Los registros coinciden ",
                        EstadoPrueba.FAILED, true);
            }
        }
    }

    /**
     * Metodo que lee un excel XLS y devuelte una lista con datos Fecha de Creacion:
     * 21-04-2020.
     *
     * @param rutaArchivo the ruta archivo
     * @param columna     the columna
     * @return the list
     * @author Carlos Fuentes
     */
    public List<String> leerExcelXLS(String rutaArchivo, int columna) {
        List datosAlmacenados = new ArrayList<>();
        try {
            // se pasa la ruta del archivo
            FileInputStream archivo = new FileInputStream(rutaArchivo);
            Workbook workbook = new XSSFWorkbook(archivo);
            // se especifica el numero de la hoja
            Sheet hoja = workbook.getSheetAt(0);
            int numFilas = hoja.getLastRowNum();
            // Se\F1alas el numero de la fila que necesites extraer datos
            Row datos = hoja.getRow(columna);
            Iterator<Cell> cellIterator = datos.cellIterator();
            Cell cell;
            while (cellIterator.hasNext()) {
                // se obtiene la celda en espec\EDfico
                cell = cellIterator.next();
                // se agregan los datos a una lista
                datosAlmacenados.add(cell);
            }
        } catch (Exception e) {
            e.getMessage();
        }
        return datosAlmacenados;
    }

    /**
     * Metodo que devuelve la cantidad de resultados enviando el xpath Fecha
     * Creaci\F3n: 29-04-2020
     * <p>
     * Count.
     *
     * @param xpath the xpath
     * @return the int
     * @author Carol Oyarzun
     */
    public int count(String xpath) {
        try {
            return DriverContextWeb.getDriverWeb().findElements(By.xpath(xpath)).size();
        } catch (Exception e) {
            finalizaTest();
            throw e;
        }
    }

    /**
     * Te devuelve si es el unico resultado del xpath. Creacion: 29-04-2020
     *
     * @param xpath the xpath *
     * @return true, if successful
     * @author Carol Oyarzun
     */
    public boolean existe(String xpath) {
        int esUnico = count(xpath);
        return esUnico == 1;

    }

    /**
     * No existe.
     *
     * @param xpath the xpath
     * @return true, if successful
     * @author Carol Oyarzun
     */
    public boolean noExiste(String xpath) {
        int esUnico = count(xpath);
        return esUnico == 0;

    }

    /**
     * Obtiene el mes.
     *
     * @param mes the mes
     * @return the string
     * @author Carol Oyarzun
     */
    public static String obtenerNombreMes(String mes) {
        switch (mes) {
            case "01":
                mes = "ENE.";
                break;
            case "02":
                mes = "FEB.";
                break;
            case "03":
                mes = "MAR.";
                break;
            case "04":
                mes = "ABR.";
                break;
            case "05":
                mes = "MAY.";
                break;
            case "06":
                mes = "JUN.";
                break;
            case "07":
                mes = "JUL.";
                break;
            case "08":
                mes = "AGO.";
                break;
            case "09":
                mes = "SEPT.";
                break;
            case "10":
                mes = "OCT.";
                break;
            case "11":
                mes = "NOV.";
                break;
            case "12":
                mes = "DIC.";
                break;
        }
        return mes;
    }

    /**
     * Elimina el 0 del dia, aplica para los numeros 01 hasta 09.
     *
     * @param dia the dia
     * @return the string
     * @author Carol Oyarzun
     */
    public String obtenerDia(String dia) {

        switch (dia) {
            case "01":
                dia = "1";
                break;
            case "02":
                dia = "2";
                break;
            case "03":
                dia = "3";
                break;
            case "04":
                dia = "4";
                break;
            case "05":
                dia = "5";
                break;
            case "06":
                dia = "6";
                break;
            case "07":
                dia = "7";
                break;
            case "08":
                dia = "8";
                break;
            case "09":
                dia = "9";
                break;

        }
        return dia;
    }

    /**
     * Validar query distinto.
     *
     * @param valorQuery    the valor query
     * @param valorEsperado the valor esperado
     * @param Query         the query
     * @author Carol Oyarzun
     */
    public void validarQueryDistinto(String valorQuery, String valorEsperado, String Query) {
        if (valorQuery != null) {

            PdfBciReports.addReport("validacion de que la query trae datos",
                    "la query trae datos, Query usada: " + Query, EstadoPrueba.PASSED, false);
            if (!valorEsperado.equals(valorQuery)) {
                PdfBciReports.addWebReportImage(
                        "Resultado consistente", "el valor traido de base de datos es: " + valorQuery
                                + " es distinto a: " + valorEsperado + ". La query usada es : " + Query,
                        EstadoPrueba.PASSED, false);
            } else {
                PdfBciReports.addWebReportImage(
                        "Resultado inconsistente", "el valor traido de base de datos es: " + valorQuery
                                + " y el valor esperado es: " + valorEsperado + ". La query usada es : " + Query,
                        EstadoPrueba.FAILED, true);
            }
        } else {
            PdfBciReports.addWebReportImage("Query vacia", "la query no tiene trae datos, Query usada: " + Query,
                    EstadoPrueba.FAILED, true);
        }
    }

    /**
     * Compara string.
     *
     * @param palabra  the palabra
     * @param comparar the comparar
     * @author Carol Oyarzun
     */
    public void comparaString(String palabra, String comparar) {
        if (StringUtils.isNotBlank(palabra) && palabra.equals(comparar)) {
            PdfBciReports.addWebReportImage("Resultado consistente",
                    "el valor: " + palabra + " coincide con el esperado :" + comparar, EstadoPrueba.PASSED, false);
        } else {
            PdfBciReports.addWebReportImage("Resultado consistente",
                    "el valor: " + palabra + " no coincide con el esperado :" + comparar, EstadoPrueba.FAILED, true);
        }
    }

    /**
     * Compara string distinto.
     *
     * @param palabra  the palabra
     * @param comparar the comparar
     * @author Carol Oyarzun
     */
    public void comparaStringDistinto(String palabra, String comparar) {
        if (StringUtils.isNotBlank(palabra) && !palabra.equals(comparar)) {
            PdfBciReports.addWebReportImage("Resultado consistente",
                    "el valor: " + palabra + " distinto con el esperado :" + comparar, EstadoPrueba.PASSED, false);
        } else {
            PdfBciReports.addWebReportImage("Resultado consistente",
                    "el valor: " + palabra + " coincide con el esperado :" + comparar, EstadoPrueba.FAILED, true);
        }
    }

    /**
     * Eliminar descarga.
     *
     * @param ruta the ruta
     * @author Carol Oyarzun
     */
    public void eliminarDescarga(String ruta) {
        try {
            File fichero = new File(ruta);

            if (fichero.exists()) {
                LOGGER.info("Se elimina el archivo " + ruta);
                fichero.delete();
            }
        } catch (Exception e) {
            LOGGER.severe("Se presenta una EXCEPCION");
            reporteConYSinImagen(true, "Se presenta una EXCEPCION", "Se presenta una EXCEPCION:" + e,
                    EstadoPrueba.FAILED, true);
        }
    }

    /**
     * Valida fila excel.
     *
     * @param url     the url
     * @param fila    the fila
     * @param columna the columna
     * @param nombre  the nombre
     * @author Carol Oyarzun
     */
    public void validaFilaExcel(String url, int fila, int columna, String nombre) {
        try {
            LOGGER.info("Se selecciona la fila en el excel");
            List<String> a = leerExcelXLS(url, fila);
            Cell[] excelArray = new Cell[a.size()];
            excelArray = a.toArray(excelArray);
            String valorExcel = excelArray[columna].toString();

            LOGGER.info("Se compara excel y el string");
            comparaString(valorExcel, nombre);

        } catch (Exception e) {
            LOGGER.severe("Se presenta una EXCEPCION. METODO: validaFilaExcel");
            reporteConYSinImagen(true, "Se presenta una EXCEPCION", "Se presenta una EXCEPCION:" + e,
                    EstadoPrueba.FAILED, true);
        }
    }


    public void validaFilaExcelDistinto(String url, int fila, int columna, String nombre) {
        try {
            LOGGER.info("Se selecciona la fila en el excel");
            List<String> a = leerExcelXLS(url, fila);
            Cell[] excelArray = new Cell[a.size()];
            excelArray = a.toArray(excelArray);
            String valorExcel = excelArray[columna].toString();

            LOGGER.info("Se compara excel y el string");
            comparaStringDistinto(valorExcel, nombre);

        } catch (Exception e) {
            LOGGER.severe("Se presenta una EXCEPCION. METODO: validaFilaExcelDistinto");
            reporteConYSinImagen(true, "Se presenta una EXCEPCION", "Se presenta una EXCEPCION:" + e,
                    EstadoPrueba.FAILED, true);
        }
    }

    /**
     * Metodo que lee un excel y devuelte una lista con datos
     * Fecha de Creacion: 01-04-2020
     *
     * @author Carlos Fuentes
     */
    public List<String> leerExcel(String rutaArchivo, int columna) {
        List datosAlmacenados = new ArrayList<>();
        try {
            // se pasa la ruta del archivo
            FileInputStream archivo = new FileInputStream(rutaArchivo);
            HSSFWorkbook workbook = new HSSFWorkbook(archivo);
            // se especifica el numero de la hoja
            HSSFSheet hoja = workbook.getSheetAt(0);
            int numFilas = hoja.getLastRowNum();
            // Señalas el numero de la fila que necesites extraer datos
            Row datos = hoja.getRow(columna);
            Iterator<Cell> cellIterator = datos.cellIterator();
            Cell cell;
            while (cellIterator.hasNext()) {
                // se obtiene la celda en específico
                cell = cellIterator.next();
                // se agregan los datos a una lista
                datosAlmacenados.add(cell);
            }

        } catch (Exception e) {
            e.getMessage();
        }
        return datosAlmacenados;

    }

    public String obtieneValorExcel(String url, int fila, int columna) {
        try {
            LOGGER.info("Se selecciona la fila en el excel");
            List<String> a = leerExcelXLS(url, fila);
            Cell[] excelArray = new Cell[a.size()];
            excelArray = a.toArray(excelArray);
            return excelArray[columna].toString();

        } catch (Exception e) {
            LOGGER.severe("Se presenta una EXCEPCION. METODO: validaFilaExcel");
            reporteConYSinImagen(true, "Se presenta una EXCEPCION", "Se presenta una EXCEPCION:" + e,
                    EstadoPrueba.FAILED, true);
            return "-1";
        }
    }

    public void contieneString(String palabra, String contenido) {
        if (StringUtils.isNotBlank(palabra) && palabra.contains(contenido)) {
            PdfBciReports.addWebReportImage("Resultado consistente",
                    "el valor: " + palabra + " coincide con el esperado :" + contenido, EstadoPrueba.PASSED, false);
        } else {
            PdfBciReports.addWebReportImage("Resultado inconsistente",
                    "el valor: " + palabra + " no coincide con el esperado :" + contenido, EstadoPrueba.FAILED, true);
        }
    }

    /**
     * Metodo para comparar elemento con msje
     * Fecha de Creacion: 21-07-2020
     *
     * @author Sebastian Almuna
     */
    public void compararDosElementos(String elementoUno, String elementoDos, String msje) {
        if (elementoUno.equals(elementoDos)) {
            PdfBciReports.addWebReportImage(elementoDos, "Campo consultado en correo corresponde a :" + elementoUno + " " + msje, EstadoPrueba.PASSED, false);
        } else {
            PdfBciReports.addWebReportImage(elementoDos, "Campo consultado en correo corresponde a :" + elementoUno + " " + msje, EstadoPrueba.FAILED, true);
        }
    }

    public String validarDescargaDinamicoSegundos(String ruta, String eliminar, int tiempo, String extension) {
        try {
            LOGGER.info("Se realiza la descarga excel");
            LocalDateTime fechadescarga = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss");
            String fechad = formatter.format(fechadescarga);
            String rutaCompleta = ruta + fechad + "." + extension;
            LOGGER.info("Se genera la ruta archivo " + rutaCompleta);
            File fichero = new File(rutaCompleta);
            int contador = 0;
            String nombreArchivo = "";
            boolean encontrado = false;
            if (fichero.exists()) {
                reporteConYSinImagen(true, "Descarga de documento", "Se ha validado correctamente el documento " + rutaCompleta,
                        EstadoPrueba.PASSED, false);
                nombreArchivo = fichero.getName();
                encontrado = true;
                if (eliminar.equalsIgnoreCase("SI")) {
                    fichero.delete();
                }
            } else {
                LOGGER.info("Se valida tiempo atras");
                while (!fichero.exists() && contador < tiempo && encontrado == false) {
                    LocalDateTime fechadescargaMenos = fechadescarga.minusSeconds(contador);
                    fechad = formatter.format(fechadescargaMenos);
                    rutaCompleta = ruta + fechad + "." + extension;
                    fichero = new File(rutaCompleta);
                    if (fichero.exists()) {
                        reporteConYSinImagen(true, "Descarga de documento", "Se ha validado correctamente el documento " + rutaCompleta,
                                EstadoPrueba.PASSED, false);
                        encontrado = true;
                        nombreArchivo = fichero.getName();
                        if (eliminar.equalsIgnoreCase("SI")) {
                            fichero.delete();
                        }
                        break;
                    } else {
                        LOGGER.info(contador + " No se encontro el archivo " + rutaCompleta);
                        contador = contador + 1;
                    }
                }
                contador = 0;
                LOGGER.info("Se valida tiempo adelante");
                while (!fichero.exists() && contador < tiempo && encontrado == false) {
                    LocalDateTime fechadescargaMas = fechadescarga.plusSeconds(contador);
                    fechad = formatter.format(fechadescargaMas);
                    rutaCompleta = ruta + fechad + "." + extension;
                    fichero = new File(rutaCompleta);
                    if (fichero.exists()) {
                        reporteConYSinImagen(true, "Descarga de documento", "Se ha validado correctamente el documento " + rutaCompleta,
                                EstadoPrueba.PASSED, false);
                        encontrado = true;
                        nombreArchivo = fichero.getName();
                        if (eliminar.equalsIgnoreCase("SI")) {
                            fichero.delete();
                        }
                        break;
                    } else {
                        LOGGER.info(contador + " No se encontro el archivo " + rutaCompleta);
                        contador = contador + 1;
                    }
                }

            }
            if (contador == tiempo && encontrado == false) {
                reporteConYSinImagen(true, "Descarga de documento",
                        "No se ha podido validar la descarga del documento" + rutaCompleta, EstadoPrueba.FAILED, true);
            }
            return nombreArchivo;
        } catch (Exception e) {
            reporteConYSinImagen(true, "encontro una exepcion", "encontro una exepcion " + e, EstadoPrueba.FAILED, true);
            return "-1";
        }
    }

	/*
	public String lecturaPdf(String rutaArchivo) {
		try {
			File file = new File(rutaArchivo);
			PDDocument document = PDDocument.load(file);
			PDFTextStripper pdfStripper = new PDFTextStripper();
			LOGGER.info("Se obtiene el texto");
			String text = pdfStripper.getText(document);
			document.close();
			return text;
		} catch (Exception e) {
			reporteConYSinImagen(true, "encontro una exepcion", "encontro una exepcion " + e, EstadoPrueba.FAILED, true);
			return "-1";
		}
	}

*/


    public String obtenerNombreMesCompleto(String mes) {
        switch (mes) {
            case "1":
                mes = "Enero";
                break;
            case "2":
                mes = "Febrero";
                break;
            case "3":
                mes = "Marzo";
                break;
            case "4":
                mes = "Abril";
                break;
            case "5":
                mes = "Mayo";
                break;
            case "6":
                mes = "Junio";
                break;
            case "7":
                mes = "Julio";
                break;
            case "8":
                mes = "Agosto";
                break;
            case "9":
                mes = "Septiembre";
                break;
            case "10":
                mes = "Octubre";
                break;
            case "11":
                mes = "Noviembre";
                break;
            case "12":
                mes = "Diciembre";
                break;
        }
        return mes;
    }

    public static boolean compareTextWithReport(WebElement elemento, String texto, boolean imageReport) {
        String textoObtenido = elemento.getText();
        if (textoObtenido.equals(texto)) {
            reporteConYSinImagen(imageReport, "Los textos coinciden: " + elemento.getText(), "El texto obtenido del elemento es el texto esperado.", EstadoPrueba.PASSED, false);
            return true;
        } else {
            reporteConYSinImagen(imageReport, "Los textos no coinciden:", "Texto Obtenido: " + textoObtenido + ".\nTexto Esperado: " + texto, EstadoPrueba.FAILED, false);
            int largoTexto = texto.length();
            do { // reachable end condition added
                largoTexto++;
            } while (largoTexto != Integer.MIN_VALUE);// true at Integer.MAX_VALUE +1
        }
        return false;
    }

    public static String rutaDescarga(File office, String rutaDescarga) {
        String sistemeOperativo=office.toString();
        if ("Mac OS X".equals(sistemeOperativo)) {
            rutaDescarga=rutaDescarga.replace("\\Downloads\\", "/Downloads/");
        }
        return rutaDescarga;
    }


}
