package util;

import driverWeb.DriverContextWeb;
import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;
import utils.DateFormater;
import utils.web.ControlledActionsWeb;
import utils.web.UtilsWeb;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.logging.Logger;

import static utils.MetodosGenericos.ucFirst;
import static utils.web.ControlledActionsWeb.loadingNegado;


public class MetodosGenericosInversiones {
    public static final Logger LOGGER = Logger.getLogger("MetodosGenericosInversiones");
    public MetodosGenericosInversiones() {
        PageFactory.initElements(DriverContextWeb.getDriverWeb(), this);
    }

    @FindBy(xpath = "//div[contains(@class,'tax-regime-description')]")
    private WebElement visTextoRegimen;



    public static String formatearRutTandem(String rut) {
        String rutFormateado = rut.replace(".", "");
        rutFormateado = rutFormateado.substring(0, rutFormateado.length() - 2);


        if (rutFormateado.length() == 8) {
            rutFormateado = "0" + rutFormateado;
        }

        if (rutFormateado.length() == 7) {
            rutFormateado = "00" + rutFormateado;
        }


        return rutFormateado;
    }

    public static String formatearRutCuentas(String rut) {
        String rutFormateado = rut.replace(".", "");
        rutFormateado = rutFormateado.substring(0, rutFormateado.length() - 2);


        if (rutFormateado.length() == 8) {
            rutFormateado = rutFormateado;
        }

        if (rutFormateado.length() == 7) {
            rutFormateado = rutFormateado;
        }


        return rutFormateado;
    }


    public static String procesarConsultaTandem(String resultado) {
        LOGGER.info("\n Método 'procesarConsultaTandem' \n");
        List<String> splitString = Arrays.asList(resultado.trim().split("  "));
        String registros = "|";
        String texto = "";

        for (int i = 0; i < splitString.size(); ++i) {
            if (splitString.get(i).contains("FinalSQL")) {
                texto = splitString.get(i);
                registros = registros + "|" + texto.replace("FinalSQL", "FinalSQL;");
            } else {
                registros = registros + splitString.get(i) + "|";
            }
        }

        registros = registros.replace("  ", "|").replaceAll("(\n|\r)", "|");

        do {
            registros = registros.replace("||", "|");
        } while (registros.indexOf("||") >= 0);

        LOGGER.info("\n" + registros + "\n");
        return registros;
    }


    public static void reporteValidacionContieneTexto(WebElement objeto, String textoEsperado) {
        try {
            boolean existeObjeto = ControlledActionsWeb.visualizarObjetoScroll(objeto, 5);
            if (existeObjeto) {

                if ((objeto.getText().trim().startsWith(textoEsperado))) {

                    LOGGER.info(objeto.getText().trim() + " == " + textoEsperado);
                    //PdfBciReports.addReport("Validación de objeto y texto", "El elemento posee el texto espereado:'" + textoEsperado + "' en la vista desplegada.", EstadoPrueba.PASSED, false);
                    PdfBciReports.addWebReportImage("Validación de objeto y texto", "El elemento posee el texto esperado:'" + textoEsperado + "' en la vista desplegada.", EstadoPrueba.PASSED, false);
                } else {
                    LOGGER.info(objeto.getText().trim() + " != " + textoEsperado);
                    PdfBciReports.addWebReportImage("Validación de objeto y texto", "El elemento no posee el texto esperado:'" + textoEsperado + "' en la vista desplegada.", EstadoPrueba.FAILED, false);
                }


            } else {
                PdfBciReports.addReport("Validación de objeto y texto", "No se visualiza el texto:'" + textoEsperado + "' en la vista desplegada.", EstadoPrueba.FAILED, false);
            }
        } catch (Exception var3) {
            LOGGER.info("No se  logra ejecutar funcion reporteValidacionTextos, motivo:" + var3.getMessage());
            PdfBciReports.addReport("Validación de objeto y texto", "Error en el método 'reporteValidacionTextos', motivo:" + var3.getMessage(), EstadoPrueba.FAILED, true);
        }

    }


    /**
     * Obtiene la hora del sistema
     *
     * @return
     */
    public static String obtenerHora() {

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
            Date EndTime = dateFormat.parse("14:00");
            LOGGER.info("\nLa hora1 es: " + EndTime + "\n");
            Date CurrenTime = dateFormat.parse(dateFormat.format(new Date()));
            LOGGER.info("\nLa hora2 es: " + CurrenTime + "\n");
            if (CurrenTime.after(EndTime)) {
                return "1";
            } else {
                return "2";
            }
        } catch (Exception e) {
            LOGGER.info("Error");
        }
        return null;
    }

    /**
     * Obtiene la hora del sistema cambiado en donde se duma 4 hr por que la hora lo toma
     * de Jenkins
     *
     * @return
     */
    public static String obtenerHora2() {

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
            Date EndTime = dateFormat.parse("18:00");
            LOGGER.info("\nLa hora1 es: " + EndTime + "\n");
            Date CurrenTime = dateFormat.parse(dateFormat.format(new Date()));
            LOGGER.info("\nLa hora2 es: " + CurrenTime + "\n");
            if (CurrenTime.after(EndTime)) {
                return "1";
            } else {
                return "2";
            }
        } catch (Exception e) {
            LOGGER.info("Error");
        }
        return null;
    }


    public static String getFechaActual() {
        LocalDate localDate = LocalDate.now();
        Locale spanishLocale = new Locale("es", "ES");
        String nameMonthActual = ucFirst(localDate.format(DateTimeFormatter.ofPattern("MMMM", spanishLocale)));
        String mes = DateFormater.getNumberFromMonth(nameMonthActual.trim());
        int dia = localDate.getDayOfMonth();
        int anio = localDate.getYear();
        String fecha = anio + "-" + StringUtils.right("0" + mes, 2) + "-" + StringUtils.right("0" + dia, 2);
        return fecha;
    }

    public static String calendarioFuLL() {
        LOGGER.info("========= 'Metodo calendarioFull'");

        Calendar cal = Calendar.getInstance();
        int diaHoy = cal.get(Calendar.DAY_OF_WEEK);

        if (diaHoy <= 5 && diaHoy>= 2) {
            String resp = "Si";
            return resp;
        } else if (diaHoy == 6 ) {
            String resp = "No";
            return resp;
        } else {
            LOGGER.info("Error en la búsqueda de día");
        }
        return null;
    }

    public static String calendarioFuLL3() {
        LOGGER.info("========= 'Metodo calendarioFull3'");

        LocalDateTime ldt = LocalDateTime.now().plusDays(3);
        DateTimeFormatter formatt1 = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH);

        String formatter = formatt1.format(ldt);
        return formatter;
    }

    public static String calendarioFuLL4() {
        LOGGER.info("========= 'Metodo calendarioFull4'");

        LocalDateTime ldt = LocalDateTime.now();
        DateTimeFormatter formatt2 = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH);

        String formatter3 = formatt2.format(ldt);
        return formatter3;
    }

    public static String calendarioFuLL5() {
        LOGGER.info("========= 'Metodo calendarioFull3'");

        LocalDateTime ldt = LocalDateTime.now().plusDays(1);
        DateTimeFormatter formatt1 = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH);

        String formatter = formatt1.format(ldt);
        return formatter;
    }

    public static void botonClic(WebElement element, String nombreBoton, String step) {
        LOGGER.info("\nMétodo -> 'botonClick'\n");

        try {
            String reporteFailed = "El Step falla porque no se encontro el elemento: " + nombreBoton + ".";
            loadingNegado(element, 3, reporteFailed, nombreBoton);
            UtilsWeb.enmarcarObjeto(element);
            if (!element.isEnabled()) {
                PdfBciReports.addReport(step, "El Step falla porque el botón: " + nombreBoton + " esta deshabilitado.", EstadoPrueba.FAILED, true);
            } else {
                PdfBciReports.addReport("Click en el elemento: " + nombreBoton, "[ControlledActions] El objeto '" + nombreBoton + "', se visualiza correctamente.", EstadoPrueba.PASSED, false);
            }

            UtilsWeb.desenmarcarObjeto(element);
            WebUtils.clickElement(element);
        } catch (NoSuchElementException var4) {
            PdfBciReports.addWebReportImage("Click en el botón", "[ControlledActions] Error: No se pudo encontrar elemento '" + nombreBoton + "' -> " + var4.getMessage(), EstadoPrueba.FAILED, true);
        }

    }

    public static String lecturaPdf(String rutaArchivo) {
        try {
            //LOGGER.info("ruta:" +rutaArchivo);
            File file = new File(rutaArchivo);
            //LOGGER.info("file:" +file);
            PDDocument document = PDDocument.load(file);
            //LOGGER.info("document:" +document);
            document.setAllSecurityToBeRemoved(true);
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String text = pdfStripper.getText(document);
            //LOGGER.info("text:" +text);
            document.close();
            return text;
        } catch (Exception e) {
            return "-1";
        }
    }

    public static String FormateoRut(String Rut){
        LOGGER.info("EliminacionRut");

        String Rutsinguion = Rut.replace("-","");
        String RutAcortado = Rutsinguion.substring(0, Rutsinguion.length() -1);

        return RutAcortado;
    }

    public static String FechaActual(){
        LOGGER.info("Metodo 'FechaActual'");

        SimpleDateFormat dtf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar calendar = Calendar.getInstance();

        Date dateObj = calendar.getTime();
        String formattedDate = dtf.format(dateObj);
        String FormateoDate = FormatearFechaDia(formattedDate);
        int FormateoMonth = FormatearFechaMonth();
        int FormateoYear = FormatearFechaYear();

        String FechaReal = FormateoDate+"/"+FormateoMonth+"/"+FormateoYear;
        LOGGER.info("Fecha actual es: "+FechaReal);
        return FechaReal;
    }

    public static String FormatearFechaDia(String formattedDate){
        LOGGER.info("Metodo 'FormatearFechaDia'");

        //Calendar cal = Calendar.getInstance();
        LocalDate cal = LocalDate.now();
        String formatCal = cal.toString();
        //DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        //String formatterString = localDate.format(formatter);
        //int diaHoy = cal.get(Calendar.DAY_OF_WEEK);
        LOGGER.info("formatCal: "+formatCal);
        String diaHoy = formatCal.substring(8,10);
        LOGGER.info("diaHoy: "+diaHoy);
        int diaHoy2 = Integer.parseInt(diaHoy);
        if (diaHoy2 < 10) {
            String FechaA = formattedDate.substring(9,10);
            LOGGER.info("Dia: "+FechaA);
            return FechaA;
        } else {
            //String var = "1";
            String diaHoyF = formatCal.substring(8,10);
            LOGGER.info("Se cambia día");
            return diaHoyF;
        }
    }

    public static Integer FormatearFechaMonth(){
        LOGGER.info("Metodo 'FormatearFechaMonth'");

        LocalDate localDate = LocalDate.now();
        Locale spanishLocale = new Locale("es", "ES");
        String nameMonthActual = ucFirst(localDate.format(DateTimeFormatter.ofPattern("MMMM", spanishLocale)));
        String mes = DateFormater.getNumberFromMonth(nameMonthActual.trim());
        int mesf = Integer.parseInt(mes);
        LOGGER.info(String.valueOf(mesf));
        if (mesf <= 10) {
            return mesf;
        } else {
            int var = Integer.parseInt("1");
            LOGGER.info("Dia sigue igual");
            return var;
        }
    }

    public static Integer FormatearFechaYear(){
        LOGGER.info("Metodo 'FormatearFechaYear'");

        int anno = Calendar.getInstance().get(Calendar.YEAR);
        return anno;
    }


    public static final String HOST_IC = "http://api-dsr01.bci.cl";
    public static final String HOST_QA = "http://api-crt01.bci.cl";

    public static final String valor2 = "18.693.924";
    public static final String valor3 = "1.557.827";
    public static final String UF = "31.157";

}