package util;

import lombok.experimental.UtilityClass;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * Clase utilitaria para fechas
 */
@UtilityClass
public class DateTimeUtils {

    /**
     * Parsea una fecha a objeto Date
     * @param date FechaStr
     * @param pattern Patron de fecha
     * @return Objeto Date o Null
     */
    public static Date parseDate(String date, String pattern) {
        try {
            SimpleDateFormat inputParser = new SimpleDateFormat(pattern);
            return inputParser.parse(date);
        } catch (ParseException e) {
            return null;
        }
    }

    /**
     * LocalDate a String
     * @param localDate LocalDate
     * @param outputPattern Patron esperado
     * @return LocalDate como String
     */
    public static String localDateToString(LocalDate localDate, String outputPattern){
        return localDate.format(DateTimeFormatter.ofPattern(outputPattern));
    }

    /**
     * LocalDate a String
     * @param localDateTime LocalDateTime
     * @param outputPattern Patron esperado
     * @return LocalDateTime como String
     */
    public static String localDateTimeToString(LocalDateTime localDateTime, String outputPattern){
        return localDateTime.format(DateTimeFormatter.ofPattern(outputPattern));
    }

    /**
     * String a LocalDate
     * @param date DateString
     * @param inputPattern Patron de fecha
     * @return LocalDate Object
     */
    public static LocalDate stringToLocalDate(String date, String inputPattern) {
        return LocalDate.parse(date, DateTimeFormatter.ofPattern(inputPattern));
    }

    /**
     * String a LocalDateTime
     * @param date DateString
     * @param inputPattern Patron de fecha
     * @return LocalDateTime Object
     */
    public static LocalDateTime stringToLocalDateTime(String date, String inputPattern) {
        return LocalDateTime.parse(date, DateTimeFormatter.ofPattern(inputPattern));
    }

    /**
     * String a LocalTime
     * @param time TimeString
     * @param inputPattern Patron de hora
     * @return LocalTime Object
     */
    public static LocalTime stringToLocalTime(String time, String inputPattern) {
        return LocalTime.parse(time, DateTimeFormatter.ofPattern(inputPattern));
    }

    public static boolean isBetween(LocalTime start, LocalTime end) {
        LocalTime current = LocalTime.now();
        return !current.isBefore(start) && current.isBefore(end);
    }

    public static String currentTimeStr(String timePattern) {
        return LocalTime.now().format(DateTimeFormatter.ofPattern(timePattern));
    }

    public static String currentTimeStr() {
        return currentTimeStr("HH:mm");
    }

}
