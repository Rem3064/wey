package util;

import driverWeb.DriverContextWeb;
import featureControlled.CucumberExecution;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.support.PageFactory;
import reporter.EstadoPrueba;
import reporter.PdfBciReports;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.stream.Collectors;


public class LogErrorInChrome {
    public static final Logger LOGGER = Logger.getLogger("LogErrorInChrome");

    public LogErrorInChrome() throws IOException {
        PageFactory.initElements(DriverContextWeb.getDriverWeb(), this);
    }

    public static List<String> valoresArchivo = new ArrayList<>();
    public static List<String> valoresArchivoFailed = new ArrayList<>();

    // Funcion para capturar JSError log.
    public static void GetJSErrorLog(String accion) {
        try {
            String str = "";
            String strWarning = "";
            String strSevere = "";
            // Objeto LogsEntries para cargar los errores de la consola, puedes discriminar por Level de Error en el Switch().
            LogEntries jserrors = DriverContextWeb.getDriverWeb().manage().logs().get(LogType.BROWSER);

            LOGGER.info("\n\n>>>>>>[ INICIO VALIDACION ERROR(s) CONSOLA JAVASCRIPT]<<<<<<");
            for (LogEntry error : jserrors) {
                switch (error.getLevel().toString()) {
                    case "SEVERE":
                        strSevere = strSevere + error.getLevel() + " - " + error.getMessage() + "\n";
                        break;
                    case "WARNING":
                        strWarning = strWarning + error.getLevel() + " - " + error.getMessage() + "\n";
                        break;
                    default:
                        str = str + error.getLevel() + " - " + error.getMessage() + "\n";
                }
            }
            LOGGER.info(str + ">>>>>>[ FINALIZA VALIDACION ERROR(s) CONSOLA  DE JAVASCRIPT]<<<<<<\n\n");
            if (!strWarning.equals("") && !strWarning.contains("RTP data channels are no longer supported.") && !strWarning.contains("Plan B SDP semantics, which is used when constructing an RTCPeerConnection") && !strWarning.contains("The AudioContext was not allowed to start. It must be resumed (or created) after a user gesture on the page")) {
                PdfBciReports.addReport("Validacion de mensajes en Consola JavaScript " + accion, "Se encontraron los siguientes mensajes en la consola javascript: \n" + strWarning, EstadoPrueba.WARNING, false);
            } else if (!strSevere.equals("")) {
                PdfBciReports.addReport("Validacion de mensajes en Consola JavaScript " + accion, "Se encontraron los siguientes mensajes en la consola javascript: \n" + strSevere, EstadoPrueba.WARNING, false);
            } else if (!str.equals("")) {
                PdfBciReports.addReport("Validacion de mensajes en Consola JavaScript " + accion, "Se encontraron los siguientes mensajes en la consola javascript: \n" + str, EstadoPrueba.WARNING, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static String revisaJavasctiptCucumber() throws IOException {
        revisaFailedCucumber();
        String comentario = featureControlled.CucumberExecution.getExecutionName();
        for (int i = 0; i < CucumberExecution.arrayFeaturesGT.size(); ++i) {
            String nombreFeature = (CucumberExecution.arrayFeaturesGT.get(i)).substring(0, (CucumberExecution.arrayFeaturesGT.get(i)).indexOf(";;")).replace(";", "");
            File file = new File("tmp/" + nombreFeature);
            String[] nombreArchivos = file.list();
            for (int j = 0; j < nombreArchivos.length; j++) {
                if (nombreArchivos[j].contains(".pdf")) {
                    String url = "tmp/" + nombreFeature + "/" + nombreArchivos[j];
                    String texto = lecturaPdf(url);
                    comentario = comentario.replace("CONTIENE ERRORES JAVASCRIPT - ", "");
                    if (texto.contains("Se encontraron los siguientes mensajes en la consola javascript:")) {
                        comentario = "CONTIENE ERRORES JAVASCRIPT - " + comentario;
                        featureControlled.CucumberExecution.setExecutionName(comentario);
                        valoresArchivo.add(nombreArchivos[j]);
                    }
                }
            }
        }
        //se eliminan los repetidos
        valoresArchivo = valoresArchivo.stream().distinct().collect(Collectors.toList());
        creacionArchivo();
        return comentario;
    }

    public static String revisaJavasctiptAT(String comentario) throws IOException {
        revisaFailedAT();
        File file = new File("tmp/");
        String[] nombreArchivos = file.list();
        for (int j = 0; j < nombreArchivos.length; j++) {
            if (nombreArchivos[j].contains(".pdf")) {
                String url = "tmp/" + nombreArchivos[j];
                String texto = lecturaPdf(url);
                if (texto.contains("SE ENCONTRARON MENSAJES EN LA CONSOLA JAVASCRIPT:")) {
                    if (comentario == null || "".equals(comentario)) {
                        comentario = "CONTIENE ERRORES JAVASCRIPT - ";
                        valoresArchivo.add(nombreArchivos[j]);
                    } else {
                        comentario = comentario.replace("CONTIENE ERRORES JAVASCRIPT - ", "");
                        comentario = "CONTIENE ERRORES JAVASCRIPT - " + comentario;
                        valoresArchivo.add(nombreArchivos[j]);
                    }
                } else {
                    if (comentario != null && !"".equals(comentario)) {
                        comentario = comentario.replace("CONTIENE ERRORES JAVASCRIPT - ", "");
                    }
                }
            }
        }
        //se eliminan los repetidos
        valoresArchivo = valoresArchivo.stream().distinct().collect(Collectors.toList());
        creacionArchivo();
        return comentario;
    }

    public static void creacionArchivo() throws IOException {
        File file = new File("tmp/ErroresJavascript.txt");
        if (file.exists()) {
            file.delete();
        }
        file.createNewFile();
        try (FileWriter fichero = new FileWriter(file)) {
            try (BufferedWriter bw = new BufferedWriter(fichero)) {
                for (String nombre : valoresArchivo) {
                    bw.write(nombre + "\n");
                }
                bw.close();
            }
        }
    }

    public static String lecturaPdf(String rutaArchivo) {
        try {
            File file = new File(rutaArchivo);
            PDDocument document = PDDocument.load(file);
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String text = pdfStripper.getText(document);
            document.close();
            return text;
        } catch (Exception e) {
            return "-1";
        }
    }

    public static void revisaFailedAT() {
        File file = new File("tmp/");
        String[] nombreArchivos = file.list();
        for (int j = 0; j < nombreArchivos.length; j++) {
            if (nombreArchivos[j].contains(".pdf") && nombreArchivos[j].contains("Failed")) {
                valoresArchivoFailed.add(nombreArchivos[j]);
            }
        }
        //se eliminan los repetidos
        valoresArchivoFailed = valoresArchivoFailed.stream().distinct().collect(Collectors.toList());
    }

    public static void revisaFailedCucumber() {
        for (int i = 0; i < CucumberExecution.arrayFeaturesGT.size(); ++i) {
            String nombreFeature = CucumberExecution.arrayFeaturesGT.get(i).substring(0, CucumberExecution.arrayFeaturesGT.get(i).indexOf(";;")).replace(";", "");
            File file = new File("tmp/" + nombreFeature);
            String[] nombreArchivos = file.list();
            for (int j = 0; j < nombreArchivos.length; j++) {
                if (nombreArchivos[j].contains(".pdf") && nombreArchivos[j].contains("Failed")) {
                    valoresArchivoFailed.add(nombreArchivos[j]);
                }
            }
        }
        //se eliminan los repetidos
        valoresArchivoFailed = valoresArchivoFailed.stream().distinct().collect(Collectors.toList());
    }

    private static String creacionCuerpoCorreo(String comentario) {
        String cuerpo;
        if ("".equals(comentario) || comentario == null) {
            cuerpo = "BUEN DIA, SE PRESENTAN LOS RESULTADOS DE LA EJECUCION. ";
        } else {
            cuerpo = "EL RESULTADO DE LA EJECUCION  " + comentario + ". ";
        }
        long largo = valoresArchivoFailed.stream().count();
        if (largo > 0) {
            cuerpo = cuerpo + "LOS CASOS FALLIDOS SON:: ";
        } else {
            cuerpo = cuerpo + "NO EXISTEN CASOS FALLIDOS";
        }
        Iterator<String> nombreIterator = valoresArchivoFailed.iterator();
        while (nombreIterator.hasNext()) {
            String nombre = nombreIterator.next();
            cuerpo = cuerpo + " " + nombre + "//";
        }
        cuerpo = cuerpo + ".......----------";
        largo = valoresArchivo.stream().count();
        if (largo > 0) {
            cuerpo = cuerpo + "LOS CASOS CON ERRRORES DE JAVASCRIPT SON:: ";
        } else {
            cuerpo = cuerpo + "NO EXISTEN CASOS FALLIDOS DE JAVASCRIPT";
        }
        nombreIterator = valoresArchivo.iterator();
        while (nombreIterator.hasNext()) {
            String nombre = nombreIterator.next();
            cuerpo = cuerpo + " " + nombre + "//";
        }
        return cuerpo;
    }


    public static void envioCorreo(String comentario) throws IOException, InterruptedException {
        Properties prop = Acciones.loadProp("almInversiones");
        String idAnalista = prop.getProperty("idAnalista");
        String idAnalista2 = prop.getProperty("idAnalista2");
        String idAutomatizador = prop.getProperty("idAutomatizador");
        String mailAutomatizador = prop.getProperty("mailAutomatizador");
        String usuarioNtAutomatizador = prop.getProperty("usuarioNtAutomatizador");
        String creacionCuerpoCorreo = creacionCuerpoCorreo(comentario);
        creacionHeader(idAnalista, idAutomatizador, creacionCuerpoCorreo, mailAutomatizador, usuarioNtAutomatizador);
        if (!idAnalista2.isEmpty()) {
            creacionHeader(idAnalista2, idAutomatizador, creacionCuerpoCorreo, mailAutomatizador, usuarioNtAutomatizador);
        }
        creacionHeader(idAutomatizador, idAutomatizador, creacionCuerpoCorreo, mailAutomatizador, usuarioNtAutomatizador);
    }

    private static void creacionHeader(String idAnalista, String idAutomatizador, String creacionCuerpoCorreo, String mailAutomatizador, String usuarioNtAutomatizador) throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\r\n  \"data\": [\r\n    {\r\n      \"author\": {\r\n        \"type\": \"workspace_user\",\r\n        \"id\": \"" + idAutomatizador + "\"\r\n      },\r\n      \"owner_test\": {\r\n        \"type\": \"test\",\r\n        \"id\": \"257006\"\r\n      },\r\n      \"text\": \"" + creacionCuerpoCorreo + "<a href=\\\"" + mailAutomatizador + "\\\" user-id=\\\"" + idAnalista + "\\\"> " + usuarioNtAutomatizador + " </a> \"\r\n    }\r\n  ]\r\n}");
        Request request = new Request.Builder()
                .url("http://octane.bci.cl:8080/api/shared_spaces/1008/workspaces/6001/comments")
                .method("POST", body)
                .addHeader("ALM_OCTANE_TECH_PREVIEW", "false")
                .addHeader("Authorization", "Basic YWxtYWRtaW5jb3JwOkNvMjAyMW1heSE=")
                .addHeader("Content-Type", "application/json")
                .addHeader("Cookie", "LWSSO_COOKIE_KEY=0lhb_fC85YKNZ9Mbusi8oas6sr-xfUIjVe6N1Lxsm3FCO9N_IVK_dQ_Ewnp8jrdJZypLpAiCLbxLIsGR16f18DwXXx9ltW7r2loq517EthsmuN1k863vk4BZXHsQCYVbCadPvgigJovaydigcXK9pgzhP0Tb80vGAQ4bIsNAEMbvpCLZ_zQffCvCSJvjQApxdroOWJjsteVBF0mPE31HD0McBYDVJASvevLbd2rEA5bCAjRR1vvmKFmFPsWDidJ9Zh1IyTnHU-0XHpkdDmugN_k9TcvxVts0q6HHAzZXWL5v9EEsDhBUnFQqfQjX2iymPOY8-JfxfJSU0UvpQ3rWHW7nrYqxXcU0ZJFvMLwGPINzKL1HhJb7Ccy9lhLlRv87; OCTANE_USER=YWxtYWRtaW5jb3Jw")
                .build();
        client.newCall(request).execute();
    }



}