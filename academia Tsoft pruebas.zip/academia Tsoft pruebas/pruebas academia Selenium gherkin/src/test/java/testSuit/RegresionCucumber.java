package testSuit;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import reporter.PdfBciReports;
import util.LogErrorInChrome;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Logger;

import static octane.UploadEvidence.UploadEvidenceTS;
@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = "com.hpe.alm.octane.OctaneGherkinFormatter:gherkin-results/ManualRunnerTest_OctaneGherkinResults.xml",
        tags = {"@TSCID994174"},
        features = {"src/test/java/feature/"},
        glue = {"step"}
)

public class RegresionCucumber {
    public static final Logger LOGGER = Logger.getLogger("RegresionCucumber");

    @AfterClass
    static public void afterClasss() throws IOException {
        LOGGER.info("AFTER CLASS");
        try {
            String usuarioALM = System.getProperty("userALM");
            String passALM = System.getProperty("passwordALM");
            String guardarALM = System.getProperty("guardarALM");
            String workspace = System.getProperty("workspace");
            String numeroTS = System.getProperty("numeroTS");
            String comentario = System.getProperty("COMENTARIO_PDF");
            if ("".equals(usuarioALM) || comentario == null) {
                comentario = LogErrorInChrome.revisaJavasctiptCucumber();
                UploadEvidenceTS("1", comentario + " Pruebas automatizadas WEB", "almInversiones.properties");
            } else {
                File file = new File("build/resources/test/almInversiones.properties");
                if (!file.exists()) {
                    file.createNewFile();
                }

                try (FileWriter fichero = new FileWriter(file)) {
                    try (BufferedWriter bw = new BufferedWriter(fichero)){
                        bw.write("userALM=" + usuarioALM + "\n");
                        bw.write("passwordALM=" + passALM + "\n");
                        bw.write("guardarALM=" + guardarALM + "\n");
                        bw.write("workspace=" + workspace + "\n");
                        bw.close();
                        comentario = LogErrorInChrome.revisaJavasctiptCucumber();
                        UploadEvidenceTS(numeroTS, comentario, "almInversiones.properties");

                    }
                }

            }
        } catch (Exception e) {
            PdfBciReports.closePDF();
        }
    }
}