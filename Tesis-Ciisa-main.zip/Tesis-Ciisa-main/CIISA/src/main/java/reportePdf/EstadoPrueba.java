package reportePdf;

public enum EstadoPrueba {
        PASSED,
        FAILED,
        WARNING;
    }