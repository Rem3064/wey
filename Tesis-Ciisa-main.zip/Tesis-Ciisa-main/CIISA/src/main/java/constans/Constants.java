package constans;

public class Constants {

  public static String urldemo="https://demoqa.com/";
  public static String urlshopping="http://advantageonlineshopping.com/";
  public static String browser="";
  //


  public static final String pathArchivo = System.getProperty("user.dir") + "\\tmp";
  public static final String RUTA_CONFIG_HTML_REPORT = System.getProperty("user.dir") + "\\";






}