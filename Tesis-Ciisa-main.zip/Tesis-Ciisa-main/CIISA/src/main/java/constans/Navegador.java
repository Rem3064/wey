package constans;

public enum Navegador {
    Firefox, Chrome, Explorer, Edge , Safari
}