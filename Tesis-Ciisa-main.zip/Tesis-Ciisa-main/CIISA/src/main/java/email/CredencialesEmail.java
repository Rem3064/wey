package email;

public class CredencialesEmail {
    public static String USER_EMAIL = "pruebasRMTesis@gmail.com";
    public static String PASS_EMAIL = "Ciisa2021";
}
